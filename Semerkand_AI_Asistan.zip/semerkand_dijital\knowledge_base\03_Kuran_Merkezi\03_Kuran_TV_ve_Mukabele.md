## 14. Kur'an TV ve Mukabele

### 14.1 Kur'an TV

- Ayetleri seçili hafızın sesiyle sırayla oynatır.
- Yalnız ayet, yalnız meal veya ayet+meal görünümü seçilebilir.
- Arapça yazı tipi değiştirilebilir.
- Sure ve ayet seçerek istenen konumdan başlanabilir.
- Oynatma duraklatılıp sürdürülebilir.
- Gerekli hafız paketi yoksa önce indirme istenir.

### 14.2 Mukabele

- Listeden cüz videosu seçin.
- Daha önce izlenen cüzde kaldığınız yerden devam edin veya baştan başlayın.
- Oynat/duraklat ve zaman çizgisinden ileri/geri sarma kontrollerini kullanın.
- Tam ekranla yatay ve geniş görünümü açın.
- Ekrana dokunarak gizli kontrolleri yeniden gösterin.
- Hızlı cüz seçicisinden başka cüze geçin.
- İzleme konumuna ayraç ekleyin; ayraçtan aynı saniyeye dönün.
- Ayraçları cüz bazında görüntüleyin veya silin. Oturum açıkken eşitleme yapılabilir.