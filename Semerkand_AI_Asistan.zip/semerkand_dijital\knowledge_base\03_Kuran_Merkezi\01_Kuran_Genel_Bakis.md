## 10. Kur'an merkezi

Alt menüden **Kur'an** bölümünü açın. Kartların kullanılabilirliği oturum ve içerik erişimine göre değişebilir.

### 10.1 Kur'an ana menüsündeki seçenekler

- **Kur'an-ı Kerîm:** Klasik mushaf sayfa görünümü.
- **Kur'an-ı Mecîd:** Gelişmiş metin, meal, arama, ses ve otomatik kaydırma özellikli okuyucu.
- **Kur'an TV:** Hafız sesi eşliğinde ayetlerin ekranda aktığı deneyim.
- **Mukabele:** Cüz bazlı video içerikleri.
- **Hatim:** Genel hatim ve grup yönetimi.
- **Cüzlerim:** Üzerinize aldığınız cüzlere hızlı erişim.
- **Hatim Duası:** Metin ve indirilebilir ses.
- **Hafız Sesleri:** Kur'an ses paketlerini indirme ve seçme.
- **Elifba:** Kur'an alfabesi öğrenme içeriği; cihazda uygun uygulama/bağlantı üzerinden açılabilir.

### 10.2 Hafız seslerini indirme

Menü yolu: **Kur'an > Hafız Sesleri**

1. Hafız listesinden bir okuyucu seçin.
2. Varsa örnek sesi dinleyin.
3. Paket boyutunu kontrol edip **İndir** düğmesine dokunun.
4. İndirme ve hazırlama tamamlanana kadar bekleyin.
5. Paketi aktif hafız olarak seçin.

İndirme durdurulup daha sonra sürdürülebilir. İndirilen hafızlar listelenir ve kullanılmayan paket onayla silinebilir. Ses paketi olmayan bir hafızla dinleme başlatılırsa uygulama bu ekrana yönlendirebilir.