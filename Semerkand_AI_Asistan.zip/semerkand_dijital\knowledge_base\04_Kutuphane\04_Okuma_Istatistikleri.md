## 29. Okuma istatistikleri

Okuma istatistikleri Kur'an ve Delâil okuyucularının menü/ayarlarından açılır.

- **Gün:** Seçilen gün.
- **Hafta:** Seçilen tarihin bulunduğu hafta.
- **Ay:** Seçilen ay.
- **Tüm zamanlar:** Bütün kayıtlar.
- **Özel:** Kullanıcının seçtiği başlangıç-bitiş aralığı.

Gösterilen ölçüler:

- Toplam okuma süresi
- Okuma yapılan gün sayısı
- Günlük ortalama
- En yüksek süreli gün
- Günlük süre grafiği
- Tarih bazlı ayrıntılar

Kur'an ve Delâil istatistikleri ayrı ürünler olarak tutulur. Oturum açıksa desteklenen veriler hesapla eşitlenebilir. Aktif okuma oturumu istatistik ekranı açılırken kayda alınır; yenile simgesi son durumu çeker.