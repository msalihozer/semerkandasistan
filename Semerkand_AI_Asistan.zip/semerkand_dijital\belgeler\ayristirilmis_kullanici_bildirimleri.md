# Ayrıştırılmış Kullanıcı Geri Bildirimleri

## 1. SORULAR (Bilgi Talepleri)

### Başlık: güneş
**Mesaj 1:** Güneş için bildirimleri değiştirecektim bulamadım

---

### Başlık: attığım adımı sayan vardı şimdi arıyorum bulamayorum nasıl yapılır bana söyleseniz
**Mesaj 1:** adım sayar vardı takvim de onu bulamıyorum

---

### Başlık: emsey
**Mesaj 1:** proğram çok güzel olmuş sadece emsey adımları saymıyor sadece

---

### Başlık: vakitlerde ezan okumuyor
**Mesaj 1:** ?

---

### Başlık: öneri
**Mesaj 1:** adım ölçer varmı

**Mesaj 2:** teşekkürler

---

### Başlık: NAMAZ VAKİTLER İNİ NASIL EKRAN BAŞİNA ALINIR
**Mesaj 1:** namaz vakti leri

**Mesaj 2:** Allah razı olsun inşallah

---

### Başlık: Namaz Vakitleri Gözükmüyor
**Mesaj 1:** kolay gelsin uygulamada bildirim ekranında namaz vakitleri gözükmüyor bilgi verebilirmisiniz

---

### Başlık: namaz vakitlerini telefon ekranımda ana sayfada göremiyorum
**Mesaj 1:** namaz vakitlerini telefonumun ana ekranında göremiyorum

---

### Başlık: Kuran okurken Ekran üstü yazılar
**Mesaj 1:** Tekrardan merhaba. 
Klasik görünüm kuran okuma sayfasında Kuran okurken yatay ekranda ekran üstü yazılar geliyor.
mesela namaz vaktine kalan dakika göstergesi geliyor en üst satıra.
Onu nasıl kaldırabilirim. yatay ekranda ilk satırda bana engel oluyor.
Teşekkürler.

---

### Başlık: tamam
**Mesaj 1:** selamın aleyküm benim güncelleme,den önce okuduğum cüzü yerini bulmak istiyorum mümkün,mü acaba

---

### Başlık: selamünaleyküm...ezan vakitlerin 5 dakika kala bana bildirilmesini rica ederim
**Mesaj 1:** ezan vakitlerin beş dakika önce bildirmesin rica edicem

---

### Başlık: bildirim
**Mesaj 1:** Merhabalar iyisinizdir umarım 
Öncelileri gelen bildirimleri favori beta beğenilen diye kaydedebiliyordum ama şimdi olmuyor.Ne yapmaliyim ?
Teşekkür ederim

---

### Başlık: namaz vakitleri bildirim cubuğu
**Mesaj 1:** telefon ekrana namaz vakit cubuğu gelmiyor

**Mesaj 2:** Lütfen erken dönüş yapılsın

---

### Başlık: kiblegah
**Mesaj 1:** kiblegahı kullanamıyorum yardımcı olur musunuz

---

### Başlık: Beğenilen sözler
**Mesaj 1:** bildirimlerden gelen sözleri beğenilen sözlere ekle yapıyorum ama sonra bulamıyorum nerde beğenilen sözler kısmı

---

### Başlık: bildirim sesini değiştiremiyorum
**Mesaj 1:** Yeni bildirim sesini beğenmedim farklı sesler sunmanizi bekliyorum

---

### Başlık: ana ekranımda gözükmüyor
**Mesaj 1:** vakitleri takip ediyordum ana ekranda suan kaldırılmıs

---

### Başlık: SemerkanD
**Mesaj 1:** SelamunAleyküm Uygulama öyle güzel öyle müthiş oldu ki 🫠🌹 hiç çıkamıyorum... 😍😍😍 
SemerkanD seyir uygulaması kapandı mı artık ...

**Mesaj 2:** evet paylaşıyorum Elbette :))

---

### Başlık: Hatırlatıcılar
**Mesaj 1:** Hatırlatıcıların ses seviyelerini alçalttığım da bile (ayar 1 olmasına rağmen), yüksek çıkıyor.

ilginize teşekkür ederim

**Mesaj 2:** ses sıkıntısı kalktı ,  cihazdan kaynaklı imiş , özür dilerim.

---

### Başlık: Bildirimler
**Mesaj 1:** Merhaba 
Takvim uygulaması ve namaz vakitleri ekranımda gözükmüyor ayrıca ezan vakitleri için bildirim sesi gelmiyor 
Uygulamalardan hepsini aktif etmeme rağmen düzelmedi

---

### Başlık: telefonun ana ekranında gözükme
**Mesaj 1:** merhabalar daha önceki uygulamada telefonun ekranında ezan vakitlerini pencere şeklinde görebiliyorduk fakat bu güncelleme ile göremiyoruz

---

### Başlık: kaza sayısı ve kurandaki yer imleri güncellemeden dolayı yok oldu
**Mesaj 1:** yazdığım kaza namazı sayıları ve kuranda belirlediğim yer imleri güncelleme nedeniyle yok oldu, aynı hesaba giriş yapmama rağmen. Nasıl geri getirebilirim? Yardımcı olursanız sevinirim.

---

### Başlık: selamün aleyküm ezber
**Mesaj 1:** Kur'an Kerim süre ezberi yapa biliyormuyuz
mülk süresini ayet ayet tekrar veya süreyi tekrar birde hızlı okuma ayarı varmi

---

### Başlık: hatme duası
**Mesaj 1:** hatme duası varmı

---

### Başlık: Aylık namaz vakitleri
**Mesaj 1:** Selâmûnaleykûm Gurbanım 
Aylık namaz vakitleri yüklenemiyor.

**Mesaj 2:** Aylık namaz vakitleri yüklenememe sıkıntısı genel olarak var galiba , çünkü başkalarında da uygulanamıyor.

**Mesaj 3:** " çözüldü "    diye  bildirmenizi rağmen , uygulama hâlâ yüklenemiyor.

ilgi ve bilginize...

---

### Başlık: Hadith und tägliche Information
**Mesaj 1:** Ich möchte gerne fragen, ob die täglichen Hadithe / islamische Inhalte und Informationen über die Propheten /Gelehrten auf der Seite der aktuellen Gebetszeit auch noch auf Deutsch übersetzt werden. Da sie aktuell auf englischer Sprache stehen, der Rest der App aber auf Deutsch eingestellt ist. Dies wäre für uns Konvertierten auch wichtig und eine Bereicherung diese Inhalte auch auf Deutsch lesen zu können.

---

### Başlık: Cuma
**Mesaj 1:** cuma surat

**Mesaj 2:** cuma

---

### Başlık: ezan sesi çalmıyor
**Mesaj 1:** vakitlerde ne yaptımsa ezan sesi çalmıyor

**Mesaj 2:** lütfen çözüm bulunuz

---

### Başlık: ezan vakitleri
**Mesaj 1:** ezan vakitlerini telefonumun ana ekranina nasıl koyarım

**Mesaj 2:** merhaba

---

### Başlık: Ana yukarda ekranda namaz vakitlerini görmek istiyorum
**Mesaj 1:** Ana ekran da namaz vakitlerini görmek istiyorum

**Mesaj 2:** teşekkürler

---

### Başlık: vidget
**Mesaj 1:** telefonun masa üstünde vidgeti nasıl ayarlıyabilirim?

---

### Başlık: namaz vakitlerinde
**Mesaj 1:** Her namaz vaktinde otomatik olarak ayarladığımız süre için sesize alma özelliğini bulamadık

**Mesaj 2:** şunu demek istiyorum diğer ezan programındaki uygulamalar gibi örnek öğle ezanı okununca benim seçeceğim süre kadar telefon kendini sessize alma özelliği yok her vakitte ayrı dakika sessize alma özelliği olması lazım 15/20/30 dakika gibi kolay gelsin

**Mesaj 3:** Allah cc işinizi rast getirsin

---

### Başlık: ezan saatı
**Mesaj 1:** ezan vakti ekranda gozuksun

---

### Başlık: Hatme Duası
**Mesaj 1:** Sesli hatme duası içeriği eklenebilir mi veya var mıdır?

---

### Başlık: eski  güncellemedeki cüz
**Mesaj 1:** güncellemedem önceki cüz kaçtı

---

### Başlık: vakitler
**Mesaj 1:** Arka planda kalan ezan vaktinin görünmesi için napmam gerekir?

---

### Başlık: ekranda nasıl göreceğim
**Mesaj 1:** telefonumun ekranında Namaz saatlerini sürekli görebilmek istiyorum Nasıl tutacağım ekranda küçültülmüş olarak

---

### Başlık: widget hkk.
**Mesaj 1:** ana ekranıma ezan gösterge sabitlendi çerçeve ebatı çok büyük eski ebatı nasıl sağlayabilirim

---

### Başlık: izin gerekli diyor ama ne izni olduğunu bulamadım
**Mesaj 1:** nasıl kullanacağım hakkında bilgi istiyorum

**Mesaj 2:** adım sayarı kullanamıyorum

---

### Başlık: her vakitlerde mesaj geliyor onu nasıl iptal edebilirim zaten sesli uyariyor
**Mesaj 1:** mesaj gelmeyi iptal etmek istiyorum

**Mesaj 2:** her vakitlerde msj geliyor onu iptal etmek istiyorum zaten sesli uyariyor

---

### Başlık: yardım
**Mesaj 1:** ana ekran da namaz vakti takvim kısmı gözüksün istiyorum ne yapmam lazım

---

### Başlık: namaz vakitleri hkk.
**Mesaj 1:** tlf mun ön yüzünde namaz saatleri nasıl gösteriliyor

---

### Başlık: namaz vakitleri 5 dakika önce bıldır
**Mesaj 1:** namaz vakitleri 5 dakika önce bıldır

---

### Başlık: namaz vakitleri Ana ekranda goruntuleyemiyorum
**Mesaj 1:** namaz vakitleri Ana ekranda goruntuleyemiyorum

---

### Başlık: ezan vaktinin belirtildiği görüntü
**Mesaj 1:** bu guncellemeden sonra yukarıdan baktığım ezan vakti gözükmüyor artık neden

**Mesaj 2:** Allah razı olsun kurbanım

---

### Başlık: durum çubuğu
**Mesaj 1:** namaz vakitleri durum çubuğunda gösterilmiyor yapmaya çalıştım olmadı

**Mesaj 2:** teşekkür ederim

---

### Başlık: Ana ekran kısa yol
**Mesaj 1:** normalde telefonu açınca ana ekranda namaz vakitleri oluyodu onu nerden açarım

**Mesaj 2:** Teşekkürler

---

### Başlık: telefonun ana ekranın da namaz vakitleri ni indiremiyorum
**Mesaj 1:** telefonun ana ekranın da namaz vakitleri ni indiremiyorum

---

### Başlık: bildirim çubuğu
**Mesaj 1:** namaz saatleri bildirim çubuğunda eskiden görünüyordu uygulamayı güncelledikten sonra gitti nasıl tekrar yapabilirim

---

### Başlık: delaili haurat
**Mesaj 1:** https://play.google.com/store/apps/details?id=com.tesnimvakfi.delailulhayrat
Bu uygulama yazi puntu kaydirma özelliği güzel

---

### Başlık: kıble pusulasi
**Mesaj 1:** kıble pusulası calismiyor pusula sensorunu bulamıyor diye kıbleyi gostermiyor

**Mesaj 2:** bu nasıl bir programmis pusula çalışmaz ise ben sürekli il dışına cikiyorum mecburen kıble yönü arıyorum pusula çalışmaz ise neye yarar bu program bende başka program yüklemek zorunda kalacam teşekkürler

**Mesaj 3:** omix x5

---

### Başlık: hatme duası
**Mesaj 1:** uygulamada hatme duası bulamadım

---

### Başlık: uygulama üst den gozuksun
**Mesaj 1:** uygulama yani namaz takibi üst cubukdan gorunsun istiyorum

---

### Başlık: bildirim çubuğu
**Mesaj 1:** kayan bildirim çubuğunda hatırlatmayı açamıyorum yardımcı olabilir misiniz?

---

### Başlık: bildirim çubuğu
**Mesaj 1:** kilit ekranında bile eskiden  namaz vakitlerini gösteriyordu şimdi kilidi açmadan göremiyorum  
benmi yapamadım yoksa bu özellik kaldırıldımı

---

### Başlık: üst kısmında namaz vakti gözükmesi
**Mesaj 1:** telefonun üst kısmında namaz vakitleri gözükmüyor

---

### Başlık: eski sürümde kur'an-ı Kerim sayfa numaraları
**Mesaj 1:** eski eski program sürümünde kur'an-ı Kerim sayfa numaraları vardı Onları öğrenmek istiyorum

**Mesaj 2:** eski sürümde iki tane ayrı yerden hatim yapıyordum bu sayfaları yer ivmeleri ile işaretledim o işaretli olan yer ivmeleri sayfalarını alabilir miyim

**Mesaj 3:** eski sayfa numaralarımı göremedim o yüzden

---

## 2. YAŞANAN SIKINTILAR (Teknik, İçerik, Ödeme, Hesap)

### Başlık: Bibliothek
**Mesaj 1:** selamun aleykum,

ich habe ein Problem mit der Bibliothek es wird mir kein Inhalt angezeigt wenn ich drauf klicke. Ich habe die App schon deinstalliert und wieder installiert trotz dessen, steht dort kein Inhalt. Ich habe ein Iphone 13 Pro Software 18.7.8. Ich habe ständig Probleme auch davor mit dem Abonnierung. Ich bitte um Hilfe.

---

### Başlık: ekran üstü görünürlük
**Mesaj 1:** uygulamayı güncellendikten sonra ekranın üst kısmında artık vakit saatlerini göremiyorum durum çubuğu üzerinde vakit saatlerini gosteren bir güncelleme yaparsanız sevinirim

---

### Başlık: Nida uygulaması er meydanı programı
**Mesaj 1:** merhaba Nida uygulamasında severek takip ettiğimiz er meydanı arşivleri görünmüyor uzun bir süredir ne zaman eklenir tekrardan en kısa zamanda eklenmesi dileğiyle kolay gelsin

---

### Başlık: uygulama hakkında
**Mesaj 1:** s.a. 
uygulama çok karışık. eski sade halini istiyorum. ana sayfayı kendi seçebileceğimiz sadeliğe ayarlanabilsin lütfen.

---

### Başlık: abonoment
**Mesaj 1:** wo kann ich meine abos sehen

---

### Başlık: Slovakya Namaz vakitleri
**Mesaj 1:** Selamun aleyküm, Slovakya namaz vakitleri kis saatiymis gibi gosteriyor. Butun namaz vakitleri bir saat normaline gore daha erken gozukuyor takvimde. 

Selamlar

---

### Başlık: Ana ekranda açamıyorum,ezan vakitlerini görmek için ekrandaki LOGO'ya tıklayınca açılıyor ben ekranda sürekli açık görünmesini istiyorum eskisi gibi
**Mesaj 1:** Ana ekranda açamıyorum,ezan vakitlerini görmek için ekrandaki LOGO'ya tıklayınca açılıyor ben ekranda sürekli açık görünmesini istiyorum eskisi gibi

---

### Başlık: adım sayar
**Mesaj 1:** adım sayarı aktif hale getşremiyorum izin gerekli diyor tüm izinleri verdiğim ama hala kullanamıyorum

---

### Başlık: telefon
**Mesaj 1:** telefonumun ana ekranında namaz vakitleri görünmüyor

---

### Başlık: selamünaleyküm
**Mesaj 1:** selamünaleyküm sistemi değiştirmişsiniz şimdi Kur’an okuyordum nerede kaldığımı bulamıyorum bana yardımcı olur musunuz

---

### Başlık: namaz vakitleri
**Mesaj 1:** namaz vakitleri TLF üst ekranda gözükmesi için ne yapilmali

**Mesaj 2:** teşekkürler

---

### Başlık: güncelleme
**Mesaj 1:** selamun aleyküm programa getirdiğini her güncellemeden sonra eski bilgiler siliniyor kazanamazı takibi kuranı Kerim’de kaldığımız yerler gibi özellikle kaza takibi konusunda kaç kez sıkıntı yaşadım 
lütfen birdaha güncelleme yapmadan önce bir uyarı verilsin ki bizde bilgileri not edelim

---

### Başlık: alarm kurma hatası
**Mesaj 1:** vakit alarmları kurarken alarm kurma hatası veriyor. bunun dışında  uygulama çok güzel olmuş Allah razı olsun

---

### Başlık: Abone sorgulamada çıkmıyor
**Mesaj 1:** abonelikleri niye çıkmıyor

**Mesaj 2:** on tane abonemiz var bir tane isim yok

---

### Başlık: telefon numarasına kod gelmiyor
**Mesaj 1:** arkadaş dergi abonesi giriş yap deyip gerekli yerleri dolduruyor şifre belirliyor telefon numarasını girip kod istediğinde kod gelmedi  tekrar gönder dediğimizde bu numara geciçi olarak engellendi diyor

---

### Başlık: kısa yolları açamıyorum kurban
**Mesaj 1:** benim telefon dan mı yoksa uygulamalar mı anlamadım gider kalanlar muhteşem

---

### Başlık: semarkand dergisine obonelim var
**Mesaj 1:** semarkand dergisi abonesiyim sifreyi kabul etmiyor

---

### Başlık: ezan vakitlerinde bildirim gelmiyor
**Mesaj 1:** b

**Mesaj 2:** ezan vakitlerinde bildirim gelmiyor

---

### Başlık: kıble
**Mesaj 1:** kıble yönü her defa farklı gösteriyor

---

### Başlık: Semerkand Seyir açılmıyor
**Mesaj 1:** Semerkand Seyir açılmıyor

---

### Başlık: sadelik
**Mesaj 1:** ula arkadaş yazıları vakti göremiyoruz puntoyu büyütün diyoruz siz puntoları küçültüyorsunuz zeka sorununuz mu var göremiyoruz kardeşim bu uygulamayı her kullanan 16 yaşında değil . bakın sizden başka bu puntoda nemaz vakti uygulaması var mı . bir sürü gereksiz şey koymuşsunuz . SADELİK İSTİYORUZ

---

### Başlık: kaydettiğim kaza namazlarımızı silindi
**Mesaj 1:** kaza namazlarımızı kayboldu

---

### Başlık: Namaz vakitlerini ana ekrana ekleyemiyorum
**Mesaj 1:** Uygulama güncellemesini önce uzun süredir kullandığım ezan vakti programı ana ekranımda duruyordu ben de bu şekilde namaz vakitlerimi rahatlıkla takip edebiliyordum fakat güncellemeyle beraber uygulama arayüzünün değişmesi ezan saatlerini ana ekranıma eklememi zorlaştırdı. Yardımcı olmanızı rica ediyorum💫

---

### Başlık: Bildirim sorunu
**Mesaj 1:** Selamün aleyküm uygulamanızı eski versiyonlarından beri kullanıyoruz fakat bu yeni güncellemeden sonra bildirim alanındaki namaz vakitlerini göremiyoruz  cihaz  samsung a56  bildirim izin ve ayarları yapıldı fakat sorunumuz devam ediyor. hayırlı çalışmalar  diliyorum.

---

### Başlık: Kur'an
**Mesaj 1:** selam aleyküm kuran okurken en üst kisinda sayfa ayrıca okuduğumuz sayfa koyu olarak belli oluyordu yeni uygulamada koyu oluyor ve sonra kapanıyor. Düzenleme şansı varmi.

---

### Başlık: Dil secimi
**Mesaj 1:** Türkce dile ayarlıyom , ertesi gün almaca dil gecmiş??

---

### Başlık: Kaza Takibi
**Mesaj 1:** Merhaba, uygulama güncellenmiş ve yeni görünümü oldukça güzel olmuş 🥰 Eneği geçen herkesin eline sağlık. Kaza namazı takibi alanında benim zaten hali hazırda bilgilerim vardı, onlar silinmiş. Olsun ekran görüntüsü alıyordum zaten belirli aralıklarla ne olur ne olmaz diye ama kaza namazı alanında sadece hesaplamayla sayı girilebiliyor. En yakın zamanı hesaplayıp bir bir artırıp eksiltip gideyim dedim çok uğraştırıcı, bu kısımda direkt sayı girilebilecek şekilde de bir düzenleme yapılırsa çok iyi olur 🙏🏻 Bir de widgeta saat ve hava durumu da eklendiğini gördüm, uygulamada da adım sayar gördüm. Talep üzerine mi eklendi bilmiyorum ama uygulamanın odağında kalmak bence daha iyi olur. Uygulamanın kendi içeriği zaten oldukça zengin ve farklı içerikler var, başka şeyler de eklenince daha karmaşık görünebiliyor, naçizane fikirim 🌸 Desteğiniz için teşekkür ederim. Bu arada bu destek kısmı da mükemmel olmuş önceden hep mail bulup mail atmaya çalışıyordum, uygulamada bu kısmı görünce çok sevindim 🤝🏻

---

### Başlık: bildirim çubuğu
**Mesaj 1:** Bildirim çubuğunda sürekli namaz vakitlerini göstermeyi nasil ayarlayabilirim

**Mesaj 2:** Biraz durduktan sonra bildirim çubuğundan kalkıyor bunu nasıl kalıcı ayarlayabilirim

---

### Başlık: kısayollar
**Mesaj 1:** sayfa düzeni çalışmıyor kısayolları düzenleme tuşları çalışmıyor

**Mesaj 2:** Tamam sorun yok hata bendeymiş kolay gelsin

---

### Başlık: kilit ekranında bildirim çubuğu yok
**Mesaj 1:** uygulama bugün güncellendi kilit ekranında namaz saatleri gösteriyordu artık o yok

**Mesaj 2:** verdiğiniz destek için teşekkür ederim sorun çözüldü

---

### Başlık: Ekran üstü görünu
**Mesaj 1:** Namaz saati ekranda görünmüyor

---

### Başlık: Iphone un kilitli ekranında zaman görünmüyor
**Mesaj 1:** Iphone 11 de kullanıyorum. Ekran kilitliyken sağa kaydırınca gelen (yani soldaki sayfada) namaza kalan süre ve takvim görünüyordu (araç takımı olarak), bu güncelleme ile artık görünmüyor

---

### Başlık: akşam namazı ve yatsı namazının alarmını kuramıyorum hatırlatıcılarını izin vermiyor
**Mesaj 1:** akşam ve yatsı namazının hatırlatıcılarını ayarlıyorum izin vermiyor

---

### Başlık: Widget
**Mesaj 1:** Selamün aleyküm, play storda yazdığım yazı için tekrar rahatsız ediyorum. Widgetlerden bir tanesini kullanıyorum. maalesef yazıların hepsini görebilmek için yarım sayfa büyütmek zorunda kaldım. Biraz daha küçültme yapıldığında sayfaya uyması için bir ayar yapılabilirse çok iyi olur. Allah razı olsun. Emeklerinize sağlık. saygılar

**Mesaj 2:** Ben teşekkür ederim, cevap için. kolaylıklar dilerim.

---

### Başlık: vakit bildirim ekranı
**Mesaj 1:** ekranda üstte ama saatlerini yazan bölüm istiyorum

---

### Başlık: Hatırlatma
**Mesaj 1:** Ezan vakitleri ayarlanmıyor.Yeni gelen güncellemede sorun var galiba.

**Mesaj 2:** Hayır ikiside değil vakitlerdeki bildirim ayarlanmıyor.

**Mesaj 3:** Hatırlatıcılar ezan vakitleri ayarlanmıyor sorun var açıyorum kendisi tekrar kapanıyor.

---

### Başlık: telefonun üst bildirim kısmında vakitleri görmek istiyorum
**Mesaj 1:** takvim dijital olmadan önce telefonun üst kısmını indirdiğimiz de beliren ezana ne kadar kaldığı ve diğer vakitler gözüküyordu şuan o yapılamıyor yardımcı olur musunuz

---

### Başlık: delailulhayrat
**Mesaj 1:** selamünaleyküm delailil hayrat çok güzel elinize sağlık fakat otomatik döndürme yapılamıyor bilgi verirmisiniz

**Mesaj 2:** daha önce vardı yapılabilirse hoş olur yaşlılar daha büyük harfleri rahat okuması bakımın dan hayırla kalın

---

### Başlık: vakit bilgisi
**Mesaj 1:** Selamun aleyküm,
Semerkand takvimindeki ana ekrandaki namaz vakitleri kısmını telefondaki kapalı ekranda gözükme imkanı varmı acaba blok olarak.

**Mesaj 2:** Allah razı olsun kurbanım

---

### Başlık: Dijital dergi
**Mesaj 1:** Abone olmama rağmen dergimi dijital ortamda okuyamıyorum

---

### Başlık: Takvim
**Mesaj 1:** günlük takvimde malesef almanca degilde inglizce gösteriyor.

---

### Başlık: hatırlatıcılar
**Mesaj 1:** iyi günler namaz vakti bildirimlerini nasıl kapatabilirim

---

### Başlık: Delailül hayrat
**Mesaj 1:** Delailül Hayrat sayfalarında çok fazla simge var. Kur'ân-ı Kerîm'de ekranı genişletince simgeler kalkıyor ama D. Hayrat'ta bu yok. Göz yoruyor. İnşaellah bir düzenleme yaparsınız. Teşekkürler

---

### Başlık: vakit
**Mesaj 1:** eskiden uygulamaya tıklamama gerek kalmadan telefonumun ana ekranında vakitlerin yazdığı bi çubuk olurdu onu nasıl açıcam

---

### Başlık: telefon ana ekranına kısayol ekleme
**Mesaj 1:** Selamün aleyküm telefon ana ekranına namaz vakitleri kısayol ekleme mevcut mu yenis sürümde?
Hayırlı günler

**Mesaj 2:** Merhaba adımları yaptım yalnız Ana ekranda Araç yüklenemiyor uyarısı alıyorum

**Mesaj 3:** Teşekkür ederim

---

### Başlık: Üst bildirim çubuğu
**Mesaj 1:** Selamün aleyküm arkadaşlar kolay gelsin 

Öncelikle elinize sağlık uygulamanın güncellemesi gayet başarılı olmuş..

Namaz vakitleri ile ilgili daha önceden üst bildirim çubuğunda görünüyordu lakin yeni güncellemeden sonra gözükmüyor. Ancak Uygulamaya giriş yaparak bakabiliyoruz. Konu ile ilgili geri dönüş rica ederim..

---

### Başlık: Her sabah herşey sifirlaniyor
**Mesaj 1:** Selamün Aleyküm 
Her sabah kalktığımda yeni app de yaptilarim herşey sifirlaniyor. 
Kur'an'ı Kerim'in de kaydettiğim sayfalar siliniyor. 
Hatirlaticalar sıfırlanıyor. 
Kaza Namazı takibim sıfırlanıyor. 
Sorunlar var galiba daha. 

Xiaomi 15 Ultra

saygılar 
Işci

**Mesaj 2:** Rabbim kolaylık versin

---

### Başlık: teşekkür
**Mesaj 1:** çok güzel uygulama olmuş teşekkür ederiz inşallah genel semerkand dergahlarımızıda konum yaparız

---

### Başlık: ana ekranda görünüm
**Mesaj 1:** uygulamayı kullanmanın dışında namaz vakitlerini de görmek istiyorum

---

### Başlık: ezan alarmı
**Mesaj 1:** ezan vaktinde ezan sesi gelmiyor

---

### Başlık: uygulama güncelleme olmadan önce boş sayfada üstte namaz vakitleri yazıyordu uygulamaya girmeden kolayca saatlere bakabiliyordum güncellemeden sonra bunu yapamıyorum
**Mesaj 1:** uygulama güncelleme olmadan önce boş sayfada üstte namaz vakitleri yazıyordu uygulamaya girmeden kolayca saatlere bakabiliyordum güncellemeden sonra bunu yapamıyorum tekrar saatleri boş sayfanın üst köşesine nasıl getiririm yardımcı olurmusunuz

---

### Başlık: Hatırlatıcı Sesi
**Mesaj 1:** İyi Günler,
Uzun yıllardır kullandığım bir uygulama, dün güncelleme sonrasında "Hatırlatıcı'nın sesi" kapatma kısmı yok " Telefondan Bildirimi sessize" almama rağmen sesli bir şekilde çalıyor ve "kapat" diyene kadarda susmuyor⁉️Acil bir çözümü olmalı‼ ️Evet hatıraltma istiyorum ama toplum içine çıkıyoruz seslide uygun olmuyor maalesef⁉️

---

### Başlık: Rumi takvim
**Mesaj 1:** Selamünaleyküm Öncelikle yeni sürümü Beğendik güzel yalnız Ecdadımızın Osmanlı Devleti'nin kullanmış olduğu Alaturka Rumi takvimin bilgileri yeni sürümde yok bu acizane değerlendirmesi lazım tekrar gösterilmesi lazım önceki bütün mesela takvimlerde var

---

### Başlık: namaz vakti
**Mesaj 1:** namaz vakitleri yok

**Mesaj 2:** teşekkürler sağolun sorunu hallettim

---

### Başlık: vakit ayarları
**Mesaj 1:** takvim verisi alınamadı yazıyor 
yani vakitler görünmüyor saat olarak

**Mesaj 2:** hayır konum bilgisi girdim düzeldi teskkur ederim

---

### Başlık: Kaza Namazı
**Mesaj 1:** selamünaleyküm sayın admin öncelikle böyle bir program hazırlayıp hizmetimize sunduğunuz için RABBİM cc hepinizden razı olsun gece kuranı kerimle ilgili teknik destek bilgimi paylaşmıştım dönüş yaptınız sağolun. Kuran okunacak sayfada sadece ekran yüzünde yazılar olması yazınında büyümesi açısından verimli olacaktır. Kaza namazı arttırımında her arttırıp azaltmaya soru soruyor kontrolün kullanıcıda olması daha verimli olacaktır. çok teşekkür ederim

---

### Başlık: vakit bildirim ekranı görünmüyor
**Mesaj 1:** vakit bildirim ekranı görünmüyor

**Mesaj 2:** tamam hallettim teşekkür ederim

---

### Başlık: Kuranı kerim
**Mesaj 1:** Selamünaleyküm kuran okuma sayfasında ezan vaktine kalan süre görünüyor oda yazıyla karıştığı için problem teşkil ediyor.ALLAH cc razı olsun

---

### Başlık: kuran-ı kerim bölümünde düzenleme talebi
**Mesaj 1:** Selamün Aleyküm. 
Kur'an-ı Kerim bölümünde cüz okurken sıralama gayet düzgün devam ediyor. programı kapatıp açınca da sorun yok ancak; normal cüzün haricinde başka bir yere geçince mesela "cuma günü bir yasin okuyayım, sonra cüzüme devam ederim" dediğinizde hangi cüzün kaçıncı sayfasında kaldığınızı kayıt etmiyor.  hatim için ayrı ve hatırlatma sistemi olan bir bölüm olmalı diye düşünüyorum. ya da böyle bir hatırlatma kısmı var mı programda?

---

### Başlık: bildirimleri kapatılmasın namazi bildorimleri
**Mesaj 1:** namaz bildirimleri kapatirmisin

---

### Başlık: yer imleri problemi
**Mesaj 1:** hatim için okumalarda işaretli olan yer imleri kayboluyor,ertesi günü kaldığımız yerden baslayamiyoruz.
hayırlı günler,kolaygelsin,başarılar!

**Mesaj 2:** zahmetiniz için teşekkürler,var olun!

---

### Başlık: Kur'an okurken büyütme yok
**Mesaj 1:** Kur'an okurken büyütemiyorum eski sürümde büyüyordu burda yok düzeltilmesini istiyorum

---

### Başlık: Yer imleri
**Mesaj 1:** Yer imlerinde hangi cüz olduğu yazmıyor 
 sadece sure ve sayfa var

---

### Başlık: namaz vakti bildirimi hatırlatıcı
**Mesaj 1:** namaz vaktinde bildirim çalıyor ya onu nasıl açıcam??

---

### Başlık: kur'an
**Mesaj 1:** kur'an da kayıtlı yer imim 
güncelleme sonrası silindi

---

### Başlık: delailul hayrat
**Mesaj 1:** kaydırmalı okurken aşağıda sarı bir bölümde kalan süre ve yüzde kaç okunduğunu gösteriyor O bölümü kaldırabiliyor muyuz sadece sayfanın kendisi olsun istiyorum

---

### Başlık: yeni güncellenen Semerkant dijital hakkında
**Mesaj 1:** Semerkant dijital dün güncelleme istedi, yaptım fakat şu anki program yani uygulama çok kötü olmuş ,eskisi ondan çok ama çok daha güzeldi,lütfen eskiye dönün,bu sadece benim fikrim değil ,benimle beraber başka arkadaşlar da böyle düşünüyor, teşekkür ederim.

---

### Başlık: ömer
**Mesaj 1:** Namaz vakitlerini öncekigibi ekranda göremiyorum

---

### Başlık: iphone araç takımında çalışmıyor
**Mesaj 1:** uygulama  iphone araç takımında kullanılmıyor

---

### Başlık: namaz vakitlerinin ana ekranımda çıkmaması
**Mesaj 1:** güncelleme sonrası telefon ana ekranımda yer alan namaz vakitleri kayboldu ve yeniden ayarlanmıyor .

---

### Başlık: iPhone ve Apple Watch vakitleri farklı
**Mesaj 1:** iPhone ile Apple Watch vakitlerinde farklılık var. Konum aynı, hesap aynı, cihazlar birbirine bağlı. Ekran kayıtlarıda mevcut. Konum: Castrop-Rauxel (Almanya). Cihaz bilgilerim: iPhone 16 Pro Max, iOS 27 - Apple Watch Series 11, watchOS 27

---

### Başlık: Sesli İçerikleri Açamıyorum.
**Mesaj 1:** Öncelikle Allah Razı Olsun Muhteşem Olmuş Uygulamanız. Ben Güncellemeden çok memnun oldum.. Semerkand Radyo Semerkand TV gibi Sesli yayınlar ilahiler eklenmiş. tıkladığında dönüp dönüp duruyor yayına Bağlanıyorum :( Buna çok üzüldüm Benim cihazım ile alakalı bir sorun sanırım bu. Dergileri de Sesli olarak dinleyemiyorum . :( Bunun teknik destekle çözülmesi mümkün mi Telefonum Vivo MARKALI ondan kaynaklı mi acaba

**Mesaj 2:** önceki versiyonda böyle bir sorun yasamıyordum. Sanırım Cihazimla alakalı :(. bu ses acamama radyo dinleyememe sorunları

**Mesaj 3:** Allah Razı Olsun Sorunum Çözüldü :))

**Mesaj 4:** Şuan İtibariyle Sesli dergiler ilahiler ve Canlı yayınlar TV Radyolar Çalışıyor :))

**Mesaj 5:** Allah razı Olsun...  Aylık Üyelik Nasıl olacak. Şuan Üyeliğim var ama

**Mesaj 6:** sonrasında nasıl olacak

---

### Başlık: Semerkand ezan saatleri
**Mesaj 1:** uygulama düzgün çalışmıyor

**Mesaj 2:** yoksa uygulamayı kapatmak zorunda kalacam

---

### Başlık: ezan vakitleri telefonun üstkısmında gözükmüyor
**Mesaj 1:** ezan vakitleri telefonun üstkısmında gözükmüyor

**Mesaj 2:** çok teşekkür ederim açtım

---

### Başlık: vakit
**Mesaj 1:** uygulamaya girmeden yukarıdan parmağımı indirince vaktin ne kadar kaldığını görüyordum yeni güncelleme ile onu göremiyorum yardımcı olur musunuz

---

### Başlık: namaz saatlerini ekranda görmekistiyorum
**Mesaj 1:** namaz saatlerini ekranda görmek istiyorum ama uygula kapalıyken

---

### Başlık: adim
**Mesaj 1:** merhaba güzel içerik olmuş elinize sağlık.adımsayar nasıl çalışıyor ilk başta vardı ama sonra kayboldu sanki göremedim

---

### Başlık: ezan vakitleri ana ekrana nasıl alabilirim
**Mesaj 1:** ezan vakitleri ana ekrana nasıl alabilirim

---

### Başlık: uygulama
**Mesaj 1:** Semerkant uygulamasından kur'an-ı Kerim okuyordum yeni güncelleme ile illa üye olacağız ondan sonra Kur'an okuyacağız Kur'an okumak için bile üyelik talep ediyorsunuz bu nasıl bir İslam anlayış çok merak ediyorum ve güncellemeden önceki hali daha güzeldi bu berbat bir hale almış çok karışık çok böyle görsel konmuş

---

### Başlık: kuran sayfasındaki vakit saati
**Mesaj 1:** söz konusu saat dikkat dağıtıyor. isteyen kaldırabilirsiniz. bununla ilgili bir seçenek konmalı.
teşekkürler

---

### Başlık: anasayfa düzeni
**Mesaj 1:** eskisi gibi anasayfada sadece namaz vakitleri ve kalan vakit şeklinde bilgi görmek istiyorum diğer şeyleri degil

---

### Başlık: Türkce seçili ama
**Mesaj 1:** Selamün Aleyküm bu hatırlatıcıda Almanca yazıyor türkce ayarlı olduğu halde. 
düzeltiseniz sevinirim. 

saygılar 
Isci

**Mesaj 2:** evet ama dil seçimi türkce o yetmiyor mu

---

### Başlık: namaz vakitleri telefon ekranına nasıl alınıyor
**Mesaj 1:** yeni sürümde namaz vakitleri telefon ekranına nasıl aktarılır

---

### Başlık: delâilü'l-hayrat klasik görünüm
**Mesaj 1:** delâilü'l-hayrat klasik görünümde tam ekran seçeneği istiyoruz. bu hâliyle yazılar küçük kalıyor.

**Mesaj 2:** samsung z fold serisindeki katlamalı telefonlar için normal modda okuma yapabilmek için de bir tasarım düşünmek gerekiyor kanaatindeyim

**Mesaj 3:** Allah teâlâ razı olsun

---

### Başlık: secde ayeti
**Mesaj 1:** dinamik görünümde neml suresindeki secde ayeti yanlış vurgulanmış. bilginize.

**Mesaj 2:** Allah teâlâ razı olsun

---

### Başlık: tam ekran klasik görünüm ve dinamik görünümde sayfa sayısı sorunu
**Mesaj 1:** kur'an-ı kerim klasik görünüm tam ekranda sayfanın ilk satırında namaz vakti sayacı ayetin üzerinde beliriyor ve ayetin okunmasını engelliyor, düzeltilmesi gerekiyor.

bir diğer sorun ise dinamik görünümde ve klasik görünümde aynı sayfanın sayıları farklı. mesela klasik görünümde neml suresi 379. sayfa dinamik görünümde 380. sayfa olarak görünüyor.

**Mesaj 2:** Allah teâlâ razı olsun

---

## 3. ÖNERİLER VE TAVSİYELER

### Başlık: Kuran'ı kerim
**Mesaj 1:** Selamun Aleyku. mümkünse yazı biraz büyütülsün. 
ayet okutma özelliği olsun.

---

### Başlık: Teşekkür…
**Mesaj 1:** Elinşze sağlık çok güzel olmuş. Emeği geçenlerden Allah cc rz olsun.

Bir konu daha vardı. önceki halinde kayıtlı olan Kuran-ı Kerim de hangi sayfada olduğum. kaza takibimdeki bilgiler güncellemeden sonra gelmedi. bu konuda daha önceden sorun çözülmüştü ama bu köklü güncellemeden sonra tekrar gitdi. o bilgilerime nasıl ulaşabilirim?

---

### Başlık: ekran üstünde
**Mesaj 1:** ekran üstünde kalan dakka gözükmüyor

**Mesaj 2:** allah razı olsun oldu hızlı geri donus için teşekkürler

---

### Başlık: kur'an-ı Kerim okuma sayfasını  düzenleme
**Mesaj 1:** kur'an-ı Kerim okurken sayfanın ortasında belirgin duran saat ve sağ köşede büyüteç okumayı zorlaştırıyor bunu düzenlemeniz mümkün mü ayrıca eski uygulamada  kaldığımız yeri sabitleyebiliyorduk. şimdi ise başka bir sayfaya geçtiğimiz takdirde kaldığımız yeri unutabiliyoruz her seferinde etiketlememiz gerekiyor. Bir de hafız seçimine şeyh Abdulbasit Abdussamed eklerseniz çok seviniriz Allah'a emanet olun

---

### Başlık: Yeni uygulama
**Mesaj 1:** Selamunaleyküm,

sizi tebrik etmek istedim. Müthiş gelişme olmuş! Namaz vakitlerini akıllı saatim’den de takip edebilmem harika! Hatta bütün vakitleri saatin baş ekranından görebilsem daha da süper olacak.

Harikasınız!!!

Acaba Asrı-Sânî’de vakitlere eklenebilir mi acaba?

Çok teşekkür ediyorum. Allah sizlerden razı olsun!

Allaha emanet olun…
Cengiz Bolat

---

### Başlık: Namaz vakitleri
**Mesaj 1:** Merhaba İyi çalışmalar dilerim kıymetli emeğinizden dolayı öncelikle çok teşekkür ederim.

Bildirim çubuğunda namaz vakitleri sabit kalarak gösteriyordu. Ancak güncelleme sonrasında durum çubuğunda hiç göstermiyor namaz vakitlerini

**Mesaj 2:** Geri dönüşünüz için minnettarım sorun çözüldü teşekkürlerimi sunarım

---

### Başlık: namaz vakitlerini gösteren tablo
**Mesaj 1:** ekran üstü namaz vakitleri görünümü geri nasıl uyarlarım

**Mesaj 2:** çok teşekkür ederim elinize emeğinize sağlık.

---

### Başlık: kuran kerim ile ilgili
**Mesaj 1:** Selamünaleyküm üstatlar kur'an-ı Kerim tam sayfa açıp okurken üst tarafta sayfa numarası cüz bilgisi geliyor idi şu anda o gelmiyor o iyi oluyordu ara sıra göz ucuyla hangi ayetleri okuyoruz hangi sureyi okuyoruz sayfa numarası nedir diye bakıyor idim Şimdi tam ekranı kaldırıp o şekilde bakmam gerekiyor Bunu düzeltirseniz güzel olur diye düşünüyorum Allah razı olsun

---

### Başlık: Widgets geht nicht
**Mesaj 1:** Selamun Aleyküm, 

seit dem neuen Update von meinem Iphone ios27 geht mein Widget für die App nicht mehr ich kann es zwar hinzufügen aber es wird nur weiss angezeigt. Ich würde mich über eine Lösung freuen

---

### Başlık: Kısa sözler
**Mesaj 1:** Uygulamaya güncelleme gelmeden önce ezan vakitlerinden önce ve ezan vakitlerinde hadis,ayet,alimlerin ya da Gavs hzlerinin söylediği sözlerin bulunduğu bildirim gelince üzerine tıklayıp sözü beğenilere ekliyordum sonra beğendiğim sözler kısmından istediğim zaman açıp okuyordum şimdiyse sözün üstüne basınca o söz kayboluyor geri bulamıyorum paylaşım da yapamıyorum eskine haline dönsün lütfen Ehlibeyttenim.

---

### Başlık: geliştirme
**Mesaj 1:** yeni güncelleme ile harika bir uygulama olmuş. elinize emeğinize sağlık Allah razı olsun.
 Kuranı kerim okumaya başlandığında okumaya başlama duası açılsa daha güzel olur. (Allah'umma bil hakki enzeltehu we bil hakki nezela)

---

### Başlık: içerik ekleme
**Mesaj 1:** içerik olarak tefsir bölümü de olsun inşallah

**Mesaj 2:** Allah ﷻ razı olsun 🤲🏽

---

### Başlık: Saat
**Mesaj 1:** Uygulamanın önceki versiyonunda 12 saat uygulamasında vardı seçilebiliyordu şimdi ise sade 24 saat uygulaması var. Yine 12 Öğleden önce sonra ayarı yaparmısınız. 
Yeni Versiyon harika. Allah razı olsun

---

### Başlık: Teşekkür
**Mesaj 1:** Selamın Aleyküm Yeni Uygumama Çok Mükemmel olmuş ALLAH RAZI OLSUN AMİN Hayır Çalışmalar.
bir de Ricamız olcakdı Ratyoda Erkek Bayan ortak yayınlar oluyor bu tür yayınlar olmasan iyi olur biz ler bu tür şeylere ÇOK DİKKAT Etmeliyiz Biz ler İSLAMI Temsil ediyoz Hayırla Kalın ALLAH EMANET 
🇸🇦⚖️🕋🕌🌹💚🤲🇹🇷

**Mesaj 2:** AMİN 🇸🇦🤲💚🌹⚖️🕋🕌🇹🇷

---

### Başlık: Vakit namazları
**Mesaj 1:** selam Aleyküm ben fransanin thionville şehrinde oturuyorum orada vakit saatleri olmasından ta Luxembourg ülkesi dudelange sehrini baz alıyor acaba thionville sehri için vakit saatleri yaparmısiniz

---

### Başlık: Talep
**Mesaj 1:** selamün aleyküm 
hatme duası uygulamaya eklense yeni ezber yapacaklar için hoş olmaz mı

---

### Başlık: vakit saatleri ile ilgili
**Mesaj 1:** ana ekrandaki vakit saatlerinde imsak vaktinin yanına teheccüd vaktinin başlangıcınıda ekleyebilir misiniz ?

---

### Başlık: Hatme Duası
**Mesaj 1:** Hayırlı günler, acaba Semerkand uygulamasına hatme duasınıda ekleyebilir misiniz?
bazen kitap olmuyor ve ezber yapmak gerekiyor çok kolaylık olur.

Rabbim hizmetlerinizi kabul ve daim etsin.

---

### Başlık: widget
**Mesaj 1:** selamün aleyküm, programın yeni sürümü için elineze sağlık Allah razı olsun.
telefonumda Semerkand widget kullanırken widget arka planı çok siyah bu şekliyle de iyi durmuyor. transparan yapabiliyormuyuz yoksa yeni güncelleme olursa transparan yapa bilir misiniz.

---

### Başlık: Semerkand ezan vakitleri
**Mesaj 1:** sorun devam ediyor dediklerinizi yaptım ezan çalmıyor ekranın üstünde eski Semerkand güncelleme olmadan vakitleri saatleri gösteriyordu oda gitti

---

### Başlık: iki adet abonelik var
**Mesaj 1:** abone olduğum görünmüyor ankara sincan fatih subesi

---

### Başlık: vvakitlerde sesize alma
**Mesaj 1:** vakitlerde otomatik sessize alma özelliği yokmu? yoksa ben mi bulamadım. Hakkunızı helal edin.

---

### Başlık: widgwt
**Mesaj 1:** Bide widget uygulamadaki vakit sayacı gibi olsa çok şık olurdu.

---

### Başlık: widget
**Mesaj 1:** büyük fontlarda widget e yazılar sığmıuor ve tamamını göremiyoruz. Küçük fontlarda sığıyor ama bu sefer diğer uygulamaları okuyamıyoruz. 
bide widget zwmin rwngini değiştiremiyoruz. samsung s26

---

### Başlık: ezan çalmıyor
**Mesaj 1:** ezan çalmıyor

**Mesaj 2:** takvim alanında hatırlayacı yok

**Mesaj 3:** bildirim saatleri yok geniş bilgi veriniz

**Mesaj 4:** yaptım olmuyor dedikleriniz neden cevap yazmıyonuz

**Mesaj 5:** uygulama kaldıralım mı

---

### Başlık: ezan sesi vaktinde çalmıyor
**Mesaj 1:** vakit namazları zamanında çalmıyor

**Mesaj 2:** bunu düzeltiniz

---

### Başlık: zikirmatik
**Mesaj 1:** program içine zikirmatikte ilave edilirse hoş olur

---

### Başlık: delaülül hayrat hakkında
**Mesaj 1:** Basılı yayın delailül hayrat ile Semerkand dijital de bulunan delailül hayrat sayfa sıralaması birbirini tutmuyor.

---

### Başlık: takvim dijital
**Mesaj 1:** Dil neden arabca yok

**Mesaj 2:** Ayrica k kerim ve delaili hayatta kaydirma özelliği istiyoruz

**Mesaj 3:** Hayratta

---

### Başlık: Günlük Dualar
**Mesaj 1:** Uygulamada günlük dualar bölümü de olsa güzel olur. Günlük dualara dair uygulamanız var ama her cihazla uyumlu olmadığı için açılmıyor.

---

### Başlık: kurban olduklarım
**Mesaj 1:** Allah sizden razı olsun

---

## 4. DİĞER

### Başlık: Delalül Hayrat
**Mesaj 1:** imlecilerle başı belada delalu hayretimi okudun Cuma'yı okudum Dolayısıyla Cuma bitti cumartesiye geldi cumartesi İbiş işareti vurdum ve İnşaat'ın telefonda tekrar imleci açtığım zaman Cumartesi olması gerekirken Cumanın son sayfası görünüyor yani imlet pasif O da bir sorun benim için

---

### Başlık: Peygamber efendimiz sav hayatını sesli
**Mesaj 1:** Peygamber efendimiz sav 
hayatını sesli dinlemek istiyorum

**Mesaj 2:** cevap gelmedi

---

### Başlık: geçmiş e-dergi aboneliğimle ilgili
**Mesaj 1:** Geçmiş yıllarda e-dergi aboneliğimde indirmiş olduğum dergilerim yeni düzenleme ile yok oldu, erişemiyorum, yeniden indirmeye çalışıyorum izin vermiyor. Ne yapabilirim, geçmiş dergilerimi neden indiremiyorum?
Geçmiş kayıtlarımla kontrol edebilirsiniz.

---

### Başlık: uygulama ezan okumuyor
**Mesaj 1:** merhaba semerkand dijital uygulamasında namaz vakitlerini ayarladım ve seslerini de ayarladım ama ezan vakti gelince ses çıkmadı

**Mesaj 2:** ne zaman cevap verilecek

---

### Başlık: uygulama
**Mesaj 1:** uygulama kilit ekranında vakitleri neden gostermiyo içerik güzel olmuş ama paylaştığıniz hadisleri okuyamıyorum hızlı geciyo daha yavaş olsun lütfen

**Mesaj 2:** paylaştiginiz hadislerin üzerine birine basamadan diğerine geçiyor okuyamıyorum biraz yavaş geçse daha iyi olur

**Mesaj 3:** ezan vakitleri kilit ekranında gözüksün lütfen

---

### Başlık: Bildirim sesi  yüksekliği
**Mesaj 1:** Esselâmu aleyküm, merhabalar.

Uygulama içerisinde alarm ses seviyesini ayarlayabildiğimiz bir bölüm mevcut ve ben ses seviyesini kısıyorum. Ancak yaptığım ayar alarm vakti geldiğinde hiçbir şekilde uygulanmıyor; alarm yine son seviyede, aşırı yüksek bir sesle çalıyor.

Ses seviyesini uygulama üzerinden istediğim seviyeye getirmeme rağmen ayarın çalışmaması konusunda gerekli düzenlemenin yapılmasını rica ediyorum.

Daha önce de bu sorun nedeniyle farklı takvim uygulamalarına geçiş yapmıştım. Sorun devam ederse maalesef yeniden farklı bir uygulama kullanmak durumunda kalacağım.

İlginiz için teşekkür ederim.

**Mesaj 2:** Çok teşekkür ediyorum. Hayırlı günler.

---

### Başlık: ezan programı
**Mesaj 1:** android telefonda play stor da semerkand dijital ezan programı gelmiyor

---

### Başlık: Kuran ı Kerim
**Mesaj 1:** Kuran ı kerim okuyorum imleç ile işaretliyorum.Fakat özellikle sayfadan çıkıyorum tekrar o sayfayı da imleç işareti yok
Şimdi bilinçli yaptığım için sayfayı biliyorum ama aradan geçen zamanda bu sayfayı hatırlıyabilir.Yani imleç ben kaldırmadan ekran da görmek istiyorum 
Allah razı olsun

**Mesaj 2:** Allah razı olsun

---

### Başlık: Yönetici Mesajı
---

### Başlık: ana ekran
**Mesaj 1:** ekrana namaz saatlerini koymak istiyorum büyük geliyor ebat olarak küçültülmüş imkanı varmı

---

### Başlık: adım sayar
**Mesaj 1:** adım sayar nasıl aktif hale getirilir

---

### Başlık: namaz vakitlerini gösteren kısayol tablo
**Mesaj 1:** namaz vakitlerini gösteren tabloyu ana ekranda neden görmiyorum. son güncellemeden sonra kısayol tablo ekrandan kayboldu ana ekrana geri nasıl uyarlıyabilirim.

---

### Başlık: namaz saatini ana ekrana almak
**Mesaj 1:** yukarıda yazdığım şekilde

---

### Başlık: kerahat vakit uyarısına bilgilendirme eki yapılabilir mi?
**Mesaj 1:** kerahat vakitlerinde hiç bir namaz kılınmaz veya farz namazı kılına bilirmi? hiç bir namaz kılınmaz mı.? ilave olarak emeğinize saglık çok güzel olmuş.

---

### Başlık: namaz vakitleri sırasında gelen sözleri Semerkand Dijital’de göremiyorum
**Mesaj 1:** kurbanım Allah sizlerden razı olsun çok güzel olmuş öncelikle bu namaz vakitleri esnasında sözler paylaşılıyordu onlar çok hoşuma gidiyor hâlâ paylaşılıyor fakat Semerkand Dijital de şu an onları göremiyorum tıkladığım zaman kayboluyorlar nereden ulaşabilirim Allah razı olsun tekrardan

**Mesaj 2:** 🌹🤲🏻🌹

---

### Başlık: Semerkant amblemi arka tarafı mavi olsun
**Mesaj 1:** Semerkant tarafı amblem arka tarafı mavi olsun

**Mesaj 2:** Ben de çok çok teşekkür ederim 
Semerkant dünya markası semerkant’ı çok seviyoruz

---

### Başlık: widget çalışmıyor
**Mesaj 1:** Uygulamayı lütfen eski haline getirin yoksa sizi ezgi yen’e havale ederim

**Mesaj 2:** yaptım ama olmuyor widgeti özelleştirdim ekledim ama telefon ekranımda çıkmıyor

**Mesaj 3:** Anlayış göstermiyorum????

---

### Başlık: güncelleme saçmalığı
**Mesaj 1:** neden sürekli uygulamayı güncelliyorsunuz???? eskisi gayet iyiydi zaten? şu an araç takımına ekleyemiyorum iyice rezil ettiniz uygulamayı

**Mesaj 2:** widget çalışmıyor

---

### Başlık: takvim
**Mesaj 1:** çok güzel olmuş Allah cc razı olsun Allah cc sadatlardan ayırmasın 🤲🌹

---

### Başlık: ezan sesi gelmiyo
**Mesaj 1:** neden ezan vakti hatırlatıcı eczan sesi gelmiyor

**Mesaj 2:** teşekkür ederim 🌹

**Mesaj 3:** denedim ama olmadı sadece bildirim geliyo

**Mesaj 4:** açık

**Mesaj 5:** çözmeye calisacam inşallah

---

### Başlık: cep tellimin ana ekranına semerkand ekranını nasıl yukleyebilirim
**Mesaj 1:** cep tellimin ana ekranına semerkand takvimi nasıl yükleyebilirim

---

### Başlık: içerik
**Mesaj 1:** uygulamayı neden sürekli değiştiriyorsunuz

**Mesaj 2:** Beğenmedim,çok karışık ve göz yorucu

---

### Başlık: Namaz saatleri
**Mesaj 1:** merhaba ana ekranda namaz saatleri görünmesini istiyorum güncellemeden önce vardı güncelleyince kayboldu

---

### Başlık: hata
**Mesaj 1:** uygulama güncellendiğinden beri sürekli hata veriyor uygulama kendini kapatıyor lütfen sorunu düzeltir misiniz

**Mesaj 2:** Samsung galaksi s21

**Mesaj 3:** ilginiz için teşekkürler

---

### Başlık: ezan
**Mesaj 1:** ezan bildirimi ekran kaldirma çerçevemde gözükmüyor güncellemeden önce kaydirilabilir pencerede görebiliyordum lütfen yardımcı olun

**Mesaj 2:** Geri dönüşünüz için teşekkür ederim sorunu giderdim 🌹

---

### Başlık: ana sayfaya namaz vakitleri oluşsun
**Mesaj 1:** ana sayfaya namaz vakştleri

---

### Başlık: güncelleme
**Mesaj 1:** şuanki güncellemeyle alâkı çok güzel olmuş maşallah inşallah böyle kalır pley storide bu kadar kaliteli bir uygulama yoktur belkide tebrik ediyorum

---

### Başlık: bildirim çubuğu
**Mesaj 1:** bildirim çubugu ayarıni bulamadım var da ben mi bulamadim bilmiyorum bildirim cubugun da ezan vakitlerini gorebilirsek güzel olur

**Mesaj 2:** Tesekkurler

**Mesaj 3:** Tamam varmış buldum

**Mesaj 4:** Teşekkür ederim

---

### Başlık: Semerkand digital
**Mesaj 1:** eski versiyon istiyorum nasıl yapacam

**Mesaj 2:** eski güncelleme halini istiyorum nasıl olur

---

### Başlık: health connect adım sayari kullanamiyorum.
**Mesaj 1:** health connect adim sayari aktif etmek istiyorum.

---

### Başlık: Teşekkür
**Mesaj 1:** Allah razı olsun teşekkür ediyorum.

---

### Başlık: Telefon ekranına uygulamyi neden yukleyemiyorum
**Mesaj 1:** uygulamayı telefon ekranına yukleyemiyorum

**Mesaj 2:** çok teşekkür ederim iyi çalışmalar

---

### Başlık: hafız seçimi
**Mesaj 1:** selamünaleyküm uygulamamızın yeni hali çok güzel olmuş fakat hafızlarda Abdussamed rahmetullahi aleyhi de görmek isterdik Bir de kur'an-ı Kerim'i okumak için ille de üyelik istiyor bunu da neden yaptınız acaba

---

### Başlık: Teşekkür
**Mesaj 1:** Emeğinize sağlık dijital platformumuz çok güzel olmuş. Kullanıcının konforuna göre konfügre edilmesi gayet işlevsel.

**Mesaj 2:** Dergilerin ve güzel içeriklerin tek bir paylaşım butonuyla sosyal platformlarda paylaşılması hem bilgi hem reklam açısından mükemmel düşünülmüş.

**Mesaj 3:** Mekke, Medine, Semerkand Tv'ler ve ilahi platformuyla radyomuz büyük süpriz oldu. Rabbim emeklerinizi sahaya ulaştırmamızı nasip eylesin. Teşekkürler.🌹🌹🌹

---

### Başlık: Bildiri ve Kilit Ekranı
**Mesaj 1:** Uygulama önceki sürümde bildiri ve kilit ekranında görüşürken yeni güncelleme sonrası görünmemektedir.

---

### Başlık: widget ayarları
**Mesaj 1:** uygulamada widgete dair ayarlama özelliği bulunmamaktadır.önceki sürümde widget renk ve şeffaflığı ayarlanabiliyordu.

---

### Başlık: ezan bildirimi alamıyorum
**Mesaj 1:** ezan bildirimi alamıyorum

---

### Başlık: Destek Mesajı
---

### Başlık: test
**Mesaj 1:** test

---

### Başlık: notları toplu görebilmek
**Mesaj 1:** sure notları toplu görülse güzel olur

---

### Başlık: selamün aleyküm
**Mesaj 1:** deneme.

Mehmet Fatih sarı

deneme

deneme

---

