## 11. Klasik mushaf okuyucu

### 11.1 Giriş ekranı

- **Kaldığın Sayfa/Devam Et** son sayfa, cüz ve sureye götürür.
- **Yer İmleri** kayıtlı mushaf sayfalarını gösterir.
- Cüz, sure veya sayfa seçicisiyle yeni bir başlangıç yapılabilir.
- Bir bildirim, widget veya başka bölüm belirli sayfayı hedeflediyse okuyucu o sayfadan açılabilir.

### 11.2 Okuma işlemleri

- Sayfaları sağa/sola kaydırarak değiştirin.
- Uygun yatay düzende iki sayfa birlikte gösterilebilir.
- Üst alanda cüz, sayfa ve sure bilgilerini görün.
- Seçiciden cüz, sure veya sayfa numarasıyla doğrudan atlayın.
- Yer imi simgesiyle mevcut sayfayı kaydedin veya kaydı kaldırın.
- Tam ekranla araç çubuklarını gizleyin.
- Okuma imleci/takip bandını açıp satır üzerinde taşıyın; sunulan imleç görünümünü ayarlardan değiştirebilirsiniz.
- Ses düğmesiyle sayfayı aktif hafızdan dinleyin.
- Ekrandan çıkıldığında son sayfa otomatik kaydedilir.

### 11.3 Okuma istatistikleri

Okuyucunun menüsünden **Okuma İstatistikleri** ekranını açın. Gün, hafta, ay, tüm zamanlar veya özel tarih aralığı seçilebilir. Ekran toplam okuma süresi, okunan gün sayısı, günlük ortalama, en iyi gün, günlük grafik ve kayıt ayrıntılarını gösterir. Yenile simgesi yerel/hesap verisini günceller.

---

## 12. Kur'an-ı Mecîd gelişmiş okuyucu

- Ayetleri dikey ve kesintisiz metin akışında okuyun.
- Sayfa, cüz, sure ve ilerleme bilgisini takip edin.
- Başlıklara dokunarak cüz/sure/sayfa seçicilerini açın.
- Sayfa numarasını yazarak doğrudan sayfaya gidin.
- Sure arayın ve seçili ayete atlayın.
- Cüz içindeki hizb kısayollarını kullanın.
- İki parmakla Arapça metin boyutunu değiştirin.
- Meal görünümünü açıp kapatın.
- Ayete dokunarak o ayetten sesi başlatın, yer imi ekleyin veya paylaşın.
- Paylaşımda ayet, meal veya ikisini birlikte seçin.
- Otomatik kaydırmayı açıp hızını ayarlayın.
- Okuma perdesi/imleciyle belirli satırlara odaklanın.
- Farklı Arapça yazı tiplerini seçin; gerekli font paketi varsa indirin.
- Son sayfa ve sayfa içindeki yaklaşık konum çıkışta saklanır.
- Menüden Kur'an okuma istatistiklerini açabilirsiniz.

---

## 13. Mealli/metin Kur'an okuyucu

Mealli/metin okuyucu erişimi uygulama içindeki ilgili bağlantı veya yönlendirmeyle açılır ve üyelik isteyebilir.

- Son okunan sayfa/cüzden devam edilebilir.
- Cüz, sure veya sayfa üzerinden başlangıç konumu seçilebilir.
- Yer imleri kayıtlı ayet ve sayfalara götürür.
- Notlar, ayetlere eklenen kişisel notları listeler.
- Bir ayete dokununca Arapça, meal, sure, cüz ve sayfa bilgisini içeren ayrıntı açılır.
- Ayet ayrıntısından ses, yer imi, not ve komşu ayete geçiş işlemleri yapılabilir.
- İki parmakla yazı büyüklüğü ayarlanabilir.
- Çift dokunma tam ekranı açıp kapatabilir.
- Okuma zemini ve görünüm seçenekleri değiştirilebilir.
- Secde ayetleri listesinden ilgili ayete gidilebilir.
- Menüden okuma istatistikleri açılabilir.