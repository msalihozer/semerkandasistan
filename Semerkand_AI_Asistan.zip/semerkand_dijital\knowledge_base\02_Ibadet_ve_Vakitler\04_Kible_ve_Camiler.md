## 9. Kıble pusulası ve yakındaki camiler

### 9.1 Kıble pusulası

Menü yolu: **Ana Sayfa > Kıble Pusulası** veya **Menü > Kıble Pusulası**

- Telefonu düz ve yere paralel tutun.
- Cihazı yavaşça çevirerek Kâbe/kıble işaretini hedefe hizalayın.
- Doğru yöne yaklaşınca görsel veya titreşimli geri bildirim alınabilir.
- Ekranda kıble açısı ve Kâbe'ye yaklaşık mesafe gösterilebilir.
- Harita seçeneği varsa kıble doğrultusunu harita üzerinde açabilirsiniz.

Pusula kararsızsa telefonu havada sekiz çizer gibi hareket ettirin. Mıknatıslı kılıfı çıkarın; metal masa, hoparlör ve güçlü elektronik cihazlardan uzaklaşın. Cihazda yön sensörü yoksa pusula kullanılamayabilir.

### 9.2 Yakındaki camiler

Menü yolu: **Menü > Yakındaki Camiler**

- Konuma yakın camiler mesafe bilgileriyle listelenir.
- Liste ve harita görünümü arasında geçiş yapılabilir.
- Cami kartı ad, adres ve uzaklık gibi ayrıntıları gösterir.
- Yol tarifi, cihazdaki uygun harita uygulamasını açar.
- Konum izni kapalıysa yakınlık sıralaması ve yol tarifi başlangıcı doğru çalışmayabilir.