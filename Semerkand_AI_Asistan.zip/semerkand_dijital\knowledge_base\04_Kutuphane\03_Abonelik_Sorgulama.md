## 18. Abonelik sorgulama

Menü yolu: **Menü > Abonelik Sorgulama**

1. Ülke kodunu seçin.
2. Telefon numaranızı girin.
3. Sorgulamayı başlatın.
4. Gerekirse SMS ile gelen doğrulama kodunu yazın.
5. Aktif ve süresi bitmiş abonelikleri sonuç ekranından kontrol edin.

Abonelik kartında ürün/dergi adı, başlangıç/bitiş tarihi ve durum bulunabilir. Cihaz sınırı doluysa kayıtlı cihazlardan birini kaldırmanız istenebilir. Kod gelmezse süre dolduktan sonra yeniden gönderin. Abonelik görünmüyorsa ülke kodu ile numaranın abonelikte kullanılan bilgilerle aynı olduğundan emin olun.