## 30. Destek talepleri

Menü yolu: **Menü > Ayarlar > Destek**

Destek alanı oturum ve internet gerektirir.

### 30.1 Yeni talep oluşturma

1. **Yeni destek talebi** düğmesine dokunun.
2. Kategori seçin: Teknik, Bilgi Talebi, İçerik Problemi, Hesap ve Üyelik, Abonelik ve Ödeme, Öneri/Geri Bildirim veya Diğer.
3. Kısa ve açıklayıcı bir konu yazın.
4. Sorunu/isteği ayrıntılı şekilde mesaj alanına yazın.
5. Gönder düğmesine dokunun.

Teknik sorunda cihaz modeli, işletim sistemi, uygulama sürümü, sorunlu ekran, hata metni ve sorunu yeniden oluşturma adımlarını yazmak çözümü hızlandırır. Şifre, SMS kodu ve ödeme kartı bilgisi paylaşmayın.

### 30.2 Talepleri izleme

- Talep listesinde konu, kategori, tarih ve durum görülür.
- Durumlar **Açık**, **Çözüldü** veya **Kapalı** olabilir.
- Talebe dokunarak kullanıcı ve destek mesajlarını konuşma biçiminde görün.
- Açık/çözülebilir konuşmaya yanıt yazıp gönderin.
- Kapalı talebe yeni mesaj gönderilemez; gerekirse yeni talep açın.
- Destek yanıtı için bildirim gelebilir; bildirime dokunmak konuşmayı açabilir.