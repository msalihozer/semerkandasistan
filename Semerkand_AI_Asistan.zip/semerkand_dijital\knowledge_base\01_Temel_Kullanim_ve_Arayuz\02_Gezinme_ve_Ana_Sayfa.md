## 2. Hızlı erişim ve gezinme

### 2.1 Alt menü

Ekranın altındaki ana menüde şu bölümler bulunur:

- **Kitaplar**
- **Dergiler**
- Ortadaki yuvarlak **Ana Sayfa** düğmesi
- **Kur'an**
- **Delâil**

Bir ana bölüm düğmesine dokunmak o bölümün giriş sayfasını açar. Okuyucu, oynatıcı ve bazı ayrıntı ekranlarında alt menü görünmeyebilir; geri düğmesiyle önceki ekrana dönülür.

### 2.2 Yan menü

Sol üstteki menü simgesi yan menüyü açar. Buradan ana modüllere, Takvim araçlarına, profil/giriş, abonelik sorgulama, tema, ayarlar, konum ve widget sayfalarına ulaşılır. Bağlı bir saat algılanmışsa saat kartı da menüde gösterilebilir.

Ana modüller:

- Ana Sayfa
- Takvim
- Kitaplar
- Dergiler
- Kur'an
- Delâilü'l-Hayrât
- Bazı sürüm/düzenlerde Duvar Kâğıtları

Takvim araçları:

- Hatırlatıcılar
- Kıble Pusulası
- Yakındaki Camiler
- Aylık Namaz Vakitleri
- Kaza Takibi
- Dinî Gün ve Geceler

Hesap ve tercihler:

- Profilim veya Giriş Yap
- Abonelik Sorgulama
- Tema Ayarları
- Ayarlar
- Konum Ayarları
- Widget Ayarları
- Oturum açıksa Çıkış Yap

### 2.3 Üst menü ve geri hareketi

- Ev simgesi ana sayfaya döndürür.
- Geri oku önceki ekrana döndürür.
- Desteklenen ekranlarda soldan sağa geri kaydırma hareketi kullanılabilir.
- Üç nokta veya ayar simgesi, açık içeriğe özel seçenekleri gösterir.
- Uygulama içindeki mini oynatıcı, başka sayfalarda gezinirken aktif sesi kontrol etmeye yarar.

---

## 5. Ana sayfa

### 5.1 Ana sayfadaki bölümler

Sunucu içeriğine ve kullanıcı düzenine göre ana sayfada şunlar bulunabilir:

- Hikâyeler ve duyurular
- Günlük Takvim/namaz vakti kartı
- Hızlı kısayollar
- Canlı yayınlar
- Hava durumu
- Adım sayar
- Okumaya/dinlemeye devam et
- Dergiler
- Keşfet içerikleri
- Yayınevleri
- Son veya yeni kitaplar
- Diğer uygulamalar

### 5.2 Hikâyeleri kullanma

- Üstteki dairesel hikâye kapağına dokunarak hikâyeyi tam ekran açın.
- Ekranın sağ/sol tarafına dokunarak sonraki/önceki içeriğe geçin.
- Parmağınızı ekranda basılı tutarak ilerlemeyi geçici durdurun.
- Bir hikâye birden çok görsel veya video içerebilir.
- Bağlantı düğmesi varsa ilgili web sayfası veya uygulama bölümü açılır.
- Görüntülenen hikâyeler görüldü olarak işaretlenebilir.

### 5.3 Ana sayfa Takvim kartı

- Seçili konumun vakitlerini ve sıradaki vakte kalan süreyi gösterir.
- Sağ/sol hareket veya oklarla başka güne geçilebilir.
- Geçmiş/gelecek gündeyken **Bugün** ile güncel tarihe dönülür.
- Konum adına dokunmak konum ayarlarını açabilir.
- Kartın ayrıntı alanına dokunmak Takvim ekranını açar.

### 5.4 Okumaya devam et

Başlanan Kur'an, kitap, dergi veya Delâil içerikleri son konumlarıyla bu alanda gösterilebilir. Karta dokunulduğunda içerik, kaydedilen sayfa/bölüm/konumdan açılır. İçerik silinmişse yeniden indirme gerekebilir.

### 5.5 Ana sayfayı düzenleme

Menü yolu: **Menü > Ayarlar > Ana Sayfayı Düzenle**

- Bölümleri sürükleme tutamacından tutup yukarı/aşağı taşıyarak sıralayın.
- Hava durumu ve adım sayar bölümlerini anahtarla gösterin veya gizleyin.
- Hikâyeler, Takvim, kısayollar ve içerik rafları gibi zorunlu bölümlerin sırası değiştirilebilir; bunların gizleme anahtarı yoktur.
- Sağ üstteki sıfırlama simgesi varsayılan sırayı geri getirir; hava durumunu gösterir, adım sayarı varsayılan olarak gizler.