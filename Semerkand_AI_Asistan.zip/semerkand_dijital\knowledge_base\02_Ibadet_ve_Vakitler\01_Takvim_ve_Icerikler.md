## 6. Takvim ve günlük içerikler

### 6.1 Takvim ekranı

- Seçili günün miladî ve hicrî tarihini gösterir.
- Günler arasında kaydırarak veya tarih seçiciyi kullanarak gezinebilirsiniz.
- Sabah, Güneş, Öğle, İkindi, Akşam ve Yatsı vakitleri gösterilir.
- Sıradaki vakit ve kalan süre üst alanda izlenebilir.
- Bir vakte dokunmak ilgili hatırlatıcı ayarını açabilir.
- Günün ayeti, hadisi, sözü, duası, tarihte bugün ve takvim yaprağı gibi kartlar veri mevcutsa gösterilir.
- Paylaş simgesi olan içerik metin veya görsel olarak paylaşılabilir.
- Daha önce indirilen gün/vakit verileri internet olmadan görüntülenebilir.

### 6.2 Günlük sözü beğenme ve paylaşma

- Günün Sözü kartındaki kalp simgesine dokunarak sözü kaydedin.
- Kayıtlı sözlere Takvim araçlarındaki **Beğenilen Sözler** ekranından ulaşın.
- Burada sözü paylaşabilir, kopyalayabilir veya listeden kaldırabilirsiniz.
- Görsel paylaşımda mevcut tasarım/arka plan seçeneklerinden birini seçebilirsiniz. Bazı tasarımlar ücretsiz, bazıları ücretli olabilir; satın alma öncesi gösterilen fiyat ve onayı esas alın.

### 6.3 Aylık namaz vakitleri

Menü yolu: **Menü > Aylık Namaz Vakitleri**

- Seçili ayın günleri ve vakitleri tablo halinde görünür.
- Önceki/sonraki aya geçilebilir.
- Bugünün satırı vurgulanır.
- Üstteki konum bilgisinden hangi yerin vakitlerinin gösterildiği kontrol edilir.

### 6.4 Dinî gün ve geceler

Menü yolu: **Menü > Dinî Gün ve Geceler**

- Kandil, bayram ve önemli hicrî tarihler yıl bazında listelenir.
- Yıl değiştirerek başka bir dönemi görüntüleyebilirsiniz.
- Yaklaşan günler görsel olarak öne çıkarılabilir.

### 6.5 Kaza namazı takibi

Menü yolu: **Menü > Kaza Takibi**

Bu özellik oturum açmayı ister.

- Sabah, Öğle, İkindi, Akşam, Yatsı ve Vitir için kalan sayıları ayrı takip edin.
- Artı/eksi düğmeleriyle sayıları güncelleyin.
- Toplu hesaplamada yıl, ay ve gün bilgisi girerek tahmini toplam oluşturun.
- İsterseniz yalnız seçtiğiniz vakitleri hesaplamaya dahil edin.
- Kaydetmeden önce sonucu kontrol edin.
- Giriş yapıldığında bilgiler hesaba eşitlenebilir ve başka cihazda sürdürülebilir.