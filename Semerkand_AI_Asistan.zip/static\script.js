const form = document.getElementById('chat-form');
const input = document.getElementById('user-input');
const sendBtn = document.getElementById('send-btn');
const chatContainer = document.getElementById('chat-container');

// Sohbet geçmişini tutan dizi (Hafıza)
let chatHistory = [];

input.addEventListener('input', function() {
    this.style.height = 'auto';
    this.style.height = (this.scrollHeight) + 'px';
    sendBtn.disabled = this.value.trim() === '';
});

input.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        if (!sendBtn.disabled) form.dispatchEvent(new Event('submit'));
    }
});

function appendMessage(role, content) {
    const msgDiv = document.createElement('div');
    msgDiv.className = `message ${role}`;
    
    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    contentDiv.innerHTML = role === 'assistant' ? content : marked.parse(content);
    
    if (role === 'assistant') {
        const avatarDiv = document.createElement('div');
        avatarDiv.className = 'avatar robot-avatar state-welcome';
        // Animasyonlu Logo Avatarı
        avatarDiv.innerHTML = `
            <img src="/static/logo.webp" alt="AI Logo" class="robot-logo">
        `;
        msgDiv.appendChild(avatarDiv);
    }
    
    msgDiv.appendChild(contentDiv);
    chatContainer.appendChild(msgDiv);
    scrollToBottom();
    return contentDiv;
}

function scrollToBottom() {
    chatContainer.scrollTop = chatContainer.scrollHeight;
}

form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const message = input.value.trim();
    if (!message) return;

    appendMessage('user', message);
    
    // Geçmişin sadece son 10 mesajını gönder (Çok şişmemesi için)
    const recentHistory = chatHistory.slice(-10);
    
    // Kullanıcının yeni sorusunu hafızaya ekle
    chatHistory.push({ role: 'user', content: message });
    
    input.value = '';
    input.style.height = 'auto';
    sendBtn.disabled = true;

    const typingIndicatorHTML = `
        <div class="typing-indicator">
            <span></span>
            <span></span>
            <span></span>
        </div>
    `;
    const assistantContentDiv = appendMessage('assistant', typingIndicatorHTML);
    // Yeni eklenen asistanın avatar div'ini bul
    const activeAvatar = assistantContentDiv.previousElementSibling;
    if (activeAvatar) {
        activeAvatar.className = 'avatar robot-avatar state-thinking';
    }
    
    let fullResponse = '';

    try {
        const response = await fetch('/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: message, history: recentHistory })
        });

        if (!response.ok) throw new Error('API Hatası');

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        assistantContentDiv.innerHTML = '';

        if (activeAvatar) {
            // Yanıt gelmeye başladığında 'yazıyor' state'ine geç
            activeAvatar.className = 'avatar robot-avatar state-typing';
        }

        while (true) {
            const { value, done } = await reader.read();
            if (done) {
                // Tamamlandığında welcome (gülümseme) state'ine geç
                if (activeAvatar) {
                    activeAvatar.className = 'avatar robot-avatar state-welcome';
                }
                break;
            }
            
            const text = decoder.decode(value);
            const lines = text.split('\n\n');
            
            for (const line of lines) {
                if (line.startsWith('data: ')) {
                    const data = line.slice(6);
                    if (data === '[DONE]') break;
                    
                    try {
                        const parsed = JSON.parse(data);
                        if (parsed.error) {
                            fullResponse += `\n**Hata:** ${parsed.error}`;
                        } else if (parsed.text) {
                            fullResponse += parsed.text;
                        }
                        assistantContentDiv.innerHTML = marked.parse(fullResponse);
                        scrollToBottom();
                    } catch (e) {
                        console.error('JSON Parse error', e, data);
                    }
                }
            }
        }
        
        // Asistanın cevabını hafızaya ekle
        if (fullResponse) {
            chatHistory.push({ role: 'assistant', content: fullResponse });
        }
        
    } catch (error) {
        assistantContentDiv.innerHTML = marked.parse('**Bir bağlantı hatası oluştu.** Lütfen tekrar deneyin.');
    }
});
