## 22. Bildirimler

- Bildirimler ekranı duyuru ve içerik bildirimlerini listeler.
- Okunmamış kayıtlar farklı işaretlenir.
- Bildirime dokunmak onu okundu yapar ve bağlantısı varsa ilgili içeriği açar.
- **Tümünü Okundu Yap** bütün okunmamış işaretlerini temizler.
- Kayıt kaydırılarak silinebilir.
- Uzun metin **Devamı/Daha az** ile genişletilip daraltılabilir.
- Görseli olan bildirimlerde görsel kartta gösterilir.

Bildirim alamıyorsanız cihazın `Ayarlar > Uygulamalar > Semerkand Dijital > Bildirimler` bölümünü kontrol edin. Namaz hatırlatıcısı, indirme, genel duyuru ve diğer bildirim kanalları Android'de ayrı ayrı kapatılmış olabilir.

---

## 26. Widget'lar ve Android bildirim çubuğu

Menü yolu: **Ana Sayfa > Yan Menü (sol üstteki 3 çizgi) > Hesap Ve Tercihler > Widget Ayarları**

Bu ekranda ilk olarak **Bildirim Çubuğu** seçeneği yer alır (Bildirim çubuğunda uygulamanın gösterilmesi için cihaz izinlerinin kontrol edilmesi gerekir).

### 26.1 Galeride platforma göre şu widget'lar bulunabilir:

- **Namaz Vakitleri Widget'ları:**
  - Tam namaz vakitleri (4x2)
  - Şeffaf veya kare vakit görünümü (Şeffaf 4x1, Kare 1x1)
  - Orta/küçük/kompakt namaz vakti (Orta 2x2, Küçük 2x1)
- **Kur'an ilerlemesi** (Kur'an-ı Kerim 4x1)
- **Delâilü'l-Hayrât ilerlemesi** (Delâilü'l-Hayrât 4x1)
- **Günün Sözü** (4x1)

### 26.2 Widget Ekleme ve Özelleştirme

Listedeki her widget kartında **"Ekle"** ve **"Ayarlar (Çark)"** butonları bulunur.

**Widget Ekleme:**
- Android'de desteklenen sürümlerde karttaki **Ekle** düğmesi sabitleme ekranını açabilir. Olmazsa ana ekrana uzun basın, **Widget'lar > Semerkand Dijital** yolunu izleyin.
- iPhone/iPad'de ana ekrana uzun basın, düzenleme/`+` menüsünü açın, Semerkand Dijital'i bulup boyutu seçin.

**Widget Özelleştirme (Ayarlar Butonu):**
- Canlı ön izlemeyi kontrol edin.
- Arka plan (Zemin), metin (Yazı) ve vurgu rengini seçin.
- Arka plan (Zemin) saydamlığını ayarlayın.
- Tüm ayarları yaptıktan sonra en alttaki **"Ayarları Kaydet ve Widget'ları Güncelle"** butonuna basmanız gerekir. Kaydedince mevcut widget yenilenir.
- Her widget türünün ayarı ayrı tutulabilir.

Widget güncellenmiyorsa uygulamayı açıp vakit/konum verisini yenileyin, widget'ı kaldırıp yeniden ekleyin ve işletim sisteminin arka plan kısıtlamalarını kontrol edin.

---

## 28. Hava durumu ve adım sayar

### 28.1 Hava durumu

- Ana sayfa kartında sıcaklık ve genel durum görünür.
- Kartı açarak saatlik/günlük tahmini inceleyin.
- Veri varsa hissedilen sıcaklık, nem, rüzgâr ve yağış gösterilir.
- Takvim için seçilen konumu kullanır.
- Güncel tahmin internet ister; kısa süre son alınan veri gösterilebilir.
- Kartı `Ayarlar > Ana Sayfayı Düzenle` bölümünden gizleyebilirsiniz.

### 28.2 Adım sayar

- Günlük adım sayısını ana sayfada gösterir.
- Karta dokunarak günlük, haftalık ve aylık raporları/grafikleri açın.
- Android'de fiziksel aktivite ve bazı cihazlarda Health Connect; iOS'ta Apple Health/hareket izni gerekir.
- İzin verilmez veya cihaz veri sağlamazsa adım gösterilemez.
- Kart varsayılan olarak gizli olabilir; `Ayarlar > Ana Sayfayı Düzenle` bölümünden açın.