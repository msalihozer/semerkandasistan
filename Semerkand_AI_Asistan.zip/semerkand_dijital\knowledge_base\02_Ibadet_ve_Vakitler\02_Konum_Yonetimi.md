## 7. Konum yönetimi

Menü yolu: **Menü > Konum Ayarları**

### 7.1 Yeni veya mevcut konumu kullanma

- **Mevcut Konumumu Kullan** ile GPS üzerinden konum tespiti yapılır.
- Manuel yöntemde ülke, şehir/il ve ilçe seçilir.
- Konum kaydedildiğinde namaz vakitleri indirilir; takvim, hava durumu, kıble ve hatırlatıcılar yeni konuma göre yenilenir.

### 7.2 Kayıtlı konumlar

- Daha önce indirilmiş konumları kayıtlı konumlar listesinden görüntüleyebilirsiniz.
- Bir konumu **aktif** yaparak uygulamanın o konumu kullanmasını sağlayabilirsiniz.
- Yenile simgesiyle seçili konumun vakit verilerini güncelleyebilirsiniz.
- Kullanmadığınız konumun indirilmiş verilerini silebilirsiniz.
- Aktif konum silinirse uygulama, kalan uygun konumlardan birine geçebilir; son ekrandaki aktif konumu kontrol edin.

### 7.3 Otomatik konum güncelleme seçenekleri

Konum ayarlarında cihaz desteğine göre şu modlar bulunabilir:

- **Her zaman otomatik:** Uygulama belirlenen aralıklarla ve konum değişimine göre kontrol yapar; arka plan konum izni gerekir.
- **Uygulama açıldığında:** Konum yalnız uygulama kullanılırken güncellenir.
- **Kapalı:** Seçili konum siz değiştirene kadar sabit kalır.

Kontrol aralığı ve konum değişikliği mesafesi ayarlanabilir. Konum değiştiğinde bildirim alma seçeneği ayrıca açılıp kapatılabilir.