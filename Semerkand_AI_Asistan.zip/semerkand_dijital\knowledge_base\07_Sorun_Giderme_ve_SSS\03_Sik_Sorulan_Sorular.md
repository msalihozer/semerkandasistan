## 34. Sık sorulan sorular ve kısa yanıtlar

### “Uygulamayı üye olmadan kullanabilir miyim?”

Takvim, konum, namaz vakitleri ve bazı genel içerikler üyeliksiz kullanılabilir. Kaza takibi, kişisel kitaplık, Hatim, bazı Kur'an/Delâil deneyimleri, eşitleme ve destek gibi kişisel alanlar giriş ister.

### “İnternet olmadan namaz vakitlerine bakabilir miyim?”

Evet. Konumun vakit verileri daha önce indirilmişse çevrimdışı görüntülenebilir. Yeni konum eklemek veya veriyi yenilemek için internet gerekir.

### “Konum izni vermeden kullanabilir miyim?”

Evet. İlk kurulumda veya Konum Ayarları'nda ülke, şehir ve ilçeyi elle seçebilirsiniz. Kıble/yakındaki camiler gibi anlık konum isteyen özellikler sınırlanabilir.

### “Ana sayfadaki adım sayarı nasıl açarım?”

`Menü > Ayarlar > Ana Sayfayı Düzenle` yolunda Adım Sayar anahtarını açın; sonra istenen fiziksel aktivite/sağlık iznini verin.

### “Kur'an sesini neden duyamıyorum?”

Önce `Kur'an > Hafız Sesleri`nden seçtiğiniz hafızın paketini indirin ve aktif yapın. Medya ses düzeyini ve Bluetooth çıkışını da kontrol edin.

### “Kaldığım Kur'an sayfasına nasıl dönerim?”

`Kur'an > Kur'an-ı Kerîm` ekranında **Kaldığın Sayfa/Devam Et** kartına dokunun. Ana sayfadaki **Devam Et** kartı veya Kur'an ilerleme widget'ı da aynı konuma götürebilir.

### “Hatim grubuna nasıl katılırım?”

Giriş yaptıktan sonra `Kur'an > Hatim > Gruplar` bölümünü açın, **Davet koduyla katıl** seçeneğine size gönderilen kodu yazın.

### “Dergiyi çevrimdışı nasıl okurum?”

Dergi detayında **İndir** düğmesine dokunun. İndirme tamamlanınca `Dergiler > İndirilenler` bölümünden açın. Sayının erişim koşuluna göre giriş veya abonelik gerekebilir.

### “Uygulamanın temasını nasıl değiştiririm?”

`Menü > Tema Ayarları` veya `Menü > Ayarlar > Tema` yolunu açın; açık, koyu ya da sistem modunu ve isterseniz vurgu rengini seçin.

### “Dili nasıl değiştiririm?”

`Menü > Ayarlar > Dil` bölümünden Sistem Dili, Türkçe, İngilizce, Almanca, Fransızca veya Arapça seçin.

### “Duvar kâğıdını iPhone'da neden doğrudan uygulayamıyorum?”

iOS üçüncü taraf uygulamaların duvar kâğıdını doğrudan değiştirmesine izin vermez. Görseli Fotoğraflar'a kaydedin, ardından iPhone Ayarları'ndaki Duvar Kâğıdı bölümünden seçin.

### “Okuma süremi nereden görürüm?”

Kur'an veya Delâil okuyucusunun menü/ayarından **Okuma İstatistikleri**ni açın; gün, hafta, ay, tüm zamanlar veya özel tarih aralığını seçin.

### “Destek ekibine nasıl ulaşırım?”

Giriş yaptıktan sonra `Menü > Ayarlar > Destek > Yeni destek talebi` yolunu izleyin. Kategori, konu ve açıklamayı doldurup gönderin.

### “Uygulama sürümünü nereden görürüm?”

`Menü > Ayarlar` ekranının alt bölümünde sürüm numarası gösterilir.