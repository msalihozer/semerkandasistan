# Semerkand Dijital AI Asistanı — Uygulama Kullanım Bilgi Tabanı

> Doküman türü: Son kullanıcı kullanım rehberi ve AI asistanı bilgi kaynağı  
> İncelenen uygulama sürümü: **3.0.1 (2080)**  
> Son kod inceleme tarihi: **23 Eylül 2026**  
> Platformlar: Android ve iPhone/iPad; belirtilen saat özellikleri Android/Wear OS ve Apple Watch desteğine göre değişebilir.

## 0. AI asistanı için kullanım talimatı

Bu dosya, Semerkand Dijital'in kullanımıyla ilgili kullanıcı sorularını yanıtlamak için hazırlanmıştır. Yanıt verirken aşağıdaki kuralları uygula:

1. Önce kullanıcının amacını belirle; sonra bu dosyadaki ilgili ekran ve işlemi kısa, sıralı adımlarla anlat.
2. Menü yolu biliniyorsa `Menü > Ayarlar > ...` biçiminde belirt.
3. Özelliğin üyelik, abonelik, internet, indirme veya cihaz izni gerektirdiğini ilgili adımda açıkça söyle.
4. Android ve iOS davranışları farklıysa platforma göre ayrı yanıt ver. Kullanıcının platformu belli değilse iki durumu da kısaca açıkla.
5. Dinamik içerik adları, ücretler, kampanyalar, güncel yayınlar ve mağaza ürünleri bu dosyada sabit kabul edilmez. Uygulamada görünen güncel bilgiyi esas al.
6. Bu dosyada doğrulanmayan ödeme iadesi, kişisel veri, fetva, dini hüküm veya kesin teknik çözüm üretme. Gerekirse kullanıcıyı `Menü > Ayarlar > Destek` yoluna yönlendir.
7. Bir ekran görünmüyorsa olası nedenleri şu sırayla kontrol ettir: uygulama sürümü, oturum, abonelik, internet, cihaz/platform desteği ve gerekli izinler.
8. Kullanıcıya geliştirici terimleri, rota adları veya API ayrıntıları verme. Ekranda görünen adları kullan.
9. Silme, hesabı kapatma, indirmeleri kaldırma veya gruptan ayrılma gibi işlemlerde sonucun geri alınamayabileceğini belirt ve ekrandaki onayı dikkatle okumasını öner.
10. Yanıtı gereksiz ayrıntıyla uzatma; fakat kullanıcının istediği işlem için gereken ön koşul, menü yolu ve sonuç mutlaka bulunsun.

## 1. Uygulamaya genel bakış

Semerkand Dijital; takvim ve namaz vakitleri, Kur'an-ı Kerîm, dijital kitap ve dergiler, Delâilü'l-Hayrât, hatim, ilahi/radyo içerikleri ve kişisel ibadet yardımcılarını tek uygulamada birleştirir.

Uygulamada yapılabilen temel işlemler:

- Seçilen konuma göre günlük ve aylık namaz vakitlerini görmek.
- Bir sonraki vakte kalan süreyi takip etmek ve vakit hatırlatıcıları kurmak.
- Günün ayeti, hadisi, sözü, duası ve tarihî içeriklerini okumak ve paylaşmak.
- Kıble yönünü pusula veya harita üzerinden bulmak; yakındaki camileri görmek.
- Kaza namazı sayılarını takip etmek ve dinî günleri incelemek.
- Kur'an'ı klasik mushaf, gelişmiş metin görünümü veya mealli görünümle okumak.
- Hafız seslerini indirip Kur'an dinlemek, Kur'an TV ve Mukabele kullanmak.
- Hatim grubu oluşturmak, gruba katılmak, cüz almak ve ilerleme kaydetmek.
- Kitap ve dergi keşfetmek, okumak, dinlemek, favorilere veya kişisel listelere eklemek.
- Delâilü'l-Hayrât'ı klasik sayfa veya açıklamalı/dinamik görünümde okumak ve dinlemek.
- İlahi Radyo, ilahi albümleri ve canlı yayınları dinlemek/izlemek.
- Hava durumu, adım sayar, okuma istatistikleri, widget ve bağlı saat özelliklerini kullanmak.
- Duvar kâğıtlarını incelemek, uygun olanları indirmek/satın almak ve cihaza uygulamak.
- Uygulama içinden destek talebi açmak ve yanıtları takip etmek.

## 2. Hızlı erişim ve gezinme

### 2.1 Alt menü

Ekranın altındaki ana menüde şu bölümler bulunur:

- **Kitaplar**
- **Dergiler**
- Ortadaki yuvarlak **Ana Sayfa** düğmesi
- **Kur'an**
- **Delâil**

Bir ana bölüm düğmesine dokunmak o bölümün giriş sayfasını açar. Okuyucu, oynatıcı ve bazı ayrıntı ekranlarında alt menü görünmeyebilir; geri düğmesiyle önceki ekrana dönülür.

### 2.2 Yan menü

Sol üstteki menü simgesi yan menüyü açar. Buradan ana modüllere, Takvim araçlarına, profil/giriş, abonelik sorgulama, tema, ayarlar, konum ve widget sayfalarına ulaşılır. Bağlı bir saat algılanmışsa saat kartı da menüde gösterilebilir.

Ana modüller:

- Ana Sayfa
- Takvim
- Kitaplar
- Dergiler
- Kur'an
- Delâilü'l-Hayrât
- Bazı sürüm/düzenlerde Duvar Kâğıtları

Takvim araçları:

- Hatırlatıcılar
- Kıble Pusulası
- Yakındaki Camiler
- Aylık Namaz Vakitleri
- Kaza Takibi
- Dinî Gün ve Geceler

Hesap ve tercihler:

- Profilim veya Giriş Yap
- Abonelik Sorgulama
- Tema Ayarları
- Ayarlar
- Konum Ayarları
- Widget Ayarları
- Oturum açıksa Çıkış Yap

### 2.3 Üst menü ve geri hareketi

- Ev simgesi ana sayfaya döndürür.
- Geri oku önceki ekrana döndürür.
- Desteklenen ekranlarda soldan sağa geri kaydırma hareketi kullanılabilir.
- Üç nokta veya ayar simgesi, açık içeriğe özel seçenekleri gösterir.
- Uygulama içindeki mini oynatıcı, başka sayfalarda gezinirken aktif sesi kontrol etmeye yarar.

## 3. Gereksinimler özeti

| Özellik | İnternet | Oturum | Abonelik/ödeme | Cihaz izni veya ek koşul |
|---|---|---|---|---|
| Daha önce indirilmiş namaz vakitleri | Gerekmez | Gerekmez | Gerekmez | Konum daha önce seçilmiş olmalı |
| Yeni konum/vakit verisi | Gerekir | Gerekmez | Gerekmez | GPS seçilirse konum izni |
| Kıble pusulası | Genelde gerekmez | Gerekmez | Gerekmez | Konum ve cihaz yön sensörü |
| Yakındaki camiler | Gerekebilir | Gerekmez | Gerekmez | Konum izni |
| Namaz hatırlatıcıları | Kurulum/veri yenilemede gerekebilir | Gerekmez | Gerekmez | Bildirim; Android'de ek alarm/pil izinleri olabilir |
| Kaza takibi | Eşitleme için gerekir | **Gerekir** | Gerekmez | — |
| Kur'an modüllerinin çoğu | İndirme/medya için gerekir | Birçok deneyimde **gerekir** | İçeriğe göre değişebilir | Ses için hafız paketi |
| Hatim ve cüz işlemleri | Gerekir | **Gerekir** | Gerekmez | Bildirim isteğe bağlı |
| Kitaplık | Liste/eşitleme için gerekir | **Gerekir** | İçeriğe göre değişebilir | İndirme için depolama alanı |
| Dergi okuma | Çevrimdışı indirme sonrası gerekmez | İçeriğe göre gerekir | Bazı sayılarda **gerekir** | İndirme için depolama alanı |
| Delâilü'l-Hayrât | İlk paket/ses indirmede gerekir | **Gerekebilir** | İçeriğe göre değişebilir | Depolama alanı |
| Canlı radyo/video | **Gerekir** | İçeriğe göre değişebilir | İçeriğe göre değişebilir | Arka plan medya izni/servisi platforma bağlıdır |
| Hava durumu | Güncellemek için gerekir | Gerekmez | Gerekmez | Seçilmiş konum |
| Adım sayar | Eşitlemeye göre değişir | Gerekmez | Gerekmez | Hareket/Health Connect/Apple Health izni |
| Duvar kâğıdı | Liste, indirme ve satın alma için gerekir | İçeriğe göre değişebilir | Ücretli üründe gerekir | Galeri/fotoğraf izni platforma bağlıdır |
| Destek talepleri | **Gerekir** | **Gerekir** | Gerekmez | — |

## 4. İlk açılış ve kurulum

### 4.1 Kurulum sihirbazı

Mobil cihazda ilk açılışta ihtiyaçlara göre şu adımlar gösterilebilir:

1. **Bildirim izni:** Namaz vakti, hatim, destek yanıtı ve uygulama duyurularını göstermek için kullanılır.
2. **Adım sayar/aktivite izni:** Android'de fiziksel aktivite ve gerekirse Health Connect; iOS'ta sağlık/hareket verisi erişimi istenir. Bu adım atlanabilir.
3. **Konum:** Otomatik GPS veya ülke/şehir/ilçe seçimiyle namaz vakitleri hazırlanır.
4. **Hatırlatıcı hazırlığı:** Android'de ekran üstü gösterim veya pil optimizasyonu gibi gerekli sistem ayarları gösterilebilir. Bu kurulum daha sonra da yapılabilir.
5. **Hatırlatılacak vakitlerin seçimi:** Bildirim izni verildiyse ilk vakit tercihleri seçilebilir.
6. **Giriş:** Hesaba giriş yapılabilir veya giriş adımı atlanarak uygulamaya devam edilebilir.

İlk kurulumda atlanan izinler daha sonra ilgili özellik açıldığında veya cihazın Ayarlar uygulamasından verilebilir.

### 4.2 Konumu otomatik belirleme

1. Konum adımında otomatik konum seçeneğini açın.
2. İstenirse “Uygulamayı kullanırken” konum izni verin.
3. Arka planda konum güncellemesi isteniyorsa ve cihaz destekliyorsa “Her zaman” izni ayrıca istenebilir.
4. Uygulamanın konumu bulmasını ve namaz vakti verisini indirmesini bekleyin.
5. İşlem tamamlanınca ana sayfada konum adı ve vakitler görünür.

### 4.3 Konumu elle belirleme

1. Manuel konum seçimini açın.
2. Önce **Ülke**, sonra **Şehir/İl**, varsa **İlçe** seçin.
3. Kaydet veya devam düğmesine dokunun.
4. Namaz vakti verisi indirilirken ekrandan çıkmadan işlemin tamamlanmasını bekleyin.

Konum izni vermek istemeyen kullanıcılar manuel seçimle uygulamanın temel takvim özelliklerini kullanabilir.

## 5. Ana sayfa

### 5.1 Ana sayfadaki bölümler

Sunucu içeriğine ve kullanıcı düzenine göre ana sayfada şunlar bulunabilir:

- Hikâyeler ve duyurular
- Günlük Takvim/namaz vakti kartı
- Hızlı kısayollar
- Canlı yayınlar
- Hava durumu
- Adım sayar
- Okumaya/dinlemeye devam et
- Dergiler
- Keşfet içerikleri
- Yayınevleri
- Son veya yeni kitaplar
- Diğer uygulamalar

### 5.2 Hikâyeleri kullanma

- Üstteki dairesel hikâye kapağına dokunarak hikâyeyi tam ekran açın.
- Ekranın sağ/sol tarafına dokunarak sonraki/önceki içeriğe geçin.
- Parmağınızı ekranda basılı tutarak ilerlemeyi geçici durdurun.
- Bir hikâye birden çok görsel veya video içerebilir.
- Bağlantı düğmesi varsa ilgili web sayfası veya uygulama bölümü açılır.
- Görüntülenen hikâyeler görüldü olarak işaretlenebilir.

### 5.3 Ana sayfa Takvim kartı

- Seçili konumun vakitlerini ve sıradaki vakte kalan süreyi gösterir.
- Sağ/sol hareket veya oklarla başka güne geçilebilir.
- Geçmiş/gelecek gündeyken **Bugün** ile güncel tarihe dönülür.
- Konum adına dokunmak konum ayarlarını açabilir.
- Kartın ayrıntı alanına dokunmak Takvim ekranını açar.

### 5.4 Okumaya devam et

Başlanan Kur'an, kitap, dergi veya Delâil içerikleri son konumlarıyla bu alanda gösterilebilir. Karta dokunulduğunda içerik, kaydedilen sayfa/bölüm/konumdan açılır. İçerik silinmişse yeniden indirme gerekebilir.

### 5.5 Ana sayfayı düzenleme

Menü yolu: **Menü > Ayarlar > Ana Sayfayı Düzenle**

- Bölümleri sürükleme tutamacından tutup yukarı/aşağı taşıyarak sıralayın.
- Hava durumu ve adım sayar bölümlerini anahtarla gösterin veya gizleyin.
- Hikâyeler, Takvim, kısayollar ve içerik rafları gibi zorunlu bölümlerin sırası değiştirilebilir; bunların gizleme anahtarı yoktur.
- Sağ üstteki sıfırlama simgesi varsayılan sırayı geri getirir; hava durumunu gösterir, adım sayarı varsayılan olarak gizler.

## 6. Takvim ve günlük içerikler

### 6.1 Takvim ekranı

- Seçili günün miladî ve hicrî tarihini gösterir.
- Günler arasında kaydırarak veya tarih seçiciyi kullanarak gezinebilirsiniz.
- Sabah, Güneş, Öğle, İkindi, Akşam ve Yatsı vakitleri gösterilir.
- Sıradaki vakit ve kalan süre üst alanda izlenebilir.
- Bir vakte dokunmak ilgili hatırlatıcı ayarını açabilir.
- Günün ayeti, hadisi, sözü, duası, tarihte bugün ve takvim yaprağı gibi kartlar veri mevcutsa gösterilir.
- Paylaş simgesi olan içerik metin veya görsel olarak paylaşılabilir.
- Daha önce indirilen gün/vakit verileri internet olmadan görüntülenebilir.

### 6.2 Günlük sözü beğenme ve paylaşma

- Günün Sözü kartındaki kalp simgesine dokunarak sözü kaydedin.
- Kayıtlı sözlere Takvim araçlarındaki **Beğenilen Sözler** ekranından ulaşın.
- Burada sözü paylaşabilir, kopyalayabilir veya listeden kaldırabilirsiniz.
- Görsel paylaşımda mevcut tasarım/arka plan seçeneklerinden birini seçebilirsiniz. Bazı tasarımlar ücretsiz, bazıları ücretli olabilir; satın alma öncesi gösterilen fiyat ve onayı esas alın.

### 6.3 Aylık namaz vakitleri

Menü yolu: **Menü > Aylık Namaz Vakitleri**

- Seçili ayın günleri ve vakitleri tablo halinde görünür.
- Önceki/sonraki aya geçilebilir.
- Bugünün satırı vurgulanır.
- Üstteki konum bilgisinden hangi yerin vakitlerinin gösterildiği kontrol edilir.

### 6.4 Dinî gün ve geceler

Menü yolu: **Menü > Dinî Gün ve Geceler**

- Kandil, bayram ve önemli hicrî tarihler yıl bazında listelenir.
- Yıl değiştirerek başka bir dönemi görüntüleyebilirsiniz.
- Yaklaşan günler görsel olarak öne çıkarılabilir.

### 6.5 Kaza namazı takibi

Menü yolu: **Menü > Kaza Takibi**

Bu özellik oturum açmayı ister.

- Sabah, Öğle, İkindi, Akşam, Yatsı ve Vitir için kalan sayıları ayrı takip edin.
- Artı/eksi düğmeleriyle sayıları güncelleyin.
- Toplu hesaplamada yıl, ay ve gün bilgisi girerek tahmini toplam oluşturun.
- İsterseniz yalnız seçtiğiniz vakitleri hesaplamaya dahil edin.
- Kaydetmeden önce sonucu kontrol edin.
- Giriş yapıldığında bilgiler hesaba eşitlenebilir ve başka cihazda sürdürülebilir.

## 7. Konum yönetimi

Menü yolu: **Menü > Konum Ayarları**

### 7.1 Yeni veya mevcut konumu kullanma

- **Mevcut Konumumu Kullan** ile GPS üzerinden konum tespiti yapılır.
- Manuel yöntemde ülke, şehir/il ve ilçe seçilir.
- Konum kaydedildiğinde namaz vakitleri indirilir; takvim, hava durumu, kıble ve hatırlatıcılar yeni konuma göre yenilenir.

### 7.2 Kayıtlı konumlar

- Daha önce indirilmiş konumları kayıtlı konumlar listesinden görüntüleyebilirsiniz.
- Bir konumu **aktif** yaparak uygulamanın o konumu kullanmasını sağlayabilirsiniz.
- Yenile simgesiyle seçili konumun vakit verilerini güncelleyebilirsiniz.
- Kullanmadığınız konumun indirilmiş verilerini silebilirsiniz.
- Aktif konum silinirse uygulama, kalan uygun konumlardan birine geçebilir; son ekrandaki aktif konumu kontrol edin.

### 7.3 Otomatik konum güncelleme seçenekleri

Konum ayarlarında cihaz desteğine göre şu modlar bulunabilir:

- **Her zaman otomatik:** Uygulama belirlenen aralıklarla ve konum değişimine göre kontrol yapar; arka plan konum izni gerekir.
- **Uygulama açıldığında:** Konum yalnız uygulama kullanılırken güncellenir.
- **Kapalı:** Seçili konum siz değiştirene kadar sabit kalır.

Kontrol aralığı ve konum değişikliği mesafesi ayarlanabilir. Konum değiştiğinde bildirim alma seçeneği ayrıca açılıp kapatılabilir.

## 8. Namaz vakti hatırlatıcıları

Menü yolu: **Ana Sayfa > Hatırlatıcılar** veya **Menü > Hatırlatıcılar**

### 8.1 Hatırlatıcı oluşturma

1. İlgili vaktin anahtarını açın.
2. Vakit satırına dokunun.
3. Uyarının vakitten **önce**, **tam vaktinde** veya **sonra** çalışmasını seçin.
4. Önce/sonra seçildiğinde dakika değerini belirleyin.
5. Uyarı sesini ve ses düzeyini seçin.
6. Değişikliği kaydedin.

Her vakit birbirinden bağımsız ayarlanabilir. Cuma günü Öğle vakti için cihaz/sürüm desteğine göre farklı davranış seçeneği bulunabilir.

### 8.2 Ses seçimi

- Hazır seslerden biri seçilebilir ve kısa ön dinleme yapılabilir.
- İndirilebilir bir ses önce cihazda hazırlanmalıdır.
- Desteklenen cihazlarda kullanıcı kendi ses dosyasını seçebilir.
- Seçilen dosya silinirse uygulama varsayılan sese dönebilir.

### 8.3 Android'de gerekli ek ayarlar

Hatırlatıcıların zamanında ve görünür çalışması için cihaz sürümüne göre şunlar gerekebilir:

- Bildirim izni
- Kesin alarm izni
- Diğer uygulamaların üzerinde gösterme izni
- Rahatsız Etmeyin erişimi
- Pil optimizasyonundan çıkarma
- Üreticiye özel otomatik başlatma/arka plan çalışma izni

Kurulum ekranındaki eksik izin kartına dokunarak ilgili sistem ayarını açın. İzin adları telefon markasına göre değişebilir.

### 8.4 Kalıcı bildirim çubuğu

Android'de `Ayarlar > Widget ve Bildirim Çubuğu` bölümünden namaz vakti bildirim çubuğu açılabilir. Bildirimde sıradaki vakit, saati ve kalan süre gösterilebilir. Bildirim izni kapalıysa özellik çalışmaz.

## 9. Kıble pusulası ve yakındaki camiler

### 9.1 Kıble pusulası

Menü yolu: **Ana Sayfa > Kıble Pusulası** veya **Menü > Kıble Pusulası**

- Telefonu düz ve yere paralel tutun.
- Cihazı yavaşça çevirerek Kâbe/kıble işaretini hedefe hizalayın.
- Doğru yöne yaklaşınca görsel veya titreşimli geri bildirim alınabilir.
- Ekranda kıble açısı ve Kâbe'ye yaklaşık mesafe gösterilebilir.
- Harita seçeneği varsa kıble doğrultusunu harita üzerinde açabilirsiniz.

Pusula kararsızsa telefonu havada sekiz çizer gibi hareket ettirin. Mıknatıslı kılıfı çıkarın; metal masa, hoparlör ve güçlü elektronik cihazlardan uzaklaşın. Cihazda yön sensörü yoksa pusula kullanılamayabilir.

### 9.2 Yakındaki camiler

Menü yolu: **Menü > Yakındaki Camiler**

- Konuma yakın camiler mesafe bilgileriyle listelenir.
- Liste ve harita görünümü arasında geçiş yapılabilir.
- Cami kartı ad, adres ve uzaklık gibi ayrıntıları gösterir.
- Yol tarifi, cihazdaki uygun harita uygulamasını açar.
- Konum izni kapalıysa yakınlık sıralaması ve yol tarifi başlangıcı doğru çalışmayabilir.

## 10. Kur'an merkezi

Alt menüden **Kur'an** bölümünü açın. Kartların kullanılabilirliği oturum ve içerik erişimine göre değişebilir.

### 10.1 Kur'an ana menüsündeki seçenekler

- **Kur'an-ı Kerîm:** Klasik mushaf sayfa görünümü.
- **Kur'an-ı Mecîd:** Gelişmiş metin, meal, arama, ses ve otomatik kaydırma özellikli okuyucu.
- **Kur'an TV:** Hafız sesi eşliğinde ayetlerin ekranda aktığı deneyim.
- **Mukabele:** Cüz bazlı video içerikleri.
- **Hatim:** Genel hatim ve grup yönetimi.
- **Cüzlerim:** Üzerinize aldığınız cüzlere hızlı erişim.
- **Hatim Duası:** Metin ve indirilebilir ses.
- **Hafız Sesleri:** Kur'an ses paketlerini indirme ve seçme.
- **Elifba:** Kur'an alfabesi öğrenme içeriği; cihazda uygun uygulama/bağlantı üzerinden açılabilir.

### 10.2 Hafız seslerini indirme

Menü yolu: **Kur'an > Hafız Sesleri**

1. Hafız listesinden bir okuyucu seçin.
2. Varsa örnek sesi dinleyin.
3. Paket boyutunu kontrol edip **İndir** düğmesine dokunun.
4. İndirme ve hazırlama tamamlanana kadar bekleyin.
5. Paketi aktif hafız olarak seçin.

İndirme durdurulup daha sonra sürdürülebilir. İndirilen hafızlar listelenir ve kullanılmayan paket onayla silinebilir. Ses paketi olmayan bir hafızla dinleme başlatılırsa uygulama bu ekrana yönlendirebilir.

## 11. Klasik mushaf okuyucu

### 11.1 Giriş ekranı

- **Kaldığın Sayfa/Devam Et** son sayfa, cüz ve sureye götürür.
- **Yer İmleri** kayıtlı mushaf sayfalarını gösterir.
- Cüz, sure veya sayfa seçicisiyle yeni bir başlangıç yapılabilir.
- Bir bildirim, widget veya başka bölüm belirli sayfayı hedeflediyse okuyucu o sayfadan açılabilir.

### 11.2 Okuma işlemleri

- Sayfaları sağa/sola kaydırarak değiştirin.
- Uygun yatay düzende iki sayfa birlikte gösterilebilir.
- Üst alanda cüz, sayfa ve sure bilgilerini görün.
- Seçiciden cüz, sure veya sayfa numarasıyla doğrudan atlayın.
- Yer imi simgesiyle mevcut sayfayı kaydedin veya kaydı kaldırın.
- Tam ekranla araç çubuklarını gizleyin.
- Okuma imleci/takip bandını açıp satır üzerinde taşıyın; sunulan imleç görünümünü ayarlardan değiştirebilirsiniz.
- Ses düğmesiyle sayfayı aktif hafızdan dinleyin.
- Ekrandan çıkıldığında son sayfa otomatik kaydedilir.

### 11.3 Okuma istatistikleri

Okuyucunun menüsünden **Okuma İstatistikleri** ekranını açın. Gün, hafta, ay, tüm zamanlar veya özel tarih aralığı seçilebilir. Ekran toplam okuma süresi, okunan gün sayısı, günlük ortalama, en iyi gün, günlük grafik ve kayıt ayrıntılarını gösterir. Yenile simgesi yerel/hesap verisini günceller.

## 12. Kur'an-ı Mecîd gelişmiş okuyucu

- Ayetleri dikey ve kesintisiz metin akışında okuyun.
- Sayfa, cüz, sure ve ilerleme bilgisini takip edin.
- Başlıklara dokunarak cüz/sure/sayfa seçicilerini açın.
- Sayfa numarasını yazarak doğrudan sayfaya gidin.
- Sure arayın ve seçili ayete atlayın.
- Cüz içindeki hizb kısayollarını kullanın.
- İki parmakla Arapça metin boyutunu değiştirin.
- Meal görünümünü açıp kapatın.
- Ayete dokunarak o ayetten sesi başlatın, yer imi ekleyin veya paylaşın.
- Paylaşımda ayet, meal veya ikisini birlikte seçin.
- Otomatik kaydırmayı açıp hızını ayarlayın.
- Okuma perdesi/imleciyle belirli satırlara odaklanın.
- Farklı Arapça yazı tiplerini seçin; gerekli font paketi varsa indirin.
- Son sayfa ve sayfa içindeki yaklaşık konum çıkışta saklanır.
- Menüden Kur'an okuma istatistiklerini açabilirsiniz.

## 13. Mealli/metin Kur'an okuyucu

Mealli/metin okuyucu erişimi uygulama içindeki ilgili bağlantı veya yönlendirmeyle açılır ve üyelik isteyebilir.

- Son okunan sayfa/cüzden devam edilebilir.
- Cüz, sure veya sayfa üzerinden başlangıç konumu seçilebilir.
- Yer imleri kayıtlı ayet ve sayfalara götürür.
- Notlar, ayetlere eklenen kişisel notları listeler.
- Bir ayete dokununca Arapça, meal, sure, cüz ve sayfa bilgisini içeren ayrıntı açılır.
- Ayet ayrıntısından ses, yer imi, not ve komşu ayete geçiş işlemleri yapılabilir.
- İki parmakla yazı büyüklüğü ayarlanabilir.
- Çift dokunma tam ekranı açıp kapatabilir.
- Okuma zemini ve görünüm seçenekleri değiştirilebilir.
- Secde ayetleri listesinden ilgili ayete gidilebilir.
- Menüden okuma istatistikleri açılabilir.

## 14. Kur'an TV ve Mukabele

### 14.1 Kur'an TV

- Ayetleri seçili hafızın sesiyle sırayla oynatır.
- Yalnız ayet, yalnız meal veya ayet+meal görünümü seçilebilir.
- Arapça yazı tipi değiştirilebilir.
- Sure ve ayet seçerek istenen konumdan başlanabilir.
- Oynatma duraklatılıp sürdürülebilir.
- Gerekli hafız paketi yoksa önce indirme istenir.

### 14.2 Mukabele

- Listeden cüz videosu seçin.
- Daha önce izlenen cüzde kaldığınız yerden devam edin veya baştan başlayın.
- Oynat/duraklat ve zaman çizgisinden ileri/geri sarma kontrollerini kullanın.
- Tam ekranla yatay ve geniş görünümü açın.
- Ekrana dokunarak gizli kontrolleri yeniden gösterin.
- Hızlı cüz seçicisinden başka cüze geçin.
- İzleme konumuna ayraç ekleyin; ayraçtan aynı saniyeye dönün.
- Ayraçları cüz bazında görüntüleyin veya silin. Oturum açıkken eşitleme yapılabilir.

## 15. Hatim, cüzlerim ve Hatim Duası

### 15.1 Hatim ana ekranı

Hatim alanı oturum açmayı gerektirir. Sekmeler:

- **Genel Hatim:** Boş cüzü seçip onaylayarak üzerinize alın.
- **Gruplar:** Yeni grup oluşturun veya davet koduyla gruba katılın.
- **Cüzlerim:** Aldığınız cüzleri ve ilerlemeyi görün.

### 15.2 Hatim grubu

- Grup oluştururken ad ve isteğe bağlı bitiş tarihi girin.
- Davet kodunu kopyalayın veya paylaşın.
- Kodla mevcut gruba katılın.
- Yetkiniz varsa grup adı/bitiş tarihini düzenleyin, üyeleri ve cüz durumlarını görün.
- Grup yöneticisi grubu silebilir ve tüm cüzler bitince turu tamamlayıp yeni tura geçebilir.
- Üye gruptan ayrılabilir; aldığı cüzü bırakabilir.
- Grup veya cüzü etkileyen işlemlerde gösterilen onayı dikkatle kontrol edin.

### 15.3 Cüz okuma ve arşiv

- Cüzü klasik mushaf, Kur'an-ı Mecîd veya sunulan diğer okuyucuyla açın.
- İlerleme sayfa bazında kaydedilir; **Devam Et** son konuma döner.
- Cüz bitince **Tamamlandı** olarak işaretleyin.
- Tamamlanan cüzler arşivde tarih ve hatim bilgisiyle görüntülenebilir.
- Hatim/cüz hatırlatmaları açıksa bitiş tarihinden belirli süre önce bildirim alınabilir.

### 15.4 Hatim Duası

- Ses paketini indirin ve çevrimdışı dinleyin.
- İndirme yüzdesini takip edin.
- Oynat/duraklat ve zaman çizgisini kullanın.
- Geçen/toplam süre oynatıcıda gösterilir.

## 16. Kitaplar ve Kitaplığım

Kitaplar bölümü ve kişisel kitaplık oturum açmayı isteyebilir.

### 16.1 Kitap keşfetme

- Öne çıkan, yeni, sesli ve editör seçkisi raflarını yatay kaydırın.
- **Tümünü Göster** ile ilgili grubun tamamını açın.
- Kategori kartından kategori kitaplarına gidin.
- Yayınevi veya yazar kartından ilgili eserlere gidin.
- Arama alanında kitap adı, yazar veya ilgili ifade arayın.

### 16.2 Kitap detay sayfası

- Kapak, ad, yazar, yayınevi, dil, seslendiren ve açıklama bilgilerini görün.
- İçerik biçimine göre **Oku**, **Dinle** veya **Tanıtım** düğmesini kullanın.
- Başka dil sürümü varsa dil seçin.
- Satış bağlantısı varsa **Satın Al** dış mağaza/web sayfasını açabilir.
- Kalp simgesiyle favoriye ekleyin/çıkarın.
- Kitabı mevcut kişisel listeye ekleyin veya yeni liste oluşturun.

### 16.3 Kitaplığım

Menü yolu: **Kitaplar > Menü > Kitaplığım**

Sekmeler:

- **Başlananlar:** İlerleme oranı ve kaldığınız yer.
- **Bitenler:** Tamamlanan kitaplar.
- **Listelerim:** Ad verilerek oluşturulan kişisel kitap listeleri.
- **Favoriler:** Kalple kaydedilen kitaplar.

Liste oluşturabilir, içindeki kitapları açabilir ve listeyi silebilirsiniz. Favori veya kitaplık kaydını kaldırırken gösterilen onayı kontrol edin.

### 16.4 E-kitap okuyucu

- Kitap ilk açılışta EPUB olarak indirilebilir; ilerleme gösterilir.
- İndirilen kitap sonraki açılışlarda çevrimdışı kullanılabilir.
- Bölüm ve görünüm seçeneklerini okuyucu içinden değiştirin.
- Son okuma konumu ve ilerleme otomatik kaydedilir.
- Açma hatasında **Tekrar Dene** seçeneğini kullanın.

### 16.5 Sesli kitap

- Kapak, kitap, bölüm, yazar ve seslendiren bilgisini görün.
- Oynat/duraklat, 30 saniye geri/ileri ve zaman çizgisini kullanın.
- Bölüm listesinden başka bölümü başlatın.
- Kaldığınız yerden devam edin veya baştan başlayın.
- Mini oynatıcıyla başka ekranlarda dinlemeyi sürdürün.
- Kilit ekranı/medya bildirimi kontrolleri platform desteğine göre kullanılabilir.

## 17. Dergiler

### 17.1 Dergi ana sayfası ve türler

- Güncel sayıları, dergi türlerini ve öne çıkan içerikleri inceleyin.
- Kapak raflarını yatay kaydırın veya **Tümünü Göster** seçeneğini kullanın.
- Tür kartına dokunarak o derginin sayılarını açın.
- Raf, Favoriler ve İndirilenler kısayollarını kullanın.
- Abonelik isteyen sayı açılırken giriş veya abonelik sorgulama yönlendirmesi gösterilir.

Tür ekranında sayılar yıllara göre gruplanır. Yıl seçilebilir; aktif kapak büyütülür. Kartta sayı, ay/yıl ve favori durumu bulunabilir.

### 17.2 Dergi detay, içindekiler ve arama

- Kapak, sayı adı, yıl, sayı numarası ve açıklamayı görün.
- Uzun açıklamayı genişletin/daraltın.
- İçindekiler panelinden konu başlığına veya sayfasına gidin.
- Kelime/ifade arayın; sonuçtaki sayfa ve metin parçasını açın.
- Arama sonucu okuyucuda vurgulanabilir.
- **İndir** ile sayıyı çevrimdışı kullanıma hazırlayın.
- İndirilen sayıyı detaydan veya İndirilenler ekranından silebilirsiniz.

### 17.3 Dergi okuyucu

- Sayfaları sağa/sola sürükleyin.
- Klasik kaydırma veya sayfa çevirme animasyonunu seçin.
- Sayfa çevirme sesini açın/kapatın.
- Yazı boyutunu ayar veya iki parmak hareketiyle değiştirin.
- Koyu mod ya da sunulan açık zemin renklerini seçin.
- Görünümü varsayılana sıfırlayın.
- Tam ekranla araç çubuklarını gizleyin.
- Önceki/sonraki sayfaya geçin, içindekileri açın veya sesli okumayı başlatın.
- Son sayfa çıkışta saklanır.

### 17.4 Metin seçimi ve alıntı

- Metne uzun basıp seçim yapın.
- Seçimi kopyalayın veya paylaşın.
- **Favoriye Ekle** ile alıntı olarak kaydedin.
- Favoriler ekranındaki **Sözler** sekmesinden alıntıları görün.
- Alıntıya dokunarak ilgili dergi sayfasına ve vurgulanmış metne dönün.
- Alıntıyı yeniden paylaşın veya silin.

### 17.5 Dergi sesli okuma

- Sesi bulunan konuda oynatma düğmesine dokunun.
- Kaldığınız yerden devam edin veya baştan başlatın.
- Konu, yazar, seslendiren ve süre bilgisini görün.
- Önceki/sonraki konu, ileri/geri sarma ve zaman çizgisini kullanın.
- Sunulan aralıkta oynatma hızını değiştirin.
- Desteklenen cihazlarda yankı efekti kullanılabilir.
- Yağmur/doğa gibi fon sesi seçip seviyesini ayrı ayarlayabilirsiniz.
- Mini oynatıcıyla dergi sayfaları arasında dinlemeyi sürdürün.

### 17.6 Raf, Favoriler ve İndirilenler

- **Raf:** Tür düğmeleriyle filtreleyin; karta dokunarak sayıya gidin.
- **Favoriler > Dergiler:** Kayıtlı sayıları tür bazında filtreleyin.
- **Favoriler > Sözler:** Kaydedilen alıntıları yönetin.
- **İndirilenler:** Çevrimdışı sayıları ve dosya boyutlarını görün; tekli veya seçim modunda toplu silin.

## 18. Abonelik sorgulama

Menü yolu: **Menü > Abonelik Sorgulama**

1. Ülke kodunu seçin.
2. Telefon numaranızı girin.
3. Sorgulamayı başlatın.
4. Gerekirse SMS ile gelen doğrulama kodunu yazın.
5. Aktif ve süresi bitmiş abonelikleri sonuç ekranından kontrol edin.

Abonelik kartında ürün/dergi adı, başlangıç/bitiş tarihi ve durum bulunabilir. Cihaz sınırı doluysa kayıtlı cihazlardan birini kaldırmanız istenebilir. Kod gelmezse süre dolduktan sonra yeniden gönderin. Abonelik görünmüyorsa ülke kodu ile numaranın abonelikte kullanılan bilgilerle aynı olduğundan emin olun.

## 19. Delâilü'l-Hayrât

Delâil bölümü oturum açmayı isteyebilir. Giriş ekranında iki deneyim bulunur:

- **Klasik görünüm:** Sayfa/PDF temelli okuma.
- **Dinamik/açıklamalı görünüm:** Metin akışı, açıklama ve gelişmiş ses takibi.

Her görünümde **Devam Et**, **Yer İmleri** ve **İçindekiler** eylemleri bulunur. **Hakkında** bölümü eserle ilgili bilgi verir.

### 19.1 Klasik görünüm

- İlk kullanımda sayfa paketini indirin; aktarım ve kurulum ilerlemesini takip edin.
- Son sayfadan devam edin veya içindekilerden gün/bölüm seçin.
- Sayfaları sağa/sola kaydırın ve yakınlaştırın.
- Mevcut sayfaya yer imi ekleyin.
- Okuma zemini ve okuma imleci gibi sunulan görünüm seçeneklerini ayarlayın.
- Otomatik ilerlemeyi açıp hızını değiştirin.
- Son sayfa çıkışta kaydedilir.
- Ayarlardan Delâil okuma istatistiklerini açabilirsiniz.

### 19.2 Dinamik/açıklamalı görünüm

- Bölüm veya yaprak seçerek başlayın; kaldığınız metin konumundan devam edin.
- Arapça metin, tercüme/açıklama ve içerik düzenini okuyucu ayarlarından değiştirin.
- Yazı boyutu, satır takibi/imleç ve otomatik kaydırmayı ayarlayın.
- Metin konumuna yer imi ekleyip yer imleri ekranından geri dönün.
- İçindekiler panelinden başka bölüme atlayın.
- Uyumlu ses paketini indirin; ses çalarken ilgili metin/satır takibi yapılabilir.
- Oynat/duraklat, zaman çizgisi ve otomatik kaydırma kontrollerini kullanın.
- Ayarlar içinden okuma istatistiklerini açın.

### 19.3 Delâil indirmeleri ve hatırlatması

- Büyük sayfa ve ses paketleri için Wi-Fi önerilir.
- İndirme bittikten sonra kurulum/hazırlama aşaması olabilir.
- Kullanılmayan ses/paketler ilgili ayarlardan silinebilir.
- Delâil hatırlatıcısı varsa gün, saat ve bildirim tercihini okuyucu/Delâil ayarlarından düzenleyin; bildirim izni gereklidir.

## 20. İlahi, radyo ve canlı yayınlar

### 20.1 İlahi Radyo

- Canlı yayını oynat/duraklat düğmesiyle kontrol edin.
- Yayın bilgisi varsa program veya parça adı gösterilir.
- Başka sayfaya geçince mini oynatıcıdan yayını yönetin.
- Kilit ekranı/medya bildirimi platforma göre kullanılabilir.
- Canlı yayın kesintisiz internet ister.

### 20.2 İlahi TV/müzik

- Öne çıkan albüm, sanatçı ve parçaları inceleyin.
- Parça, albüm veya sanatçı arayın.
- Albüm detayında kapak ve parça listesini açın.
- Bir parçayı seçince oynatma sırası ilgili listeden oluşturulur.
- Parçayı favoriye, kişisel listeye veya indirmelere ekleyin.
- Albümün tamamını topluca indirme seçeneği sunulabilir.
- Yalnız Wi-Fi ile indirme açıksa mobil veride indirme başlamaz.

### 20.3 İlahi oynatıcı ve arşiv

- Mini oynatıcıda kapak, ad, sanatçı, ilerleme ve oynat/duraklat bulunur.
- Tam oynatıcıda önceki/sonraki, karıştırma ve tekrar modlarını kullanın.
- Kuyruğu açıp parçaya geçin, sıralayın veya sıradan kaldırın.
- Son Dinlediklerim geçmişini tek tek veya topluca temizleyin.
- İndirilenleri çevrimdışı oynatın.
- Ad vererek çalma listesi oluşturun; parça ekleyin, kaldırın, sıralayın, listeyi yeniden adlandırın veya silin.

### 20.4 Canlı video

- Ana sayfadaki yayın kartına dokunun.
- Oynat/duraklat, ses ve tam ekran kontrollerini kullanın.
- Telefonu yatay çevirerek geniş görünüm kullanın.
- Yayın kapalı veya bağlantı başarısızsa **Yeniden Dene** seçeneğini kullanın.

## 21. Duvar kâğıtları

Duvar Kâğıtları ekranında görseller ızgara halinde listelenir. Bir karta dokunarak tam ön izlemeyi ve ürün durumunu açın.

### 21.1 Ücretsiz veya sahip olunan duvar kâğıdı

- **Android:** Uygula düğmesine dokunun; **Ana Ekran**, **Kilit Ekranı** veya **Her İkisi** seçeneğini belirleyin.
- **iPhone/iPad:** Görsel önce Fotoğraflar'a kaydedilir. Ardından iOS Ayarlar/Fotoğraflar üzerinden kullanıcı tarafından duvar kâğıdı yapılır; iOS uygulamanın duvar kâğıdını doğrudan değiştirmesine izin vermez.
- Galeriye kaydetme için platformun fotoğraf/medya izni istenebilir.

### 21.2 Ücretli duvar kâğıdı

- Kartta gösterilen mağaza fiyatını kontrol edin.
- Satın alma düğmesi Google Play/App Store ödeme akışını açar.
- Başarıyla sahip olunan ürün indirilebilir veya uygulanabilir.
- Satın alma beklemede, iptal veya başarısız durumdaysa mağaza işleminin sonucunu kontrol edin.
- İade, ödeme veya mağaza hesabı sorunlarında ilgili uygulama mağazasının kuralları geçerlidir; gerekirse uygulama içi Destek'e başvurun.

## 22. Bildirimler

- Bildirimler ekranı duyuru ve içerik bildirimlerini listeler.
- Okunmamış kayıtlar farklı işaretlenir.
- Bildirime dokunmak onu okundu yapar ve bağlantısı varsa ilgili içeriği açar.
- **Tümünü Okundu Yap** bütün okunmamış işaretlerini temizler.
- Kayıt kaydırılarak silinebilir.
- Uzun metin **Devamı/Daha az** ile genişletilip daraltılabilir.
- Görseli olan bildirimlerde görsel kartta gösterilir.

Bildirim alamıyorsanız cihazın `Ayarlar > Uygulamalar > Semerkand Dijital > Bildirimler` bölümünü kontrol edin. Namaz hatırlatıcısı, indirme, genel duyuru ve diğer bildirim kanalları Android'de ayrı ayrı kapatılmış olabilir.

## 23. Hesap oluşturma ve giriş

### 23.1 Giriş yöntemleri

Giriş ekranında kullanılabilir seçenekler:

- E-posta ile devam etme
- Telefon ile devam etme
- Google ile giriş
- iPhone/iPad'de Apple ile giriş
- Daha önce etkinleştirildiyse biyometrik hızlı giriş

Uygulama girilen e-posta/telefonun mevcut hesaba mı yoksa kayıt akışına mı ait olduğunu kontrol eder ve uygun adımları gösterir.

### 23.2 Telefon ile giriş/kayıt

- Ülke kodunu seçin ve telefon numarasını girin.
- Numara 8–15 rakam aralığında olmalıdır.
- Mevcut hesaba göre şifre veya SMS doğrulama adımı gösterilebilir.
- Yeni hesapta ad, soyad, iletişim ve şifre bilgilerini tamamlayın.
- Mevcut minimum şifre uzunluğu 4 karakterdir; ekranda gösterilen güncel koşullar her zaman önceliklidir.
- Dergi aboneliği durumu sorulursa doğru seçeneği işaretleyin; abonelik eşleştirme/doğrulama adımı açılabilir.

### 23.3 E-posta, doğrulama ve şifre

- E-posta adresini doğru yazın ve devam edin.
- Hesap varsa şifreyle giriş yapın.
- Yeni kayıtta istenen profil ve telefon bilgilerini doldurun.
- E-posta/SMS kodu istenirse gelen kodu ilgili alana yazın.
- Kod gelmezse spam klasörünü/telefon hattını kontrol edip yeniden gönderin.
- Şifre unutulduysa ekrandaki şifre yenileme akışını kullanın.

### 23.4 Sosyal ve biyometrik giriş

- Google girişinde cihazdaki Google hesabını seçin.
- Apple ile giriş yalnız desteklenen Apple cihazlarında görünür.
- Sosyal hesaptan telefon bilgisi gelmediyse hesap tamamlamak için telefon istenebilir.
- Biyometrik giriş etkinleştirilirken parmak izi/Face ID doğrulaması yapılır.
- Cihazın biyometrik kayıtları değişirse güvenlik nedeniyle yeniden normal giriş gerekebilir.

## 24. Profil ve bağlı cihazlar

Menü yolu: **Menü > Profilim**

### 24.1 Profil

- Ad-soyad, e-posta ve telefon bilgilerini görüntüleyin.
- **Profili Düzenle** ile ad, soyad ve sunulan diğer bilgileri güncelleyin.
- E-posta/telefon değişikliği doğrulama kodu gerektirebilir.
- Tema, biyometrik giriş ve bağlı cihazlara profil içinden ulaşın.
- İnternet yokken önceden kaydedilmiş temel profil bilgisi gösterilebilir.

### 24.2 Bağlı cihazlar

- Hesabın açık olduğu cihazları görüntüleyin.
- Mevcut cihaz rozetle işaretlenebilir.
- Cihaz adı/modeli, işletim sistemi, uygulama sürümü ve son görülme zamanı gösterilebilir.
- Kullanmadığınız başka cihazı onayla kaldırın.
- Cihaz sınırına ulaşıldığında yeni girişten önce eski bir cihazı kaldırmanız istenir.

### 24.3 Çıkış ve hesap silme

- **Çıkış Yap** mevcut oturumu kapatır.
- Biyometrik hızlı giriş açıksa yalnız oturumu kapatma veya bu cihazdaki hızlı giriş/hesap bilgisini de kaldırma seçenekleri sunulabilir.
- **Hesabı Sil** kalıcı bir işlemdir. Onay ekranındaki veri kaybı açıklamasını okuyun; yalnız gerçekten hesabı kapatmak istiyorsanız onaylayın.

## 25. Ayarlar

Menü yolu: **Menü > Ayarlar**

### 25.1 Ayarlar ana ekranı

- Widget ve Bildirim Çubuğu
- Tema
- Dil
- Ana Sayfayı Düzenle
- Bölgesel gereksinime göre anonim kullanım istatistiği tercihi
- Uygulama Kullanım Rehberi
- Uygulama Tanıtımını yeniden gösterme
- Destek
- Alt bölümde uygulama sürümü

### 25.2 Tema

- Açık, koyu veya sistem temasını seçin.
- Hazır vurgu renklerinden birini seçin.
- Özel renk seçicisinde renk tonu/doygunluk/parlaklığı ayarlayın.
- Değişikliği ön izlemede görün.
- Tema ayarlarını varsayılana sıfırlayın.
- Uygun widget'lar seçilen vurgu rengini kullanabilir.

### 25.3 Dil

- Sistem dilini takip etme veya doğrudan dil seçme kullanılabilir.
- Desteklenen diller: Türkçe, İngilizce, Almanca, Fransızca ve Arapça.
- Arapça seçildiğinde arayüz sağdan sola uyarlanır.
- Dil değişikliği metinlere ve tarih biçimlerine uygulanır.
- Desteklenmeyen sistem dilinde uygulama yedek dile geçebilir.

### 25.4 Uygulama tanıtımı ve rehber

- **Uygulama Tanıtımı** ilk kurulumdan sonra da yeniden açılabilir.
- **Uygulama Kullanım Rehberi**, aktif dil için sunucuda rehber varsa görünür.
- Rehber yüklenmiyorsa interneti kontrol edip tekrar deneyin.

## 26. Widget'lar ve Android bildirim çubuğu

Menü yolu: **Menü > Ayarlar > Widget ve Bildirim Çubuğu**

Galeride platforma göre şu widget'lar bulunabilir:

- Tam namaz vakitleri
- Orta/küçük/kompakt namaz vakti
- Şeffaf veya kare vakit görünümü
- Kur'an ilerlemesi
- Delâilü'l-Hayrât ilerlemesi
- Günün Sözü

### 26.1 Widget ekleme

- Android'de desteklenen sürümlerde karttaki **Ekle** düğmesi sabitleme ekranını açabilir. Olmazsa ana ekrana uzun basın, **Widget'lar > Semerkand Dijital** yolunu izleyin.
- iPhone/iPad'de ana ekrana uzun basın, düzenleme/`+` menüsünü açın, Semerkand Dijital'i bulup boyutu seçin.

### 26.2 Widget özelleştirme

- Canlı ön izlemeyi kontrol edin.
- Arka plan, metin ve vurgu rengini seçin.
- Arka plan saydamlığını ayarlayın.
- Kaydedince mevcut widget yenilenir.
- Her widget türünün ayarı ayrı tutulabilir.

Widget güncellenmiyorsa uygulamayı açıp vakit/konum verisini yenileyin, widget'ı kaldırıp yeniden ekleyin ve işletim sisteminin arka plan kısıtlamalarını kontrol edin.

## 27. Bağlı saat

Bağlı bir saat algılanırsa yan menüde **Bağlı Saat** kartı veya **Saat Ayarları** ekranı görünür.

- Saatin bağlı/eşleştirilmiş/erişilemiyor durumunu görün.
- **Şimdi Eşitle** ile verileri elle gönderin.
- Son eşitleme zamanını kontrol edin.
- Namaz vakitleri temel saat özelliğidir ve sürekli açıktır.
- Kaza/hatim ilerlemesi, dinî günler ve medya kumandası modüllerini açıp kapatın.
- Hatırlatıcı ayarlarına telefondaki ilgili ekrandan gidin.
- Saat çevrimdışı kullanım için sınırlı sayıda günlük vakit verisi saklayabilir; güncel kodda sekiz günlük çevrimdışı vakit desteği belirtilmektedir.
- Kıble, hatırlatıcı, medya ve kadran/komplikasyon özelliklerinin kullanılabilirliği saat platformuna ve modele bağlıdır.

Saat eşitlenmiyorsa Bluetooth'u, telefon-saat bağlantısını, eşlikçi saat uygulamasını ve iki cihazdaki Semerkand Dijital sürümünü kontrol edin; sonra **Şimdi Eşitle**yi yeniden deneyin.

## 28. Hava durumu ve adım sayar

### 28.1 Hava durumu

- Ana sayfa kartında sıcaklık ve genel durum görünür.
- Kartı açarak saatlik/günlük tahmini inceleyin.
- Veri varsa hissedilen sıcaklık, nem, rüzgâr ve yağış gösterilir.
- Takvim için seçilen konumu kullanır.
- Güncel tahmin internet ister; kısa süre son alınan veri gösterilebilir.
- Kartı `Ayarlar > Ana Sayfayı Düzenle` bölümünden gizleyebilirsiniz.

### 28.2 Adım sayar

- Günlük adım sayısını ana sayfada gösterir.
- Karta dokunarak günlük, haftalık ve aylık raporları/grafikleri açın.
- Android'de fiziksel aktivite ve bazı cihazlarda Health Connect; iOS'ta Apple Health/hareket izni gerekir.
- İzin verilmez veya cihaz veri sağlamazsa adım gösterilemez.
- Kart varsayılan olarak gizli olabilir; `Ayarlar > Ana Sayfayı Düzenle` bölümünden açın.

## 29. Okuma istatistikleri

Okuma istatistikleri Kur'an ve Delâil okuyucularının menü/ayarlarından açılır.

- **Gün:** Seçilen gün.
- **Hafta:** Seçilen tarihin bulunduğu hafta.
- **Ay:** Seçilen ay.
- **Tüm zamanlar:** Bütün kayıtlar.
- **Özel:** Kullanıcının seçtiği başlangıç-bitiş aralığı.

Gösterilen ölçüler:

- Toplam okuma süresi
- Okuma yapılan gün sayısı
- Günlük ortalama
- En yüksek süreli gün
- Günlük süre grafiği
- Tarih bazlı ayrıntılar

Kur'an ve Delâil istatistikleri ayrı ürünler olarak tutulur. Oturum açıksa desteklenen veriler hesapla eşitlenebilir. Aktif okuma oturumu istatistik ekranı açılırken kayda alınır; yenile simgesi son durumu çeker.

## 30. Destek talepleri

Menü yolu: **Menü > Ayarlar > Destek**

Destek alanı oturum ve internet gerektirir.

### 30.1 Yeni talep oluşturma

1. **Yeni destek talebi** düğmesine dokunun.
2. Kategori seçin: Teknik, Bilgi Talebi, İçerik Problemi, Hesap ve Üyelik, Abonelik ve Ödeme, Öneri/Geri Bildirim veya Diğer.
3. Kısa ve açıklayıcı bir konu yazın.
4. Sorunu/isteği ayrıntılı şekilde mesaj alanına yazın.
5. Gönder düğmesine dokunun.

Teknik sorunda cihaz modeli, işletim sistemi, uygulama sürümü, sorunlu ekran, hata metni ve sorunu yeniden oluşturma adımlarını yazmak çözümü hızlandırır. Şifre, SMS kodu ve ödeme kartı bilgisi paylaşmayın.

### 30.2 Talepleri izleme

- Talep listesinde konu, kategori, tarih ve durum görülür.
- Durumlar **Açık**, **Çözüldü** veya **Kapalı** olabilir.
- Talebe dokunarak kullanıcı ve destek mesajlarını konuşma biçiminde görün.
- Açık/çözülebilir konuşmaya yanıt yazıp gönderin.
- Kapalı talebe yeni mesaj gönderilemez; gerekirse yeni talep açın.
- Destek yanıtı için bildirim gelebilir; bildirime dokunmak konuşmayı açabilir.

## 31. Çevrimdışı kullanım ve indirmeler

İnternet olmadan kullanılabilen başlıca içerikler:

- Daha önce indirilmiş Takvim ve namaz vakitleri
- Uygulamadaki yerel Kur'an metni/mushaf sayfaları
- İndirilmiş hafız sesleri
- İndirilmiş e-kitap ve sesli kitap içeriği
- İndirilmiş dergi sayıları ve mevcut medya dosyaları
- İndirilmiş Delâil sayfa ve ses paketleri
- İndirilmiş ilahiler

İnternet gerektiren başlıca işlemler:

- Yeni içerik listelerini ve canlı yayınları almak
- Hesap, hatim, kitaplık ve destek eşitlemesi
- Abonelik sorgulama ve SMS doğrulama
- Yeni paket/medya indirme ve mağaza satın alması
- Hava durumu güncellemesi

İndirme iptal edilirse geçici dosyalar temizlenebilir. Büyük paketleri Wi-Fi ile indirin. Yeterli boş alan yoksa içerik açılmayabilir; ilgili İndirilenler/ayar ekranından kullanmadığınız paketleri silin.

## 32. Ortak ses oynatma davranışı

- Kur'an, kitap, dergi, Delâil, ilahi ve radyo kendi oynatıcılarını kullanır.
- Mini oynatıcı sayfalar arasında mevcut sesi kontrol eder.
- Tam oynatıcıda zaman çizgisi, geçen/toplam süre ve içerik bilgisi bulunur.
- Kilit ekranı ve medya bildirimi kontrolleri işletim sistemi desteğine bağlıdır.
- Telefon görüşmesi, başka uygulamanın ses odağı veya kulaklık bağlantısının kesilmesi sesi duraklatabilir.
- Farklı ana seslerin üst üste çalmaması için yeni bir oynatıcı başlatıldığında önceki ses durabilir.
- Ses başlamıyorsa medya ses düzeyini, interneti/indirilen paketi ve aktif Bluetooth cihazını kontrol edin.

## 33. Sorun giderme

### 33.1 Namaz vakitleri yanlışsa

1. Ana sayfadaki konum adını kontrol edin.
2. `Menü > Konum Ayarları`ndan doğru ülke/şehir/ilçeyi seçin veya GPS ile yenileyin.
3. Kayıtlı konumlar içinden doğru olanı aktif yapın.
4. Konum verisini yenileyin.
5. Seyahat ettiyseniz otomatik konum modunu veya manuel seçimi güncelleyin.

### 33.2 Hatırlatıcı çalmıyorsa

1. İlgili vaktin anahtarının açık olduğunu kontrol edin.
2. Telefonun bildirim ve medya/alarm ses düzeyini kontrol edin.
3. Seçili konum ve güncel vakit verisini doğrulayın.
4. Android'de kesin alarm, ekran üstü gösterim ve pil optimizasyonu izinlerini kontrol edin.
5. Rahatsız Etmeyin modunda çalma seçildi ise gerekli erişimi verin.
6. Hatırlatıcıyı kapatıp tekrar açarak planı yenileyin.

### 33.3 Pusula doğru göstermiyorsa

1. Mıknatıslı kılıfı çıkarın.
2. Metal ve elektronik eşyalardan uzaklaşın.
3. Telefonu sekiz şekli çizerek kalibre edin.
4. Konum iznini ve seçili konumu kontrol edin.
5. Açık alanda tekrar deneyin; cihazda pusula sensörü bulunmayabileceğini göz önünde bulundurun.

### 33.4 İçerik açılmıyor veya indirilmiyorsa

1. İnternet bağlantısını kontrol edin ve **Yeniden Dene**ye dokunun.
2. Özellik üyelik istiyorsa giriş yapın.
3. Dergi/özel içerik abonelik istiyorsa aboneliği sorgulayın.
4. Depolama alanını kontrol edin.
5. Yalnız Wi-Fi ile indirme açıksa Wi-Fi'a bağlanın.
6. Yarım kalan paketi ilgili alandan silip yeniden indirin.
7. Uygulamayı mağazadan güncelleyin.

### 33.5 Giriş yapılamıyorsa

1. Ülke kodu, telefon veya e-postayı kontrol edin.
2. İnternet bağlantısını kontrol edin.
3. SMS/e-posta kodunun en son gönderilen kod olduğundan emin olun.
4. Şifre unutulduysa yenileme akışını kullanın.
5. Cihaz sınırı uyarısında eski cihazı kaldırın.
6. Sosyal giriş iptal edildiyse Google/Apple hesabını yeniden seçin.

### 33.6 Abonelik görünmüyorsa

1. Abonelikte kullanılan doğru ülke kodu ve telefonu girin.
2. SMS doğrulamasını tamamlayın.
3. Aktif ve süresi bitmiş listelerin ikisini de kontrol edin.
4. Oturumu ve interneti yenileyin.
5. Sorun sürerse `Ayarlar > Destek > Yeni destek talebi > Abonelik ve Ödeme` yolunu kullanın.

### 33.7 Uygulama dili veya tema değişmiyorsa

1. Ayarı tekrar seçin ve önceki ekrana dönün.
2. Sistem dilini takip seçiliyse cihaz dilini kontrol edin.
3. Uygulamayı tamamen kapatıp yeniden açın.
4. Widget rengi değişmediyse widget ayarını ayrıca kaydedin veya widget'ı yeniden ekleyin.

### 33.8 Destek, hesap veya eşitleme ekranı boşsa

1. İnternet bağlantısını kontrol edin.
2. Aynı hesapla oturumun açık olduğunu doğrulayın.
3. Yenile/tekrar dene düğmesini kullanın.
4. Uygulama sürümünü güncelleyin.
5. Oturum süresi dolmuşsa yeniden giriş yapın.

## 34. Sık sorulan sorular ve kısa yanıtlar

### “Uygulamayı üye olmadan kullanabilir miyim?”

Takvim, konum, namaz vakitleri ve bazı genel içerikler üyeliksiz kullanılabilir. Kaza takibi, kişisel kitaplık, Hatim, bazı Kur'an/Delâil deneyimleri, eşitleme ve destek gibi kişisel alanlar giriş ister.

### “İnternet olmadan namaz vakitlerine bakabilir miyim?”

Evet. Konumun vakit verileri daha önce indirilmişse çevrimdışı görüntülenebilir. Yeni konum eklemek veya veriyi yenilemek için internet gerekir.

### “Konum izni vermeden kullanabilir miyim?”

Evet. İlk kurulumda veya Konum Ayarları'nda ülke, şehir ve ilçeyi elle seçebilirsiniz. Kıble/yakındaki camiler gibi anlık konum isteyen özellikler sınırlanabilir.

### “Ana sayfadaki adım sayarı nasıl açarım?”

`Menü > Ayarlar > Ana Sayfayı Düzenle` yolunda Adım Sayar anahtarını açın; sonra istenen fiziksel aktivite/sağlık iznini verin.

### “Kur'an sesini neden duyamıyorum?”

Önce `Kur'an > Hafız Sesleri`nden seçtiğiniz hafızın paketini indirin ve aktif yapın. Medya ses düzeyini ve Bluetooth çıkışını da kontrol edin.

### “Kaldığım Kur'an sayfasına nasıl dönerim?”

`Kur'an > Kur'an-ı Kerîm` ekranında **Kaldığın Sayfa/Devam Et** kartına dokunun. Ana sayfadaki **Devam Et** kartı veya Kur'an ilerleme widget'ı da aynı konuma götürebilir.

### “Hatim grubuna nasıl katılırım?”

Giriş yaptıktan sonra `Kur'an > Hatim > Gruplar` bölümünü açın, **Davet koduyla katıl** seçeneğine size gönderilen kodu yazın.

### “Dergiyi çevrimdışı nasıl okurum?”

Dergi detayında **İndir** düğmesine dokunun. İndirme tamamlanınca `Dergiler > İndirilenler` bölümünden açın. Sayının erişim koşuluna göre giriş veya abonelik gerekebilir.

### “Uygulamanın temasını nasıl değiştiririm?”

`Menü > Tema Ayarları` veya `Menü > Ayarlar > Tema` yolunu açın; açık, koyu ya da sistem modunu ve isterseniz vurgu rengini seçin.

### “Dili nasıl değiştiririm?”

`Menü > Ayarlar > Dil` bölümünden Sistem Dili, Türkçe, İngilizce, Almanca, Fransızca veya Arapça seçin.

### “Duvar kâğıdını iPhone'da neden doğrudan uygulayamıyorum?”

iOS üçüncü taraf uygulamaların duvar kâğıdını doğrudan değiştirmesine izin vermez. Görseli Fotoğraflar'a kaydedin, ardından iPhone Ayarları'ndaki Duvar Kâğıdı bölümünden seçin.

### “Okuma süremi nereden görürüm?”

Kur'an veya Delâil okuyucusunun menü/ayarından **Okuma İstatistikleri**ni açın; gün, hafta, ay, tüm zamanlar veya özel tarih aralığını seçin.

### “Destek ekibine nasıl ulaşırım?”

Giriş yaptıktan sonra `Menü > Ayarlar > Destek > Yeni destek talebi` yolunu izleyin. Kategori, konu ve açıklamayı doldurup gönderin.

### “Uygulama sürümünü nereden görürüm?”

`Menü > Ayarlar` ekranının alt bölümünde sürüm numarası gösterilir.

## 35. Terimler ve kullanıcıların kullanabileceği eş anlamlar

AI asistanı aşağıdaki ifadeleri aynı özellik kapsamında değerlendirmelidir:

| Kullanıcının söyleyebileceği ifade | Uygulamadaki karşılık |
|---|---|
| Ezan alarmı, namaz alarmı, vakit bildirimi | Hatırlatıcılar |
| Namaz saatleri, ezan saatleri | Namaz vakitleri / Takvim |
| Şehir değiştirme, lokasyon değiştirme | Konum Ayarları |
| Kıble yönü, kıble bulucu | Kıble Pusulası |
| Cami bul, yakınımdaki cami | Yakındaki Camiler |
| Kaza sayacı | Kaza Takibi |
| Mushaf, sayfa Kur'an | Kur'an-ı Kerîm klasik okuyucu |
| Akış Kur'an, metin Kur'an | Kur'an-ı Mecîd / metin okuyucu; sorunun ayrıntısına göre ayrıştır |
| Meal, Türkçe Kur'an | Mealli/metin Kur'an okuyucu |
| Kur'an sesi, hoca sesi | Hafız Sesleri |
| Cüz videosu | Mukabele |
| Hatim grubu, ortak hatim | Hatim > Gruplar |
| Kitap rafım | Kitaplığım |
| Dergi rafım | Dergi Rafı |
| Kaydettiğim sözler | Beğenilen Sözler veya Dergi Favorileri > Sözler; kaynağı sor |
| Delail, Delailül Hayrat, Hayrat | Delâilü'l-Hayrât |
| Ana ekran aracı | Widget |
| Bildirim bandı, vakit çubuğu | Android bildirim çubuğu |
| Akıllı saat, kol saati | Bağlı Saat / Saat Ayarları |
| Okuma sürem | Okuma İstatistikleri |
| Yardım, müşteri hizmetleri, hata bildir | Destek Talepleri |
| Arka plan resmi | Duvar Kâğıtları |

## 36. AI yanıt şablonları

### İşlem anlatımı şablonu

> **Menü yolu:** Menü > ...  
> 1. ... ekranını açın.  
> 2. ... seçeneğine dokunun.  
> 3. ... bilgisini seçip kaydedin.  
> **Gereken:** İnternet/oturum/izin gerekiyorsa burada belirtin.

### Özellik görünmüyor şablonu

> Bu özellik cihaz, uygulama sürümü veya hesap durumuna göre görünmeyebilir. Önce uygulamayı güncelleyin; ardından oturumunuzu ve ilgili izin/aboneliği kontrol edin. Hâlâ görünmüyorsa Menü > Ayarlar > Destek üzerinden cihaz modeli ve uygulama sürümüyle talep açın.

### Teknik sorun şablonu

> Önce [ilgili ayarı] ve [gerekli izni] kontrol edin. Sonra veriyi/ekranı yenileyip tekrar deneyin. Sorun sürerse Menü > Ayarlar > Destek > Yeni destek talebi yolunda **Teknik** kategorisini seçin; cihaz modeli, işletim sistemi, uygulama sürümü, hata metni ve sorunun oluşma adımlarını ekleyin.

## 37. Bilinen kapsam sınırları

- Uygulamadaki kitap, dergi, hikâye, canlı yayın, kampanya, fiyat ve abonelik içeriği sunucudan değişebilir.
- Bir içeriğin ücretsiz, ücretli veya aboneliğe dahil olması içerik bazında belirlenir; güncel uygulama ekranı esas alınır.
- İzin ekranlarının adı ve yeri Android üreticisine/iOS sürümüne göre değişebilir.
- Saat, widget, arka plan medya ve biyometrik özellikler cihaz donanımı ile işletim sistemi desteğine bağlıdır.
- Bu rehber uygulamanın kullanımını açıklar; dini hüküm/fetva, ödeme iadesi kararı veya kişisel hesap incelemesi yapmaz.
- Hesap, ödeme, abonelik ve veri eşitlemeyle ilgili kullanıcıya özel inceleme gerektiğinde uygulama içi Destek kullanılmalıdır.

