## 16. Kitaplar ve Kitaplığım

Kitaplar bölümü ve kişisel kitaplık oturum açmayı isteyebilir.

### 16.1 Kitap keşfetme

- Öne çıkan, yeni, sesli ve editör seçkisi raflarını yatay kaydırın.
- **Tümünü Göster** ile ilgili grubun tamamını açın.
- Kategori kartından kategori kitaplarına gidin.
- Yayınevi veya yazar kartından ilgili eserlere gidin.
- Arama alanında kitap adı, yazar veya ilgili ifade arayın.

### 16.2 Kitap detay sayfası

- Kapak, ad, yazar, yayınevi, dil, seslendiren ve açıklama bilgilerini görün.
- İçerik biçimine göre **Oku**, **Dinle** veya **Tanıtım** düğmesini kullanın.
- Başka dil sürümü varsa dil seçin.
- Satış bağlantısı varsa **Satın Al** dış mağaza/web sayfasını açabilir.
- Kalp simgesiyle favoriye ekleyin/çıkarın.
- Kitabı mevcut kişisel listeye ekleyin veya yeni liste oluşturun.

### 16.3 Kitaplığım

Menü yolu: **Kitaplar > Menü > Kitaplığım**

Sekmeler:

- **Başlananlar:** İlerleme oranı ve kaldığınız yer.
- **Bitenler:** Tamamlanan kitaplar.
- **Listelerim:** Ad verilerek oluşturulan kişisel kitap listeleri.
- **Favoriler:** Kalple kaydedilen kitaplar.

Liste oluşturabilir, içindeki kitapları açabilir ve listeyi silebilirsiniz. Favori veya kitaplık kaydını kaldırırken gösterilen onayı kontrol edin.

### 16.4 E-kitap okuyucu

- Kitap ilk açılışta EPUB olarak indirilebilir; ilerleme gösterilir.
- İndirilen kitap sonraki açılışlarda çevrimdışı kullanılabilir.
- Bölüm ve görünüm seçeneklerini okuyucu içinden değiştirin.
- Son okuma konumu ve ilerleme otomatik kaydedilir.
- Açma hatasında **Tekrar Dene** seçeneğini kullanın.

### 16.5 Sesli kitap

- Kapak, kitap, bölüm, yazar ve seslendiren bilgisini görün.
- Oynat/duraklat, 30 saniye geri/ileri ve zaman çizgisini kullanın.
- Bölüm listesinden başka bölümü başlatın.
- Kaldığınız yerden devam edin veya baştan başlayın.
- Mini oynatıcıyla başka ekranlarda dinlemeyi sürdürün.
- Kilit ekranı/medya bildirimi kontrolleri platform desteğine göre kullanılabilir.