# Semerkand Dijital AI Asistanı — Uygulama Kullanım Bilgi Tabanı

> Doküman türü: Son kullanıcı kullanım rehberi ve AI asistanı bilgi kaynağı  
> İncelenen uygulama sürümü: **3.0.1 (2080)**  
> Son kod inceleme tarihi: **23 Eylül 2026**  
> Platformlar: Android ve iPhone/iPad; belirtilen saat özellikleri Android/Wear OS ve Apple Watch desteğine göre değişebilir.