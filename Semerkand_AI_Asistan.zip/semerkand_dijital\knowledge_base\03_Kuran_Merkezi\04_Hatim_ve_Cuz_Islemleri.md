## 15. Hatim, cüzlerim ve Hatim Duası

### 15.1 Hatim ana ekranı

Hatim alanı oturum açmayı gerektirir. Sekmeler:

- **Genel Hatim:** Boş cüzü seçip onaylayarak üzerinize alın.
- **Gruplar:** Yeni grup oluşturun veya davet koduyla gruba katılın.
- **Cüzlerim:** Aldığınız cüzleri ve ilerlemeyi görün.

### 15.2 Hatim grubu

- Grup oluştururken ad ve isteğe bağlı bitiş tarihi girin.
- Davet kodunu kopyalayın veya paylaşın.
- Kodla mevcut gruba katılın.
- Yetkiniz varsa grup adı/bitiş tarihini düzenleyin, üyeleri ve cüz durumlarını görün.
- Grup yöneticisi grubu silebilir ve tüm cüzler bitince turu tamamlayıp yeni tura geçebilir.
- Üye gruptan ayrılabilir; aldığı cüzü bırakabilir.
- Grup veya cüzü etkileyen işlemlerde gösterilen onayı dikkatle kontrol edin.

### 15.3 Cüz okuma ve arşiv

- Cüzü klasik mushaf, Kur'an-ı Mecîd veya sunulan diğer okuyucuyla açın.
- İlerleme sayfa bazında kaydedilir; **Devam Et** son konuma döner.
- Cüz bitince **Tamamlandı** olarak işaretleyin.
- Tamamlanan cüzler arşivde tarih ve hatim bilgisiyle görüntülenebilir.
- Hatim/cüz hatırlatmaları açıksa bitiş tarihinden belirli süre önce bildirim alınabilir.

### 15.4 Hatim Duası

- Ses paketini indirin ve çevrimdışı dinleyin.
- İndirme yüzdesini takip edin.
- Oynat/duraklat ve zaman çizgisini kullanın.
- Geçen/toplam süre oynatıcıda gösterilir.