## 23. Hesap oluşturma ve giriş

### 23.1 Giriş yöntemleri

Giriş ekranında kullanılabilir seçenekler:

- E-posta ile devam etme
- Telefon ile devam etme
- Google ile giriş
- iPhone/iPad'de Apple ile giriş
- Daha önce etkinleştirildiyse biyometrik hızlı giriş

Uygulama girilen e-posta/telefonun mevcut hesaba mı yoksa kayıt akışına mı ait olduğunu kontrol eder ve uygun adımları gösterir.

### 23.2 Telefon ile giriş/kayıt

- Ülke kodunu seçin ve telefon numarasını girin.
- Numara 8–15 rakam aralığında olmalıdır.
- Mevcut hesaba göre şifre veya SMS doğrulama adımı gösterilebilir.
- Yeni hesapta ad, soyad, iletişim ve şifre bilgilerini tamamlayın.
- Mevcut minimum şifre uzunluğu 4 karakterdir; ekranda gösterilen güncel koşullar her zaman önceliklidir.
- Dergi aboneliği durumu sorulursa doğru seçeneği işaretleyin; abonelik eşleştirme/doğrulama adımı açılabilir.

### 23.3 E-posta, doğrulama ve şifre

- E-posta adresini doğru yazın ve devam edin.
- Hesap varsa şifreyle giriş yapın.
- Yeni kayıtta istenen profil ve telefon bilgilerini doldurun.
- E-posta/SMS kodu istenirse gelen kodu ilgili alana yazın.
- Kod gelmezse spam klasörünü/telefon hattını kontrol edip yeniden gönderin.
- Şifre unutulduysa ekrandaki şifre yenileme akışını kullanın.

### 23.4 Sosyal ve biyometrik giriş

- Google girişinde cihazdaki Google hesabını seçin.
- Apple ile giriş yalnız desteklenen Apple cihazlarında görünür.
- Sosyal hesaptan telefon bilgisi gelmediyse hesap tamamlamak için telefon istenebilir.
- Biyometrik giriş etkinleştirilirken parmak izi/Face ID doğrulaması yapılır.
- Cihazın biyometrik kayıtları değişirse güvenlik nedeniyle yeniden normal giriş gerekebilir.