## 25. Ayarlar

Menü yolu: **Menü > Ayarlar**

### 25.1 Ayarlar ana ekranı

- Widget ve Bildirim Çubuğu
- Tema
- Dil
- Ana Sayfayı Düzenle
- Bölgesel gereksinime göre anonim kullanım istatistiği tercihi
- Uygulama Kullanım Rehberi
- Uygulama Tanıtımını yeniden gösterme
- Destek
- Alt bölümde uygulama sürümü

### 25.2 Tema

- Açık, koyu veya sistem temasını seçin.
- Hazır vurgu renklerinden birini seçin.
- Özel renk seçicisinde renk tonu/doygunluk/parlaklığı ayarlayın.
- Değişikliği ön izlemede görün.
- Tema ayarlarını varsayılana sıfırlayın.
- Uygun widget'lar seçilen vurgu rengini kullanabilir.

### 25.3 Dil

- Sistem dilini takip etme veya doğrudan dil seçme kullanılabilir.
- Desteklenen diller: Türkçe, İngilizce, Almanca, Fransızca ve Arapça.
- Arapça seçildiğinde arayüz sağdan sola uyarlanır.
- Dil değişikliği metinlere ve tarih biçimlerine uygulanır.
- Desteklenmeyen sistem dilinde uygulama yedek dile geçebilir.

### 25.4 Uygulama tanıtımı ve rehber

- **Uygulama Tanıtımı** ilk kurulumdan sonra da yeniden açılabilir.
- **Uygulama Kullanım Rehberi**, aktif dil için sunucuda rehber varsa görünür.
- Rehber yüklenmiyorsa interneti kontrol edip tekrar deneyin.