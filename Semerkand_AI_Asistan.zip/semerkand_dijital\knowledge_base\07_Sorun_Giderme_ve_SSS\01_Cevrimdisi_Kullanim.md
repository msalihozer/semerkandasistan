## 31. Çevrimdışı kullanım ve indirmeler

İnternet olmadan kullanılabilen başlıca içerikler:

- Daha önce indirilmiş Takvim ve namaz vakitleri
- Uygulamadaki yerel Kur'an metni/mushaf sayfaları
- İndirilmiş hafız sesleri
- İndirilmiş e-kitap ve sesli kitap içeriği
- İndirilmiş dergi sayıları ve mevcut medya dosyaları
- İndirilmiş Delâil sayfa ve ses paketleri
- İndirilmiş ilahiler

İnternet gerektiren başlıca işlemler:

- Yeni içerik listelerini ve canlı yayınları almak
- Hesap, hatim, kitaplık ve destek eşitlemesi
- Abonelik sorgulama ve SMS doğrulama
- Yeni paket/medya indirme ve mağaza satın alması
- Hava durumu güncellemesi

İndirme iptal edilirse geçici dosyalar temizlenebilir. Büyük paketleri Wi-Fi ile indirin. Yeterli boş alan yoksa içerik açılmayabilir; ilgili İndirilenler/ayar ekranından kullanmadığınız paketleri silin.