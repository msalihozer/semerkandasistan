## 35. Terimler ve kullanıcıların kullanabileceği eş anlamlar

AI asistanı aşağıdaki ifadeleri aynı özellik kapsamında değerlendirmelidir:

| Kullanıcının söyleyebileceği ifade | Uygulamadaki karşılık |
|---|---|
| Ezan alarmı, namaz alarmı, vakit bildirimi | Hatırlatıcılar |
| Namaz saatleri, ezan saatleri | Namaz vakitleri / Takvim |
| Şehir değiştirme, lokasyon değiştirme | Konum Ayarları |
| Kıble yönü, kıble bulucu | Kıble Pusulası |
| Cami bul, yakınımdaki cami | Yakındaki Camiler |
| Kaza sayacı | Kaza Takibi |
| Mushaf, sayfa Kur'an | Kur'an-ı Kerîm klasik okuyucu |
| Akış Kur'an, metin Kur'an | Kur'an-ı Mecîd / metin okuyucu; sorunun ayrıntısına göre ayrıştır |
| Meal, Türkçe Kur'an | Mealli/metin Kur'an okuyucu |
| Kur'an sesi, hoca sesi | Hafız Sesleri |
| Cüz videosu | Mukabele |
| Hatim grubu, ortak hatim | Hatim > Gruplar |
| Kitap rafım | Kitaplığım |
| Dergi rafım | Dergi Rafı |
| Kaydettiğim sözler | Beğenilen Sözler veya Dergi Favorileri > Sözler; kaynağı sor |
| Delail, Delailül Hayrat, Hayrat | Delâilü'l-Hayrât |
| Ana ekran aracı | Widget |
| Bildirim bandı, vakit çubuğu | Android bildirim çubuğu |
| Akıllı saat, kol saati | Bağlı Saat / Saat Ayarları |
| Okuma sürem | Okuma İstatistikleri |
| Yardım, müşteri hizmetleri, hata bildir | Destek Talepleri |
| Arka plan resmi | Duvar Kâğıtları |