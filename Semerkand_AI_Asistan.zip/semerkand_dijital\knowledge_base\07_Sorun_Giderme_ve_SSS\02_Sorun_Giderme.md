## 33. Sorun giderme

### 33.1 Namaz vakitleri yanlışsa

1. Ana sayfadaki konum adını kontrol edin.
2. `Menü > Konum Ayarları`ndan doğru ülke/şehir/ilçeyi seçin veya GPS ile yenileyin.
3. Kayıtlı konumlar içinden doğru olanı aktif yapın.
4. Konum verisini yenileyin.
5. Seyahat ettiyseniz otomatik konum modunu veya manuel seçimi güncelleyin.

### 33.2 Hatırlatıcı çalmıyorsa

1. İlgili vaktin anahtarının açık olduğunu kontrol edin.
2. Telefonun bildirim ve medya/alarm ses düzeyini kontrol edin.
3. Seçili konum ve güncel vakit verisini doğrulayın.
4. Android'de kesin alarm, ekran üstü gösterim ve pil optimizasyonu izinlerini kontrol edin.
5. Rahatsız Etmeyin modunda çalma seçildi ise gerekli erişimi verin.
6. Hatırlatıcıyı kapatıp tekrar açarak planı yenileyin.

### 33.3 Pusula doğru göstermiyorsa

1. Mıknatıslı kılıfı çıkarın.
2. Metal ve elektronik eşyalardan uzaklaşın.
3. Telefonu sekiz şekli çizerek kalibre edin.
4. Konum iznini ve seçili konumu kontrol edin.
5. Açık alanda tekrar deneyin; cihazda pusula sensörü bulunmayabileceğini göz önünde bulundurun.

### 33.4 İçerik açılmıyor veya indirilmiyorsa

1. İnternet bağlantısını kontrol edin ve **Yeniden Dene**ye dokunun.
2. Özellik üyelik istiyorsa giriş yapın.
3. Dergi/özel içerik abonelik istiyorsa aboneliği sorgulayın.
4. Depolama alanını kontrol edin.
5. Yalnız Wi-Fi ile indirme açıksa Wi-Fi'a bağlanın.
6. Yarım kalan paketi ilgili alandan silip yeniden indirin.
7. Uygulamayı mağazadan güncelleyin.

### 33.5 Giriş yapılamıyorsa

1. Ülke kodu, telefon veya e-postayı kontrol edin.
2. İnternet bağlantısını kontrol edin.
3. SMS/e-posta kodunun en son gönderilen kod olduğundan emin olun.
4. Şifre unutulduysa yenileme akışını kullanın.
5. Cihaz sınırı uyarısında eski cihazı kaldırın.
6. Sosyal giriş iptal edildiyse Google/Apple hesabını yeniden seçin.

### 33.6 Abonelik görünmüyorsa

1. Abonelikte kullanılan doğru ülke kodu ve telefonu girin.
2. SMS doğrulamasını tamamlayın.
3. Aktif ve süresi bitmiş listelerin ikisini de kontrol edin.
4. Oturumu ve interneti yenileyin.
5. Sorun sürerse `Ayarlar > Destek > Yeni destek talebi > Abonelik ve Ödeme` yolunu kullanın.

### 33.7 Uygulama dili veya tema değişmiyorsa

1. Ayarı tekrar seçin ve önceki ekrana dönün.
2. Sistem dilini takip seçiliyse cihaz dilini kontrol edin.
3. Uygulamayı tamamen kapatıp yeniden açın.
4. Widget rengi değişmediyse widget ayarını ayrıca kaydedin veya widget'ı yeniden ekleyin.

### 33.8 Destek, hesap veya eşitleme ekranı boşsa

1. İnternet bağlantısını kontrol edin.
2. Aynı hesapla oturumun açık olduğunu doğrulayın.
3. Yenile/tekrar dene düğmesini kullanın.
4. Uygulama sürümünü güncelleyin.
5. Oturum süresi dolmuşsa yeniden giriş yapın.