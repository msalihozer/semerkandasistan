## 24. Profil ve bağlı cihazlar

Menü yolu: **Menü > Profilim**

### 24.1 Profil

- Ad-soyad, e-posta ve telefon bilgilerini görüntüleyin.
- **Profili Düzenle** ile ad, soyad ve sunulan diğer bilgileri güncelleyin.
- E-posta/telefon değişikliği doğrulama kodu gerektirebilir.
- Tema, biyometrik giriş ve bağlı cihazlara profil içinden ulaşın.
- İnternet yokken önceden kaydedilmiş temel profil bilgisi gösterilebilir.

### 24.2 Bağlı cihazlar

- Hesabın açık olduğu cihazları görüntüleyin.
- Mevcut cihaz rozetle işaretlenebilir.
- Cihaz adı/modeli, işletim sistemi, uygulama sürümü ve son görülme zamanı gösterilebilir.
- Kullanmadığınız başka cihazı onayla kaldırın.
- Cihaz sınırına ulaşıldığında yeni girişten önce eski bir cihazı kaldırmanız istenir.

### 24.3 Çıkış ve hesap silme

- **Çıkış Yap** mevcut oturumu kapatır.
- Biyometrik hızlı giriş açıksa yalnız oturumu kapatma veya bu cihazdaki hızlı giriş/hesap bilgisini de kaldırma seçenekleri sunulabilir.
- **Hesabı Sil** kalıcı bir işlemdir. Onay ekranındaki veri kaybı açıklamasını okuyun; yalnız gerçekten hesabı kapatmak istiyorsanız onaylayın.

---

## 27. Bağlı saat

Bağlı bir saat algılanırsa yan menüde **Bağlı Saat** kartı veya **Saat Ayarları** ekranı görünür.

- Saatin bağlı/eşleştirilmiş/erişilemiyor durumunu görün.
- **Şimdi Eşitle** ile verileri elle gönderin.
- Son eşitleme zamanını kontrol edin.
- Namaz vakitleri temel saat özelliğidir ve sürekli açıktır.
- Kaza/hatim ilerlemesi, dinî günler ve medya kumandası modüllerini açıp kapatın.
- Hatırlatıcı ayarlarına telefondaki ilgili ekrandan gidin.
- Saat çevrimdışı kullanım için sınırlı sayıda günlük vakit verisi saklayabilir; güncel kodda sekiz günlük çevrimdışı vakit desteği belirtilmektedir.
- Kıble, hatırlatıcı, medya ve kadran/komplikasyon özelliklerinin kullanılabilirliği saat platformuna ve modele bağlıdır.

Saat eşitlenmiyorsa Bluetooth'u, telefon-saat bağlantısını, eşlikçi saat uygulamasını ve iki cihazdaki Semerkand Dijital sürümünü kontrol edin; sonra **Şimdi Eşitle**yi yeniden deneyin.