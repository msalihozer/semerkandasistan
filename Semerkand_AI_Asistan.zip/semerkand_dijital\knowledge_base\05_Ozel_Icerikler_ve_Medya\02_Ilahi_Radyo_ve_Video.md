## 20. İlahi, radyo ve canlı yayınlar

### 20.1 İlahi Radyo

- Canlı yayını oynat/duraklat düğmesiyle kontrol edin.
- Yayın bilgisi varsa program veya parça adı gösterilir.
- Başka sayfaya geçince mini oynatıcıdan yayını yönetin.
- Kilit ekranı/medya bildirimi platforma göre kullanılabilir.
- Canlı yayın kesintisiz internet ister.

### 20.2 İlahi TV/müzik

- Öne çıkan albüm, sanatçı ve parçaları inceleyin.
- Parça, albüm veya sanatçı arayın.
- Albüm detayında kapak ve parça listesini açın.
- Bir parçayı seçince oynatma sırası ilgili listeden oluşturulur.
- Parçayı favoriye, kişisel listeye veya indirmelere ekleyin.
- Albümün tamamını topluca indirme seçeneği sunulabilir.
- Yalnız Wi-Fi ile indirme açıksa mobil veride indirme başlamaz.

### 20.3 İlahi oynatıcı ve arşiv

- Mini oynatıcıda kapak, ad, sanatçı, ilerleme ve oynat/duraklat bulunur.
- Tam oynatıcıda önceki/sonraki, karıştırma ve tekrar modlarını kullanın.
- Kuyruğu açıp parçaya geçin, sıralayın veya sıradan kaldırın.
- Son Dinlediklerim geçmişini tek tek veya topluca temizleyin.
- İndirilenleri çevrimdışı oynatın.
- Ad vererek çalma listesi oluşturun; parça ekleyin, kaldırın, sıralayın, listeyi yeniden adlandırın veya silin.

### 20.4 Canlı video

- Ana sayfadaki yayın kartına dokunun.
- Oynat/duraklat, ses ve tam ekran kontrollerini kullanın.
- Telefonu yatay çevirerek geniş görünüm kullanın.
- Yayın kapalı veya bağlantı başarısızsa **Yeniden Dene** seçeneğini kullanın.

---

## 32. Ortak ses oynatma davranışı

- Kur'an, kitap, dergi, Delâil, ilahi ve radyo kendi oynatıcılarını kullanır.
- Mini oynatıcı sayfalar arasında mevcut sesi kontrol eder.
- Tam oynatıcıda zaman çizgisi, geçen/toplam süre ve içerik bilgisi bulunur.
- Kilit ekranı ve medya bildirimi kontrolleri işletim sistemi desteğine bağlıdır.
- Telefon görüşmesi, başka uygulamanın ses odağı veya kulaklık bağlantısının kesilmesi sesi duraklatabilir.
- Farklı ana seslerin üst üste çalmaması için yeni bir oynatıcı başlatıldığında önceki ses durabilir.
- Ses başlamıyorsa medya ses düzeyini, interneti/indirilen paketi ve aktif Bluetooth cihazını kontrol edin.