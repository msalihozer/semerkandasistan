## 1. Uygulamaya genel bakış

Semerkand Dijital; takvim ve namaz vakitleri, Kur'an-ı Kerîm, dijital kitap ve dergiler, Delâilü'l-Hayrât, hatim, ilahi/radyo içerikleri ve kişisel ibadet yardımcılarını tek uygulamada birleştirir.

Uygulamada yapılabilen temel işlemler:

- Seçilen konuma göre günlük ve aylık namaz vakitlerini görmek.
- Bir sonraki vakte kalan süreyi takip etmek ve vakit hatırlatıcıları kurmak.
- Günün ayeti, hadisi, sözü, duası ve tarihî içeriklerini okumak ve paylaşmak.
- Kıble yönünü pusula veya harita üzerinden bulmak; yakındaki camileri görmek.
- Kaza namazı sayılarını takip etmek ve dinî günleri incelemek.
- Kur'an'ı klasik mushaf, gelişmiş metin görünümü veya mealli görünümle okumak.
- Hafız seslerini indirip Kur'an dinlemek, Kur'an TV ve Mukabele kullanmak.
- Hatim grubu oluşturmak, gruba katılmak, cüz almak ve ilerleme kaydetmek.
- Kitap ve dergi keşfetmek, okumak, dinlemek, favorilere veya kişisel listelere eklemek.
- Delâilü'l-Hayrât'ı klasik sayfa veya açıklamalı/dinamik görünümde okumak ve dinlemek.
- İlahi Radyo, ilahi albümleri ve canlı yayınları dinlemek/izlemek.
- Hava durumu, adım sayar, okuma istatistikleri, widget ve bağlı saat özelliklerini kullanmak.
- Duvar kâğıtlarını incelemek, uygun olanları indirmek/satın almak ve cihaza uygulamak.
- Uygulama içinden destek talebi açmak ve yanıtları takip etmek.

---

## 3. Gereksinimler özeti

| Özellik | İnternet | Oturum | Abonelik/ödeme | Cihaz izni veya ek koşul |
|---|---|---|---|---|
| Daha önce indirilmiş namaz vakitleri | Gerekmez | Gerekmez | Gerekmez | Konum daha önce seçilmiş olmalı |
| Yeni konum/vakit verisi | Gerekir | Gerekmez | Gerekmez | GPS seçilirse konum izni |
| Kıble pusulası | Genelde gerekmez | Gerekmez | Gerekmez | Konum ve cihaz yön sensörü |
| Yakındaki camiler | Gerekebilir | Gerekmez | Gerekmez | Konum izni |
| Namaz hatırlatıcıları | Kurulum/veri yenilemede gerekebilir | Gerekmez | Gerekmez | Bildirim; Android'de ek alarm/pil izinleri olabilir |
| Kaza takibi | Eşitleme için gerekir | **Gerekir** | Gerekmez | — |
| Kur'an modüllerinin çoğu | İndirme/medya için gerekir | Birçok deneyimde **gerekir** | İçeriğe göre değişebilir | Ses için hafız paketi |
| Hatim ve cüz işlemleri | Gerekir | **Gerekir** | Gerekmez | Bildirim isteğe bağlı |
| Kitaplık | Liste/eşitleme için gerekir | **Gerekir** | İçeriğe göre değişebilir | İndirme için depolama alanı |
| Dergi okuma | Çevrimdışı indirme sonrası gerekmez | İçeriğe göre gerekir | Bazı sayılarda **gerekir** | İndirme için depolama alanı |
| Delâilü'l-Hayrât | İlk paket/ses indirmede gerekir | **Gerekebilir** | İçeriğe göre değişebilir | Depolama alanı |
| Canlı radyo/video | **Gerekir** | İçeriğe göre değişebilir | İçeriğe göre değişebilir | Arka plan medya izni/servisi platforma bağlıdır |
| Hava durumu | Güncellemek için gerekir | Gerekmez | Gerekmez | Seçilmiş konum |
| Adım sayar | Eşitlemeye göre değişir | Gerekmez | Gerekmez | Hareket/Health Connect/Apple Health izni |
| Duvar kâğıdı | Liste, indirme ve satın alma için gerekir | İçeriğe göre değişebilir | Ücretli üründe gerekir | Galeri/fotoğraf izni platforma bağlıdır |
| Destek talepleri | **Gerekir** | **Gerekir** | Gerekmez | — |

---

## 4. İlk açılış ve kurulum

### 4.1 Kurulum sihirbazı

Mobil cihazda ilk açılışta ihtiyaçlara göre şu adımlar gösterilebilir:

1. **Bildirim izni:** Namaz vakti, hatim, destek yanıtı ve uygulama duyurularını göstermek için kullanılır.
2. **Adım sayar/aktivite izni:** Android'de fiziksel aktivite ve gerekirse Health Connect; iOS'ta sağlık/hareket verisi erişimi istenir. Bu adım atlanabilir.
3. **Konum:** Otomatik GPS veya ülke/şehir/ilçe seçimiyle namaz vakitleri hazırlanır.
4. **Hatırlatıcı hazırlığı:** Android'de ekran üstü gösterim veya pil optimizasyonu gibi gerekli sistem ayarları gösterilebilir. Bu kurulum daha sonra da yapılabilir.
5. **Hatırlatılacak vakitlerin seçimi:** Bildirim izni verildiyse ilk vakit tercihleri seçilebilir.
6. **Giriş:** Hesaba giriş yapılabilir veya giriş adımı atlanarak uygulamaya devam edilebilir.

İlk kurulumda atlanan izinler daha sonra ilgili özellik açıldığında veya cihazın Ayarlar uygulamasından verilebilir.

### 4.2 Konumu otomatik belirleme

1. Konum adımında otomatik konum seçeneğini açın.
2. İstenirse “Uygulamayı kullanırken” konum izni verin.
3. Arka planda konum güncellemesi isteniyorsa ve cihaz destekliyorsa “Her zaman” izni ayrıca istenebilir.
4. Uygulamanın konumu bulmasını ve namaz vakti verisini indirmesini bekleyin.
5. İşlem tamamlanınca ana sayfada konum adı ve vakitler görünür.

### 4.3 Konumu elle belirleme

1. Manuel konum seçimini açın.
2. Önce **Ülke**, sonra **Şehir/İl**, varsa **İlçe** seçin.
3. Kaydet veya devam düğmesine dokunun.
4. Namaz vakti verisi indirilirken ekrandan çıkmadan işlemin tamamlanmasını bekleyin.

Konum izni vermek istemeyen kullanıcılar manuel seçimle uygulamanın temel takvim özelliklerini kullanabilir.