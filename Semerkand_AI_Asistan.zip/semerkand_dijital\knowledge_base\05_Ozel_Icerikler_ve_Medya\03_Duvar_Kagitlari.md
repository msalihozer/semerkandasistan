## 21. Duvar kâğıtları

Duvar Kâğıtları ekranında görseller ızgara halinde listelenir. Bir karta dokunarak tam ön izlemeyi ve ürün durumunu açın.

### 21.1 Ücretsiz veya sahip olunan duvar kâğıdı

- **Android:** Uygula düğmesine dokunun; **Ana Ekran**, **Kilit Ekranı** veya **Her İkisi** seçeneğini belirleyin.
- **iPhone/iPad:** Görsel önce Fotoğraflar'a kaydedilir. Ardından iOS Ayarlar/Fotoğraflar üzerinden kullanıcı tarafından duvar kâğıdı yapılır; iOS uygulamanın duvar kâğıdını doğrudan değiştirmesine izin vermez.
- Galeriye kaydetme için platformun fotoğraf/medya izni istenebilir.

### 21.2 Ücretli duvar kâğıdı

- Kartta gösterilen mağaza fiyatını kontrol edin.
- Satın alma düğmesi Google Play/App Store ödeme akışını açar.
- Başarıyla sahip olunan ürün indirilebilir veya uygulanabilir.
- Satın alma beklemede, iptal veya başarısız durumdaysa mağaza işleminin sonucunu kontrol edin.
- İade, ödeme veya mağaza hesabı sorunlarında ilgili uygulama mağazasının kuralları geçerlidir; gerekirse uygulama içi Destek'e başvurun.