## 8. Namaz vakti hatırlatıcıları

Menü yolu: **Ana Sayfa > Hatırlatıcılar** veya **Menü > Hatırlatıcılar**

### 8.1 Hatırlatıcı oluşturma

1. İlgili vaktin anahtarını açın.
2. Vakit satırına dokunun.
3. Uyarının vakitten **önce**, **tam vaktinde** veya **sonra** çalışmasını seçin.
4. Önce/sonra seçildiğinde dakika değerini belirleyin.
5. Uyarı sesini ve ses düzeyini seçin.
6. Değişikliği kaydedin.

Her vakit birbirinden bağımsız ayarlanabilir. Cuma günü Öğle vakti için cihaz/sürüm desteğine göre farklı davranış seçeneği bulunabilir.

### 8.2 Ses seçimi

- Hazır seslerden biri seçilebilir ve kısa ön dinleme yapılabilir.
- İndirilebilir bir ses önce cihazda hazırlanmalıdır.
- Desteklenen cihazlarda kullanıcı kendi ses dosyasını seçebilir.
- Seçilen dosya silinirse uygulama varsayılan sese dönebilir.

### 8.3 Android'de gerekli ek ayarlar

Hatırlatıcıların zamanında ve görünür çalışması için cihaz sürümüne göre şunlar gerekebilir:

- Bildirim izni
- Kesin alarm izni
- Diğer uygulamaların üzerinde gösterme izni
- Rahatsız Etmeyin erişimi
- Pil optimizasyonundan çıkarma
- Üreticiye özel otomatik başlatma/arka plan çalışma izni

Kurulum ekranındaki eksik izin kartına dokunarak ilgili sistem ayarını açın. İzin adları telefon markasına göre değişebilir.

### 8.4 Kalıcı bildirim çubuğu

Android'de `Ayarlar > Widget ve Bildirim Çubuğu` bölümünden namaz vakti bildirim çubuğu açılabilir. Bildirimde sıradaki vakit, saati ve kalan süre gösterilebilir. Bildirim izni kapalıysa özellik çalışmaz.