## 17. Dergiler

### 17.1 Dergi ana sayfası ve türler

- Güncel sayıları, dergi türlerini ve öne çıkan içerikleri inceleyin.
- Kapak raflarını yatay kaydırın veya **Tümünü Göster** seçeneğini kullanın.
- Tür kartına dokunarak o derginin sayılarını açın.
- Raf, Favoriler ve İndirilenler kısayollarını kullanın.
- Abonelik isteyen sayı açılırken giriş veya abonelik sorgulama yönlendirmesi gösterilir.

Tür ekranında sayılar yıllara göre gruplanır. Yıl seçilebilir; aktif kapak büyütülür. Kartta sayı, ay/yıl ve favori durumu bulunabilir.

### 17.2 Dergi detay, içindekiler ve arama

- Kapak, sayı adı, yıl, sayı numarası ve açıklamayı görün.
- Uzun açıklamayı genişletin/daraltın.
- İçindekiler panelinden konu başlığına veya sayfasına gidin.
- Kelime/ifade arayın; sonuçtaki sayfa ve metin parçasını açın.
- Arama sonucu okuyucuda vurgulanabilir.
- **İndir** ile sayıyı çevrimdışı kullanıma hazırlayın.
- İndirilen sayıyı detaydan veya İndirilenler ekranından silebilirsiniz.

### 17.3 Dergi okuyucu

- Sayfaları sağa/sola sürükleyin.
- Klasik kaydırma veya sayfa çevirme animasyonunu seçin.
- Sayfa çevirme sesini açın/kapatın.
- Yazı boyutunu ayar veya iki parmak hareketiyle değiştirin.
- Koyu mod ya da sunulan açık zemin renklerini seçin.
- Görünümü varsayılana sıfırlayın.
- Tam ekranla araç çubuklarını gizleyin.
- Önceki/sonraki sayfaya geçin, içindekileri açın veya sesli okumayı başlatın.
- Son sayfa çıkışta saklanır.

### 17.4 Metin seçimi ve alıntı

- Metne uzun basıp seçim yapın.
- Seçimi kopyalayın veya paylaşın.
- **Favoriye Ekle** ile alıntı olarak kaydedin.
- Favoriler ekranındaki **Sözler** sekmesinden alıntıları görün.
- Alıntıya dokunarak ilgili dergi sayfasına ve vurgulanmış metne dönün.
- Alıntıyı yeniden paylaşın veya silin.

### 17.5 Dergi sesli okuma

- Sesi bulunan konuda oynatma düğmesine dokunun.
- Kaldığınız yerden devam edin veya baştan başlatın.
- Konu, yazar, seslendiren ve süre bilgisini görün.
- Önceki/sonraki konu, ileri/geri sarma ve zaman çizgisini kullanın.
- Sunulan aralıkta oynatma hızını değiştirin.
- Desteklenen cihazlarda yankı efekti kullanılabilir.
- Yağmur/doğa gibi fon sesi seçip seviyesini ayrı ayarlayabilirsiniz.
- Mini oynatıcıyla dergi sayfaları arasında dinlemeyi sürdürün.

### 17.6 Raf, Favoriler ve İndirilenler

- **Raf:** Tür düğmeleriyle filtreleyin; karta dokunarak sayıya gidin.
- **Favoriler > Dergiler:** Kayıtlı sayıları tür bazında filtreleyin.
- **Favoriler > Sözler:** Kaydedilen alıntıları yönetin.
- **İndirilenler:** Çevrimdışı sayıları ve dosya boyutlarını görün; tekli veya seçim modunda toplu silin.