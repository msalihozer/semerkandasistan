## 19. Delâilü'l-Hayrât

Delâil bölümü oturum açmayı isteyebilir. Giriş ekranında iki deneyim bulunur:

- **Klasik görünüm:** Sayfa/PDF temelli okuma.
- **Dinamik/açıklamalı görünüm:** Metin akışı, açıklama ve gelişmiş ses takibi.

Her görünümde **Devam Et**, **Yer İmleri** ve **İçindekiler** eylemleri bulunur. **Hakkında** bölümü eserle ilgili bilgi verir.

### 19.1 Klasik görünüm

- İlk kullanımda sayfa paketini indirin; aktarım ve kurulum ilerlemesini takip edin.
- Son sayfadan devam edin veya içindekilerden gün/bölüm seçin.
- Sayfaları sağa/sola kaydırın ve yakınlaştırın.
- Mevcut sayfaya yer imi ekleyin.
- Okuma zemini ve okuma imleci gibi sunulan görünüm seçeneklerini ayarlayın.
- Otomatik ilerlemeyi açıp hızını değiştirin.
- Son sayfa çıkışta kaydedilir.
- Ayarlardan Delâil okuma istatistiklerini açabilirsiniz.

### 19.2 Dinamik/açıklamalı görünüm

- Bölüm veya yaprak seçerek başlayın; kaldığınız metin konumundan devam edin.
- Arapça metin, tercüme/açıklama ve içerik düzenini okuyucu ayarlarından değiştirin.
- Yazı boyutu, satır takibi/imleç ve otomatik kaydırmayı ayarlayın.
- Metin konumuna yer imi ekleyip yer imleri ekranından geri dönün.
- İçindekiler panelinden başka bölüme atlayın.
- Uyumlu ses paketini indirin; ses çalarken ilgili metin/satır takibi yapılabilir.
- Oynat/duraklat, zaman çizgisi ve otomatik kaydırma kontrollerini kullanın.
- Ayarlar içinden okuma istatistiklerini açın.

### 19.3 Delâil indirmeleri ve hatırlatması

- Büyük sayfa ve ses paketleri için Wi-Fi önerilir.
- İndirme bittikten sonra kurulum/hazırlama aşaması olabilir.
- Kullanılmayan ses/paketler ilgili ayarlardan silinebilir.
- Delâil hatırlatıcısı varsa gün, saat ve bildirim tercihini okuyucu/Delâil ayarlarından düzenleyin; bildirim izni gereklidir.