import os
import json
import sqlite3
import datetime
from flask import Flask, render_template, request, Response, stream_with_context
import ollama
import chromadb
from chromadb.utils import embedding_functions

app = Flask(__name__)

# --- ChromaDB Setup ---
chroma_client = chromadb.PersistentClient(path="C:/Users/DELL/Desktop/ai-control/chroma_db")
ollama_ef = embedding_functions.OllamaEmbeddingFunction(
    url="http://localhost:11434/api/embeddings",
    model_name="nomic-embed-text"
)
collection = chroma_client.get_collection(name="semerkand_kb", embedding_function=ollama_ef)

# --- Rota Haritasını Belleğe Al (Hybrid Approach) ---
ui_map_path = r"C:\Users\DELL\Desktop\ai-control\semerkand_dijital\knowledge_base\ui_navigation_map.json"
try:
    with open(ui_map_path, "r", encoding="utf-8") as f:
        ui_map_data = json.load(f)
        paths = ui_map_data.get("hedefe_nasil_ulasilir_yollari", {})
        paths_str = "\n".join([f"- {k}: {v}" for k, v in paths.items()])
        actions = ui_map_data.get("ekran_ve_aksiyonlar", [])
        actions_str = "\n".join([f"- Ekran: {a.get('bulunulan_ekran', '')} -> İşlem: {a.get('yapilabilen_islem', '')}" for a in actions])
        ui_map_content = f"### MENÜ YOLLARI\n{paths_str}\n\n### EKRAN İŞLEMLERİ\n{actions_str}"
except Exception as e:
    print("UI Map yüklenemedi:", e)
    ui_map_content = ""

# --- 1. Veritabanı (SQLite) Kurulumu ---
def init_db():
    conn = sqlite3.connect('chat_logs.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            project_name TEXT,
            category TEXT,
            user_question TEXT,
            assistant_response TEXT
        )
    ''')
    conn.commit()
    conn.close()

init_db()

def save_log(project, category, question, response):
    try:
        conn = sqlite3.connect('chat_logs.db')
        cursor = conn.cursor()
        timestamp = datetime.datetime.now().isoformat()
        cursor.execute("INSERT INTO logs (timestamp, project_name, category, user_question, assistant_response) VALUES (?, ?, ?, ?, ?)",
                       (timestamp, project, category, question, response))
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"Log kaydetme hatası: {e}")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/chat', methods=['POST'])
def chat_api():
    data = request.json
    user_message = data.get("message", "")
    history = data.get("history", [])
    
    if not user_message:
        return {"error": "Message is required"}, 400

    # 1. RAG ile İlgili Kaynakları Bul
    results = collection.query(
        query_texts=[user_message],
        n_results=4
    )
    
    context_docs = results['documents'][0] if results['documents'] else []
    context_text = "\n\n---\n\n".join(context_docs)

    rag_system_prompt = f"""SENİN GÖREVİN: 'Semerkand Dijital' uygulaması hakkında net, açık ve anlaşılır teknik destek vermek.

CİHAZ İZİNLERİ KURALI (ÇOK ÖNEMLİ):
Eğer kullanıcı Adım Sayar, Kıble Pusulası, Bildirim (veya Bildirim Çubuğu) ya da Konum gibi cihaz izni gerektiren bir özellik soruyorsa, çözüm yolunu şu iki net başlık altında anlat:
1. UYGULAMA İÇİ KONTROL: Önce uygulamanın içindeki menü yolunu, aşağıdaki NAVİGASYON HARİTASI'nı kullanarak ver. (Örn: Bildirim çubuğu açma için Widget ve Bildirim Çubuğu Ayarları'nı kontrol etmesini söyle). Haritada olmayan menüleri uydurma!
2. TELEFON AYARLARI KONTROLÜ (Android / iOS): Daha sonra telefonun kendi sistem ayarlarından izinlerin (veya bildirimlerin) açık olması gerektiğini belirt. Android ve iOS için telefon ayarları (Örn: Ayarlar > Uygulamalar > Semerkand Dijital > İzinler/Bildirimler) adımlarını açık ve net ifadelerle, uygulamadan ayırarak anlat.

MENÜ YOLU KURALI:
Uygulama içi bir menü tarif ederken ASLA haritada olmayan sahte bir ekran veya menü uydurma.

BİLGİ TABANI ALINTILARI (RAG):
{context_text}

UYGULAMA NAVİGASYON HARİTASI (Sadece Bu Yolları Kullan):
{ui_map_content}
"""

    messages = [{"role": "system", "content": rag_system_prompt}]
    messages.extend(history)
    messages.append({"role": "user", "content": user_message})

    def generate():
        full_response = ""
        try:
            stream = ollama.chat(
                model='semerkand_ai',
                messages=messages,
                stream=True,
                options={'num_ctx': 8192, 'temperature': 0.1, 'keep_alive': -1}
            )
            
            for chunk in stream:
                content = chunk['message']['content']
                if content:
                    full_response += content
                    yield f"data: {json.dumps({'text': content})}\n\n"
            
            # Kategori Tahmini
            try:
                cat_prompt = (
                    f"Aşağıdaki kullanıcı sorusunu analiz et ve bu soru için en uygun teknik destek kategorisini (örn: 'Abonelik', 'Okuma', 'Hata') 1-2 kelimeyle yaz.\n"
                    f"Soru: {user_message}"
                )
                cat_response = ollama.chat(
                    model='semerkand_ai',
                    messages=[{"role": "user", "content": cat_prompt}],
                    stream=False,
                    options={'num_ctx': 4096, 'keep_alive': -1}
                )
                ai_detected_category = cat_response['message']['content'].strip()
                ai_detected_category = ai_detected_category.replace('"', '').replace("'", "")
            except Exception as e:
                print(f"Kategori analiz hatası: {e}")
                ai_detected_category = "Genel"

            save_log("semerkand_dijital", ai_detected_category, user_message, full_response)

        except Exception as e:
            error_msg = f"Ollama bağlantı hatası: {str(e)}"
            yield f"data: {json.dumps({'error': error_msg})}\n\n"
        
        yield "data: [DONE]\n\n"

    return Response(stream_with_context(generate()), mimetype='text/event-stream')

if __name__ == '__main__':
    # Uzun süreli çalışma için debug=False yapıldı
    app.run(host='0.0.0.0', port=5000, debug=False)
