import os
import json
import chromadb
from chromadb.utils import embedding_functions

# Connect to local ChromaDB
chroma_client = chromadb.PersistentClient(path="C:/Users/DELL/Desktop/ai-control/chroma_db")

# Use Ollama for embeddings
ollama_ef = embedding_functions.OllamaEmbeddingFunction(
    url="http://localhost:11434/api/embeddings",
    model_name="nomic-embed-text"
)

# Re-create the collection
try:
    chroma_client.delete_collection(name="semerkand_kb")
except:
    pass

collection = chroma_client.create_collection(
    name="semerkand_kb",
    embedding_function=ollama_ef
)

kb_dir = r"C:\Users\DELL\Desktop\ai-control\semerkand_dijital\knowledge_base"
ui_map_path = r"C:\Users\DELL\Desktop\ai-control\semerkand_dijital\knowledge_base\ui_navigation_map.json"

docs = []
metadatas = []
ids = []
doc_id = 1

print("Bilgi tabanı markdown dosyaları okunuyor...")
# 1. Read Markdown files (chunk by paragraph or file)
for root, dirs, files in os.walk(kb_dir):
    for file in sorted(files):
        if file.endswith(".md") and file != "README.md":
            with open(os.path.join(root, file), "r", encoding="utf-8") as f:
                content = f.read()
                # Split by Double Newlines (Paragraphs) to create smaller chunks
                chunks = [c.strip() for c in content.split("\n\n") if len(c.strip()) > 30]
                for chunk in chunks:
                    docs.append(chunk)
                    metadatas.append({"source": file})
                    ids.append(f"doc_{doc_id}")
                    doc_id += 1

print("UI Navigasyon Haritası okunuyor...")
# 2. Read UI Map and convert to chunks
with open(ui_map_path, "r", encoding="utf-8") as f:
    ui_map = json.load(f)
    
    # Paths chunk
    for feature, path in ui_map.get("hedefe_nasil_ulasilir_yollari", {}).items():
        chunk_text = f"Özellik/İşlem: {feature}\nMenü Yolu: {path}"
        docs.append(chunk_text)
        metadatas.append({"source": "ui_map_paths"})
        ids.append(f"doc_{doc_id}")
        doc_id += 1
        
    # Actions chunk
    for action in ui_map.get("ekran_ve_aksiyonlar", []):
        ekran = action.get('bulunulan_ekran', '')
        islem = action.get('yapilabilen_islem', '')
        chunk_text = f"Ekran: {ekran}\nYapılabilecek İşlem: {islem}"
        docs.append(chunk_text)
        metadatas.append({"source": "ui_map_actions"})
        ids.append(f"doc_{doc_id}")
        doc_id += 1

print(f"Toplam {len(docs)} adet parça veritabanına ekleniyor. Bu işlem biraz sürebilir...")
# 3. Add to ChromaDB (Batching to avoid large payload issues)
batch_size = 100
for i in range(0, len(docs), batch_size):
    collection.add(
        documents=docs[i:i+batch_size],
        metadatas=metadatas[i:i+batch_size],
        ids=ids[i:i+batch_size]
    )
    print(f"%{int((i/len(docs))*100)} tamamlandı...")

print("Veritabanı başarıyla oluşturuldu!")
